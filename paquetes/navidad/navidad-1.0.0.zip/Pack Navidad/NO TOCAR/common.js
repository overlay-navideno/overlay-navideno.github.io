/* ─────────────────────────────────────────────────────────────
   Pack Navidad — código compartido (script clásico, sin módulos)
   · HW.PIEZAS   : qué se puede configurar en cada pieza (lo usa el PANEL)
                   archivo = nombre dentro de la carpeta Piezas/ (solo ASCII)
   · HW.leer()   : lee los parámetros de la URL con sus valores de fábrica
   · HW.Chat     : chat de Twitch anónimo por WebSocket (sin login)
                   + campos de canje/bits/insignias + eventos (subs, regalos, raids)
   · HW.ChatKick : chat de Kick anónimo por WebSocket (sin login)
   · HW.Helix, HW.validarToken, HW.EventSub : login opcional (Mascota con token=)
   · HW.nieve    : capa de nieve con copos HTML (3 profundidades)
   · HW.guirnalda: tira de luces navideñas con colgantes
   · HW.arte     : dibujos SVG propios (foco, estrella, copo, pino, regalo…;
                   fase 6: repisa, chimenea, vela, renoAsoma, galletaAsoma;
                   fase 7: jengibre = casa, ventana, gomita, glaseado;
                   fase 8: rodillo, cortador, frasco;
                   fase 9: montana, cerca, farol, munecoNieve, trineo, cabana)
   · HW.pantalla : bloque de texto de los fondos (Empezamos / Vuelvo / Fin)
   El namespace sigue llamándose HW (heredado del pack de Halloween).
   REGLA: el texto que viene del chat o de la URL se pone SIEMPRE con
   textContent. Nunca se concatena dentro de strings SVG/HTML.
   ───────────────────────────────────────────────────────────── */
(function(){
'use strict';
var HW = window.HW = window.HW || {};

/* Login opcional. AUTH_URL la rellena quien publique la página de conexión (ver navidad-dev/auth/PUBLICAR.md).
   SCOPES: todos de solo lectura (la página de conexión lleva su propia copia). */
HW.AUTH_URL = 'https://overlay-navideno.github.io/';
HW.SCOPES = ['channel:read:redemptions','moderator:read:followers','bits:read','channel:read:subscriptions','channel:read:hype_train'];
/* Versión del pack: el único sitio donde se escribe. Solo el PANEL la usa, para avisar si hay una más nueva
   (las piezas no preguntan nada). Formato 1.2.3. */
HW.VERSION = '1.0.0';
/* App de Twitch del pack (es pública: va en la página de conexión). Un código de otra app (con más permisos) no se acepta */
HW.CLIENT_ID = '67faq6zza1tfkrn0kd2eu6yjyylned';
/* ¿El código comprobado es de esta app? En pruebas contra un Twitch simulado local (validar = 127.0.0.1) vale «prueba» */
HW.esNuestraApp = function(clientId, base){
  clientId = String(clientId || '');
  return clientId === HW.CLIENT_ID || (!!base && HW.esLocal(base, ['http', 'https']) && clientId === 'prueba');
};

/* ── 0. Datos de esta computadora (solo si el pack lo instaló el instalador) ──
   Carpeta «Datos» junto a PANEL.html, fuera de lo que cambia una actualización:
   · Datos/conexion.js → window.NV_CONEXION = {puerto, clave}: la conexión con OBS que dejó el instalador (la misma
     contraseña que OBS ya guarda en su config.json). Solo la lee el PANEL dentro de OBS (?obs=1&datos=1).
   · Datos/codigo.js → window.NV_CODIGO = '…': tu código de Twitch, escrito por el plugin del pack cuando lo pegas en el
     panel de OBS. Así no va en la URL de tus fuentes (ni en Propiedades ni en la colección de escenas).
     Lo leen el PANEL (?datos=1) y las piezas cuyo link dice codigo=1 (nunca dentro de la vista previa: vista=1).
   Se cargan aquí con document.write: corren justo después de este archivo y antes del script de la página. */
(function(){
  if (typeof document === 'undefined' || typeof location === 'undefined') return;   /* fuera de un navegador (pruebas en node) */
  var q = {};
  String(location.search || '').replace(/^\?/, '').split('&').concat(String(location.hash || '').replace(/^#/, '').split('&')).forEach(function(par){
    var i = par.indexOf('='); if (par) q[(i < 0 ? par : par.slice(0, i)).toLowerCase()] = i < 0 ? '' : par.slice(i + 1);
  });
  var si = function(v){ return /^(1|si|s|true)$/i.test(String(v == null ? '' : v)); };
  var yo = document.currentScript && document.currentScript.src || '';
  var raiz = yo.replace(/[^\/]*\/common\.js(?:[?#].*)?$/, '');
  if (!raiz || raiz === yo || si(q.vista)) return;
  var cargar = function(arch){ try { document.write('<script src="' + raiz + 'Datos/' + arch + '"><\/script>'); } catch(e){} };
  if (si(q.datos)){ cargar('conexion.js'); cargar('codigo.js'); }
  else if (si(q.codigo) && !q.token) cargar('codigo.js');
})();

/* ── 1. Catálogo de piezas y parámetros ─────────────────────── */
var SI_NO = [['si','Sí'],['no','No']];
HW.SI_NO = SI_NO;
var FHD = [1920, 1080];
/* Campos comunes de los tres fondos (doble modo: pantalla con texto / fondo limpio).
   cambios = { clave: {def, l, help…} } retoca un campo común solo en ese fondo (fase 9: nieve 1 en Blanca Navidad) */
/* Atajos de color del PANEL: van encima del selector libre, nunca en su lugar */
HW.TONOS = [['e8424f','Rojo'],['2f8f5b','Verde'],['ffcf5c','Dorado'],['4f8fd6','Azul'],['fffaf0','Blanco']];
/* Atajos del color de los fondos. ffcf5c es el de fábrica: deja cada adorno con su color de siempre */
var TONOS_FONDO = [['ffcf5c','De fábrica'],['e8424f','Rojo'],['2f8f5b','Verde'],['d99a1c','Dorado'],['4f8fd6','Azul'],['9a62d6','Morado'],['fffaf0','Blanco']];
/* Color elegido para la decoración de un fondo, o '' si es el de fábrica (cada adorno conserva sus colores) */
HW.colorEscena = function(acento){
  var h = HW.hex(acento);
  if (!h || h === '#ffcf5c') return '';
  /* casi blanco: un plata suave, para que rayas y cuadros se sigan viendo sobre su fondo claro */
  var c = HW.rgb(h);
  return (c[0] * .3 + c[1] * .59 + c[2] * .11) > 225 ? HW.mezcla(h, '#6f86ad', .42) : h;
};
function camposFondo(extra, cambios){
  var campos = [
    {k:'modo', l:'Modo', t:'select', def:'pantalla', o:[['pantalla','Pantalla con texto (Empezamos / Vuelvo / Fin)'],['fondo','Fondo limpio (sin texto)']]},
    {k:'tipo', l:'Pantalla', t:'select', def:'soon', o:[['soon','Empezamos pronto'],['brb','Vuelvo enseguida'],['ending','Fin del directo']], visibleSi:{modo:'pantalla'}},
    {k:'titulo', l:'Título', t:'text', def:'', ph:'(texto de fábrica)', help:'Vacío = texto de fábrica de cada pantalla', visibleSi:{modo:'pantalla'}},
    {k:'subtitulo', l:'Subtítulo / mensaje', t:'text', def:'', ph:'(texto de fábrica)', visibleSi:{modo:'pantalla'}},
    {k:'cuenta', l:'Cuenta atrás', t:'select', def:'si', o:SI_NO, visibleSi:{modo:'pantalla', tipo:['soon','brb']}},
    {k:'minutos', l:'Minutos de la cuenta atrás', t:'num', def:5, min:0, max:120, step:1, visibleSi:{modo:'pantalla', tipo:['soon','brb'], cuenta:'si'},
      help:'Al llegar a 0 dice «¡Ya casi!». 0 = sin cuenta'},
    {k:'acento', l:'Color de la decoración', t:'color', def:'ffcf5c', tonos:TONOS_FONDO, help:'Pinta los adornos de la escena y el cartel. De fábrica (ffcf5c) cada adorno lleva su color de siempre'},
    {k:'nieve', l:'Nieve', t:'num', def:0.6, min:0, max:3, step:0.1, help:'0 = sin nieve. Más de 2 puede pesar en PCs modestos'},
    {k:'guirnalda', l:'Guirnalda arriba', t:'select', def:'si', o:SI_NO}
  ];
  if (cambios) campos = campos.map(function(d){
    if (!cambios[d.k]) return d;
    var c = {}, k; for (k in d) c[k] = d[k]; for (k in cambios[d.k]) c[k] = cambios[d.k][k];
    return c;
  });
  return campos.concat(extra || []);
}
/* Miniatura del cielo para las tarjetas del PANEL: degradado de 3 colores, luna o sol a la altura y y el monte nevado */
function cieloMini(c, astro, y){
  return '<svg viewBox="0 0 84 98" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="cm'+c[0].slice(1)+c[1].slice(1)+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+c[0]+'"/><stop offset=".55" stop-color="'+c[1]+'"/><stop offset="1" stop-color="'+c[2]+'"/></linearGradient></defs>' +
    '<rect width="84" height="98" rx="10" fill="url(#cm'+c[0].slice(1)+c[1].slice(1)+')"/><circle cx="52" cy="'+y+'" r="11" fill="'+astro+'"/>' +
    '<path d="M0 88V74L18 56L32 70L48 50L68 72L84 62V88Q84 98 74 98H10Q0 98 0 88Z" fill="#3a3f7a"/><path d="M0 88V82Q42 72 84 84V88Q84 98 74 98H10Q0 98 0 88Z" fill="#eef1ff"/></svg>';
}
/* Minis de las tarjetas del PANEL. Son funciones: solo se dibujan al abrir el PANEL, nunca dentro de una pieza */
function miniSvg(caja, s){ return '<svg viewBox="'+caja+'" xmlns="http://www.w3.org/2000/svg">'+s+'</svg>'; }
function miniEn(x, y, e, s, rot){ return '<g transform="translate('+x+' '+y+') scale('+e+')'+(rot ? ' rotate('+rot+')' : '')+'">'+s+'</g>'; }
var MINI_CABLE = 'M-46-18Q0 18 46-18';
function miniCable(){ return '<path d="'+MINI_CABLE+'" fill="none" stroke="#123524" stroke-width="7" stroke-linecap="round"/><path d="'+MINI_CABLE+'" fill="none" stroke="#4fb37a" stroke-width="3.5" stroke-linecap="round"/>'; }
/* Cuenta: el cartelito con su adornito a la izquierda (el mismo arte que la pieza) */
function miniAdorno(id){
  var A = HW.arte, sin = id === 'ninguno', x0 = sin ? -30 : -12;
  var cartel = '<rect x="-42" y="-15" width="84" height="30" rx="15" fill="#2a2638" stroke="#e8424f" stroke-width="3"/>' +
    '<rect x="' + x0 + '" y="-4" width="' + (32 - x0) + '" height="8" rx="4" fill="#fff4dd" opacity=".55"/>';
  var dib = id === 'acebo' ? miniEn(-26, 0, .5, A.acebo()) : sin ? '' : miniEn(-26, 0, .58, A.estrella({ r:22, cara:true, brillo:false }));
  return miniSvg('-45 -19 90 38', cartel + dib);
}
function miniColgante(id){
  var A = HW.arte, hilo = '<path d="M0 0V16" stroke="#e9dcc0" stroke-width="2"/>', dib = '';
  if (id === 'calcetas') dib = hilo + miniEn(-9, 2, .74, A.calceta({ color:'#e8424f', patron:'rayas' }));
  else if (id === 'bastones') dib = hilo + miniEn(2, 14, .78, A.baston());
  else if (id === 'estrellas') dib = hilo + miniEn(0, 44, 1.2, A.estrella({ r:22, cara:true, brillo:false }));
  else if (id === 'bolas') dib = hilo + miniEn(0, 14, 1.1, A.bola('#e8424f'));
  return miniSvg('-42 -22 84 98', miniCable() + dib);
}
function miniPaleta(id){
  var A = HW.arte, cols = HW.PALETAS[id] || HW.PALETAS.clasica, s = miniCable();
  [[-31, -8, 14], [-11, -1, 5], [11, -1, -5], [31, -8, -14]].forEach(function(f, i){
    s += '<circle cx="'+f[0]+'" cy="'+(f[1] + 24)+'" r="17" fill="'+cols[i]+'" opacity=".22"/>' + miniEn(f[0], f[1], .78, A.foco(cols[i]), f[2]);
  });
  return miniSvg('-46 -24 92 76', s);
}
/* Nombres cortos de las tarjetas (o[1] sigue siendo el nombre largo de Parametros (avanzado).txt) */
var NOMBRES_PALETA = { clasica:'Muchos colores', calida:'Cálidas', fria:'Frías' };
/* Un marquito de cámara, con el mismo arte que el marco de verdad */
function miniCuadro(){ return '<rect x="-34" y="-24" width="68" height="48" rx="7" fill="#17141d" stroke="#1d1a2e" stroke-width="8"/><rect x="-34" y="-24" width="68" height="48" rx="7" fill="none" stroke="#e8424f" stroke-width="4.5"/>'; }
function miniEsquina(id){
  var A = HW.arte, s = miniCuadro();
  if (id === 'acebo') s += miniEn(-30, -20, .5, A.acebo()) + miniEn(30, 20, .5, A.acebo(), 180);
  else if (id === 'muerdago') s += miniEn(-17, -26, .62, A.muerdago()) + miniEn(17, -26, .62, A.muerdago());
  else if (id === 'bastones'){
    var par = '<g transform="translate(-14 -40) rotate(-18)">' + A.baston() + '</g><g transform="translate(14 -40) scale(-1 1) rotate(-18)">' + A.baston() + '</g><g transform="translate(0 -26) scale(.6)">' + A.acebo() + '</g>';
    s += miniEn(-28, -18, .42, par, -40) + miniEn(28, 18, .42, par, 140);
  }
  return miniSvg('-50 -40 100 80', s);
}
function miniAsoma(id){
  var A = HW.arte, art = id === 'galleta' ? A.galletaAsoma : A.renoAsoma;
  if (id === 'ninguno') return miniSvg('-50 -40 100 80', miniCuadro());
  return miniSvg('-82 -142 164 160', '<clipPath id="mini-asoma-'+id+'"><rect x="-82" y="-142" width="164" height="142"/></clipPath><g clip-path="url(#mini-asoma-'+id+')">' + art({ parte:'cabeza' }) + '</g><rect x="-80" y="-4" width="160" height="16" rx="6" fill="#e8424f" stroke="#1d1a2e" stroke-width="4"/>' + art({ parte:'manos' }));
}
/* Regiones de la Cuenta para Navidad (11-nov): nombre práctico → zona IANA. Intl calcula solo el horario de verano.
   Nunca se enseña GMT ni UTC. [clave, nombre, zona, grupo]. 'pc' = la hora de la computadora (lo de antes del 11-nov) */
HW.REGIONES = [
  ['cdmx', 'CDMX, Guadalajara y Monterrey', 'America/Mexico_City', 'México'],
  ['noroeste', 'Sonora, Sinaloa y Baja California Sur', 'America/Hermosillo', 'México'],
  ['tijuana', 'Tijuana y Mexicali', 'America/Tijuana', 'México'],
  ['cancun', 'Cancún y Quintana Roo', 'America/Cancun', 'México'],
  ['guatemala', 'Guatemala y Centroamérica (El Salvador, Honduras, Nicaragua, Costa Rica)', 'America/Guatemala', 'Centroamérica y el Caribe'],
  ['panama', 'Panamá', 'America/Panama', 'Centroamérica y el Caribe'],
  ['caribe', 'República Dominicana y Puerto Rico', 'America/Santo_Domingo', 'Centroamérica y el Caribe'],
  ['cuba', 'Cuba', 'America/Havana', 'Centroamérica y el Caribe'],
  ['colombia', 'Colombia', 'America/Bogota', 'Sudamérica'],
  ['peru', 'Perú', 'America/Lima', 'Sudamérica'],
  ['ecuador', 'Ecuador', 'America/Guayaquil', 'Sudamérica'],
  ['venezuela', 'Venezuela', 'America/Caracas', 'Sudamérica'],
  ['bolivia', 'Bolivia', 'America/La_Paz', 'Sudamérica'],
  ['paraguay', 'Paraguay', 'America/Asuncion', 'Sudamérica'],
  ['chile', 'Chile', 'America/Santiago', 'Sudamérica'],
  ['argentina', 'Argentina', 'America/Argentina/Buenos_Aires', 'Sudamérica'],
  ['uruguay', 'Uruguay', 'America/Montevideo', 'Sudamérica'],
  ['espana', 'España (península y Baleares)', 'Europe/Madrid', 'España'],
  ['canarias', 'Islas Canarias', 'Atlantic/Canary', 'España'],
  ['us-este', 'EE. UU. Este (Nueva York, Miami)', 'America/New_York', 'Estados Unidos'],
  ['us-centro', 'EE. UU. Centro (Chicago, Houston, Dallas)', 'America/Chicago', 'Estados Unidos'],
  ['us-montana', 'EE. UU. Montaña (Denver)', 'America/Denver', 'Estados Unidos'],
  ['us-pacifico', 'EE. UU. Pacífico (Los Ángeles)', 'America/Los_Angeles', 'Estados Unidos'],
  ['pc', 'La hora de mi computadora', '', 'Otra']
];
HW.PIEZAS = [
  /* ── Chat ── */
  { id:'desfile', grupo:'chat', archivo:'Desfile del chat.html', nombre:'Desfile navideño del chat', transparente:true, demo:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Cada persona que escribe en tu chat de Twitch o de Kick sale como un personaje navideño (reno, duende, muñeco de nieve…) que camina con su nombre y su mensaje.',
    /* Sin canal el desfile no sirve (en OBS sale un aviso): por eso el canal va primero, como en la Mascota */
    pasos:[
      {t:'Tu chat', f:'Quien escriba en tu chat sale caminando por la pantalla. No hay que conectar nada más.', twitch:{ sinCanal:'Sin tu canal el desfile no tiene a quién sacar. Aquí en la vista previa sale gente de mentira.' }, campos:[]},
      {t:'Cómo se ven', f:'Ya viene listo. Cambia solo lo que quieras.', campos:['pos','tamano','velocidad','mensajes']},
      {t:'Cuánta gente sale', f:'Si tu chat es muy movido, baja el número para que no se amontonen.', campos:['max','duracion']}
    ],
    avanzado:['ignorar','demo'],
    avanzadoNota:'· nombres que no salen, chat de mentira y otro canal',
    /* Probar: recarga la vista previa con chat de mentira. No entra en el link */
    probarVista:{ t:'Que pase gente de mentira', volver:'Volver a mi chat', q:'demo=si', claves:['canal','canalkick'], nota:'Solo en esta vista previa. No sale en tu directo.' },
    params:[ /* 8 personajes: reno, duende, muneco, galleta, santa, pinguino, oso, cascanueces */
      {k:'canal', l:'Canal de Twitch', t:'text', def:'', ph:'tucanal', help:'Solo el nombre, sin twitch.tv/. Deja en blanco el que no uses',
        lPaso:'Tu canal de Twitch', helpPaso:'Solo el nombre, tal como sale en twitch.tv/tucanal (sin twitch.tv/). Si solo usas Kick, déjalo vacío.', listo:'✓ Listo: el desfile ve el chat de {canal}.'},
      {k:'canalkick', l:'Canal de Kick', t:'text', def:'', ph:'tucanal', lPaso:'Tu canal de Kick', helpPaso:'Solo el nombre, sin kick.com/. Puedes poner los dos a la vez.', help:'Solo el nombre, sin kick.com/. Deja en blanco el que no uses. Puedes poner los dos a la vez'},
      {k:'chatroom', l:'Número de chatroom de Kick (casi nunca hace falta)', t:'text', def:'', ph:'(vacío = automático)', visibleSi:{canalkick:'*'},
        help:'Déjalo vacío. Solo si el desfile dice que falta: abre en el navegador kick.com/api/v2/channels/TUCANAL, busca "chatroom" y copia el número de "id" que va justo después'},
      {k:'demo', l:'Modo demo (chat de mentira)', t:'select', def:'no', o:SI_NO, ui:'interruptor', lPaso:'Modo demo: chat de mentira también en OBS', helpPaso:'Para grabar sin chat real. Apágalo antes de tu directo.', help:'Para probar o grabar sin chat real. En esta vista previa, si no hay canal, ya sale en demo'},
      {k:'max', l:'Máximo en pantalla', t:'num', def:10, min:1, max:25, step:1, ui:'botones', lPaso:'¿Cuántos a la vez?', helpPaso:'Si llega uno más, se va el que lleva más rato callado.',
        botones:[[5,'Hasta 5'],[10,'Hasta 10'],[20,'Hasta 20']], otro:'hasta {max}', fino:{menos:'Menos', mas:'Más'}},
      {k:'velocidad', l:'Velocidad al caminar', t:'num', def:1, min:0.3, max:3, step:0.1, ui:'botones', lPaso:'¿A qué velocidad caminan?',
        botones:[[0.6,'Lenta'],[1,'Normal'],[1.6,'Rápida']], fino:{menos:'Más lenta', mas:'Más rápida'}},
      {k:'duracion', l:'Segundos que se queda cada personaje', t:'num', def:120, min:15, max:900, step:5, ui:'botones', lPaso:'¿Cuánto se queda cada uno?', helpPaso:'Se cuenta desde su último mensaje.',
        botones:[[60,'1 min'],[120,'2 min'],[300,'5 min']], otro:'{duracion} segundos', fino:{menos:'Menos rato', mas:'Más rato'}, help:'Contados desde su último mensaje'},
      {k:'mensajes', l:'Mostrar globos con el mensaje', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Enseñar lo que escriben en un globo'},
      {k:'pos', l:'Por dónde caminan', t:'select', def:'abajo', ui:'botones', lPaso:'¿Por dónde caminan?', botones:[['abajo','Abajo'],['arriba','Arriba']], o:[['abajo','Abajo'],['arriba','Arriba']]},
      {k:'tamano', l:'Tamaño de los personajes', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?',
        botones:[[0.7,'Chicos'],[1,'Normal'],[1.4,'Grandes']], fino:{menos:'Más chicos', mas:'Más grandes'}},
      {k:'ignorar', l:'Ignorar estos usuarios', t:'text', def:'nightbot,streamelements,streamlabs,moobot,fossabot,wizebot,soundalerts,botrix,kickbot', lPaso:'Estos nombres no salen en el desfile', helpPaso:'Sepáralos con comas. Ya vienen los bots más comunes.', help:'Separados por comas (bots)'}
    ]},
  { id:'mascota', grupo:'chat', archivo:'Mascota.html', nombre:'Mascota navideña', transparente:true, demo:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Un personaje que vive en tu stream: saluda al chat, se ríe, baila con el hype y reacciona a los canjes de puntos del canal.',
    /* Botones «Probar» del PANEL (las 12 acciones) y acciones que se pueden asignar a un canje */
    acciones:[['saludar','Saludar'],['reir','Reír'],['celebrar','Celebrar'],['felizNavidad','Feliz Navidad'],['despedirse','Despedirse'],
      ['comerGalleta','Comer galleta'],['bailar','Bailar'],['bolaDeNieve','Bola de nieve'],['abrazo','Abrazo'],['siesta','Siesta'],
      ['abrirRegalo','Abrir regalo'],['cambiarDisfraz','Cambiar disfraz']],
    canjeables:['comerGalleta','bailar','bolaDeNieve','abrazo','siesta','abrirRegalo','cambiarDisfraz'],
    /* El PANEL enseña esta pieza en 3 pasos (campos con «paso») + «Ajustes finos» (el resto).
       Solo cambia la pantalla del PANEL: los parámetros y sus valores de fábrica son los mismos. */
    pasos:[
      {t:'Elige tu mascota', f:'Toca el personaje que más te guste y elige dónde sale y de qué tamaño.', campos:['disfraz','pos','tamano']},
      {t:'Cómo se porta', f:'Ya viene lista. Cambia solo lo que quieras.',
        campos:['saludar','reacciones','globos','paseo','saludar_streamer','hype_n','siesta_min','disfraz_min']},
      {t:'Tu chat y tus canjes', f:'Con tu canal la mascota ve tu chat y saluda a la gente. Con tu cuenta conectada, también tus followers y todos tus canjes de puntos.',
        twitch:{ sinCanal:'Sin tu canal la mascota no ve tu chat. Aquí en la vista previa hace cosas sola.', sinCodigo:'Tu chat ya funciona. Conecta tu cuenta para los followers y para los canjes que no piden texto.', listo:'✓ Listo: la mascota ve tu chat y tus canjes.', extra:'canjes' }, campos:[]}
    ],
    /* hype_s va con hype_n (los botones fijan los dos). login_eventos y t_* salen en el último paso con el código comprobado */
    avanzado:['ignorar','demo','canjes','palabras','aprender'],
    params:[ /* disfraces: santa, reno, duende, galleta, muneco. Avanzados (sin campo en el PANEL): vista=1, fps=1,
                y solo para pruebas en local: eventsub=ws://127.0.0.1…, helix=http://127.0.0.1…, bid=, clientid= */
      {k:'canal', l:'Canal de Twitch', t:'text', def:'', ph:'tucanal', help:'Solo el nombre, sin twitch.tv/. De aquí salen el chat, los canjes, los subs y los raids',
        lPaso:'Tu canal de Twitch', helpPaso:'Solo el nombre, tal como sale en twitch.tv/tucanal (sin twitch.tv/).'},
      {k:'canalkick', l:'Canal de Kick (opcional)', t:'text', def:'', ph:'tucanal', lPaso:'Tu canal de Kick', helpPaso:'Solo el nombre, sin kick.com/.', help:'Solo el nombre, sin kick.com/. La mascota también reacciona al chat de Kick (los canjes y los subs son solo de Twitch)'},
      {k:'chatroom', l:'Número de chatroom de Kick (casi nunca hace falta)', t:'text', def:'', ph:'(vacío = automático)', visibleSi:{canalkick:'*'},
        help:'Déjalo vacío. Solo si la mascota dice que falta: abre en el navegador kick.com/api/v2/channels/TUCANAL, busca "chatroom" y copia el número de "id" que va justo después'},
      {k:'disfraz', l:'Disfraz', t:'select', def:'santa', ui:'tarjetas', o:[['santa','Santa'],['reno','Reno'],['duende','Duende'],['galleta','Galleta de jengibre'],['muneco','Muñeco de nieve'],['azar','Al azar cada día']]},
      {k:'disfraz_min', l:'Minutos con un disfraz de canje', t:'num', def:3, min:1, max:60, step:1, ui:'botones', lPaso:'Si un canje le cambia el disfraz, vuelve al suyo a los…',
        botones:[[1,'1 min'],[3,'3 min'],[10,'10 min']], otro:'{disfraz_min} min', help:'Cuando un canje le cambia el disfraz, a los tantos minutos vuelve al suyo'},
      {k:'pos', l:'Posición', t:'select', def:'abajo-der', ui:'botones', lPaso:'¿Dónde sale?', botones:[['abajo-izq','Izquierda'],['abajo-centro','Centro'],['abajo-der','Derecha']], o:[['abajo-der','Abajo a la derecha'],['abajo-izq','Abajo a la izquierda'],['abajo-centro','Abajo al centro']]},
      {k:'tamano', l:'Tamaño', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?', botones:[[0.7,'Chica'],[1,'Normal'],[1.4,'Grande']]},
      {k:'paseo', l:'Pasea un poco cuando está tranquila', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Pasea cuando está tranquila'},
      {k:'globos', l:'Globos de texto', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Habla con globos de texto'},
      {k:'saludar', l:'Saluda a quien escribe por primera vez', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'saludar_streamer', l:'También reacciona a tus mensajes (los del streamer)', t:'select', def:'no', o:SI_NO, ui:'interruptor', lPaso:'También reacciona a lo que escribes tú',
        help:'Con «No» ignora lo que escribes tú en el chat. Tus canjes, subs y raids sí cuentan'},
      {k:'reacciones', l:'Reacciona al chat (jaja, gg, feliz navidad, <3…)', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Reacciona al chat: jaja, gg, feliz navidad…'},
      {k:'hype_n', l:'Mensajes para el modo fiesta', t:'num', def:12, min:3, max:100, step:1, ui:'botones', lPaso:'Modo fiesta', helpPaso:'Cuando el chat se anima, baila y echa destellos.',
        botones:[[{hype_n:25,hype_s:20},'Le cuesta'],[{hype_n:12,hype_s:20},'Normal'],[{hype_n:6,hype_s:20},'Se anima rápido']], otro:'{hype_n} en {hype_s} s', help:'Si llegan tantos mensajes seguidos, baila y echa destellos. Se le pasa unos 12 s después de que el chat se calma'},
      {k:'hype_s', l:'…en cuántos segundos', t:'num', def:20, min:5, max:120, step:1},
      {k:'siesta_min', l:'Minutos sin nada para echarse una siesta', t:'num', def:5, min:0, max:60, step:1, ui:'botones', lPaso:'Siesta', helpPaso:'Se duerme sola cuando no pasa nada en tu chat.',
        botones:[[0,'Nunca'],[5,'A los 5 min'],[15,'A los 15 min'],[30,'A los 30 min']], otro:'{siesta_min} min', help:'0 = nunca se duerme sola'},
      {k:'demo', l:'Modo demo', t:'select', def:'no', o:SI_NO, help:'Hace acciones solas para probar o grabar. En esta vista previa, si no hay canal, ya sale en demo'},
      {k:'ignorar', l:'Ignorar estos usuarios', t:'text', def:'nightbot,streamelements,streamlabs,moobot,fossabot,wizebot,soundalerts,botrix,kickbot', help:'Separados por comas (bots)'},
      {k:'canjes', l:'Canjes de puntos → acción', t:'mapa', def:'', ph:'3f9c1a2b:bailar, 7d4e5f60:siesta', widget:'escuchar-canjes',
        aviso:'Sin la conexión con Twitch solo funcionan los canjes que piden texto al espectador: créalos en Twitch con «Pedir texto al espectador» activado. Con la conexión valen todos.',
        help:'Lo arma el botón «Escuchar canjes» de aquí abajo. Cada canje va como id:acción, separados por comas; basta con los 8 primeros caracteres del id. Acciones: comergalleta, bailar, boladenieve, abrazo, siesta, abrirregalo, cambiardisfraz'},
      {k:'palabras', l:'Palabras en el texto del canje → acción', t:'palabras', def:'galleta:comergalleta,baile:bailar,bola:boladenieve,abrazo:abrazo,siesta:siesta,regalo:abrirregalo,disfraz:cambiardisfraz',
        ph:'galleta:comergalleta, baile:bailar',
        help:'Si el canje no está en la lista de arriba, se busca la palabra en lo que escribió el viewer: palabra:acción, separadas por comas'},
      {k:'aprender', l:'Enseñar el id de cada canje (para configurar)', t:'select', def:'no', o:SI_NO,
        help:'Con «Sí», cada canje sale 20 s en una esquina con su id. Ponlo en «No» cuando termines. Si un canje no coincide con nada: con «No» la mascota celebra y da las gracias'},
      {k:'token', l:'Conexión con Twitch (opcional)', t:'token', def:'', ph:'pega aquí tu código',
        help:'Solo hace falta para follows, hype train y canjes sin texto (los subs, bits y raids ya llegan sin conexión; con ella no salen repetidos). Consíguelo con «Conseguir token». Nunca lo enseñes en directo'},
      {k:'login_eventos', l:'Con la conexión, reaccionar a…', t:'lista', def:'follow,sub,bits,raid,hype,canje', visibleSi:{token:'*'},
        lPaso:'Avisa cuando…', helpPaso:'Si quitas subs, bits o raids, igual los ve por el chat.',
        o:[['follow','Follows'],['sub','Subs y regalos'],['bits','Bits'],['raid','Raids'],['hype','Hype train'],['canje','Canjes de puntos']],
        help:'Lo que desmarques no se pide a Twitch. Los subs, bits y raids desmarcados siguen llegando como sin conexión (por el chat)'},
      {k:'t_follow', l:'Globo cuando alguien te sigue', t:'text', def:'¡Gracias por seguir, {nombre}!', visibleSi:{token:'*'}, help:'{nombre} = quien te sigue'},
      {k:'t_sub', l:'Globo de sub', t:'text', def:'¡Gracias por el sub, {nombre}!', visibleSi:{token:'*'}, help:'{nombre} = quien se suscribe'},
      {k:'t_bits', l:'Globo de bits', t:'text', def:'¡Gracias por los {n} bits, {nombre}!', visibleSi:{token:'*'}, help:'{n} = cuántos bits'},
      {k:'t_raid', l:'Globo de raid', t:'text', def:'¡Bienvenida, tropa de {nombre}!', visibleSi:{token:'*'}, help:'{nombre} = quien te raidea · {n} = cuántos llegan'}
    ]},
  /* ── Decoración ── */
  { id:'guirnalda', grupo:'deco', archivo:'Guirnalda de luces.html', nombre:'Guirnalda de luces', transparente:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Tira de luces navideñas con ramitas de pino y adornos colgando (calcetas, bastones, estrellas o bolas). Va arriba o abajo de la pantalla.',
    pasos:[
      {t:'Los adornos', f:'Toca lo que quieres que cuelgue de la tira.', campos:['colgantes','pino']},
      {t:'Las luces', f:'Elige los colores y cómo parpadean.', campos:['paleta','parpadeo']},
      {t:'¿Dónde va?', f:'Arriba o abajo de la pantalla, y de qué tamaño.', campos:['pos','escala']}
    ],
    avanzado:['brillo'],
    avanzadoNota:'· cuánto brillan las luces',
    params:[
      {k:'pos', l:'Posición', t:'select', def:'arriba', ui:'botones', lPaso:'¿Arriba o abajo?', botones:[['arriba','Arriba'],['abajo','Abajo']], o:[['arriba','Arriba'],['abajo','Abajo']]},
      {k:'colgantes', l:'Adornos colgando', t:'select', def:'calcetas', ui:'tarjetas', lPaso:'¿Qué cuelga?', mini:miniColgante, nombres:{bastones:'Bastones', bolas:'Bolas'}, o:[['calcetas','Calcetas'],['bastones','Bastones de caramelo'],['estrellas','Estrellas'],['bolas','Bolas de árbol'],['ninguno','Sin adornos']]},
      {k:'paleta', l:'Colores de las luces', t:'select', def:'clasica', ui:'tarjetas', lPaso:'¿De qué color son las luces?', mini:miniPaleta, nombres:NOMBRES_PALETA, o:[['clasica','Clásica (multicolor)'],['calida','Cálida (blanco y dorado)'],['rojoverde','Rojo y verde'],['fria','Fría (azul y blanco)']]},
      {k:'pino', l:'Ramitas de pino', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Con ramitas de pino'},
      {k:'parpadeo', l:'Parpadeo', t:'select', def:'suave', ui:'botones', lPaso:'¿Cómo parpadean?', botones:[['suave','Suave'],['secuencia','Una tras otra'],['ninguno','Fijas']], o:[['suave','Suave'],['secuencia','En secuencia (persecución)'],['ninguno','Fijas, sin parpadeo']]},
      {k:'brillo', l:'Brillo', t:'num', def:1, min:0.2, max:2, step:0.1, ui:'botones', lPaso:'¿Cuánto brillan?', botones:[[0.6,'Poco'],[1,'Normal'],[1.6,'Mucho']], fino:{menos:'Menos', mas:'Más'}},
      {k:'escala', l:'Tamaño', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?', botones:[[0.7,'Chica'],[1,'Normal'],[1.4,'Grande']], fino:{menos:'Más chica', mas:'Más grande'}}
    ]},
  { id:'nieve', grupo:'deco', archivo:'Nieve.html', nombre:'Nieve', transparente:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Capa de nieve cayendo encima de todo, con copos cerca y lejos. Opcional: una franja baja de nieve que se va juntando abajo y un duende que pasa con su quitanieves a bajarla.',
    /* Botón «Probar» del PANEL (la pieza lo recibe por postMessage con vista=1). probarSi: cuándo se ve */
    acciones:[['duende','Que pase el duende']],
    probarSi:{acumula:'si', duende:'si'},
    probarTxt:'Solo en esta vista previa. En tu directo pasa cuando la nieve llega arriba.',
    pasos:[
      {t:'Cuánta nieve', f:'Ya viene lista. Cambia solo lo que quieras.', campos:['intensidad','tam']},
      {t:'Cómo cae', f:'Elige hacia dónde la lleva el viento y si se junta abajo.', campos:['viento','acumula','duende','duende_cada']}
    ],
    avanzado:['semilla'],
    avanzadoNota:'· dónde cae cada copo',
    params:[
      {k:'intensidad', l:'Cantidad de nieve', t:'num', def:1, min:0.3, max:3, step:0.1, ui:'botones', lPaso:'¿Cuánta nieve cae?', botones:[[0.5,'Poca'],[1,'Normal'],[2,'Mucha'],[3,'Ventisca']], fino:{menos:'Menos', mas:'Más'}, help:'0.3 = unos pocos copos · 3 = ventisca'},
      {k:'viento', l:'Viento', t:'num', def:0.2, min:-1, max:1, step:0.1, ui:'botones', lPaso:'¿Hacia dónde sopla el viento?', botones:[[-0.6,'A la izquierda'],[0,'Sin viento'],[0.2,'Un poco a la derecha'],[0.6,'A la derecha']], fino:{menos:'Izquierda', mas:'Derecha'}, help:'Negativo = hacia la izquierda · 0 = cae recta'},
      {k:'tam', l:'Tamaño de los copos', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño son los copos?', botones:[[0.7,'Chicos'],[1,'Normal'],[1.5,'Grandes']], fino:{menos:'Más chicos', mas:'Más grandes'}},
      {k:'acumula', l:'Nieve que se junta abajo', t:'select', def:'no', o:SI_NO, ui:'interruptor', lPaso:'Se junta nieve abajo', helpPaso:'Una franja baja, sin tapar tu juego.'},
      {k:'duende', l:'Duende con quitanieves', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Pasa un duende quitando la nieve', helpPaso:'Cruza con su maquinita cuando la nieve llega arriba. Baja mucho, pero nunca la deja vacía.', visibleSi:{acumula:'si'}},
      {k:'duende_cada', l:'Minutos entre pasadas del duende', t:'num', def:4.5, min:1, max:15, step:0.5, ui:'botones', lPaso:'¿Cada cuánto pasa el duende?', botones:[[2,'Cada 2 minutos'],[4.5,'Cada 4 minutos y medio'],[8,'Cada 8 minutos']], fino:{menos:'Más seguido', mas:'Menos seguido'}, visibleSi:{acumula:'si', duende:'si'}, help:'La nieve tarda eso en volver a llenarse'},
      {k:'semilla', l:'Variante', t:'num', def:7, min:1, max:99, step:1, lPaso:'Variante de la nieve', help:'Cambia dónde cae cada copo'}
    ]},
  { id:'arbol', grupo:'deco', archivo:'Arbol de Navidad.html', nombre:'Árbol de Navidad', transparente:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Un arbolito con luces, bolas, estrella en la punta y regalos debajo, en una esquina de abajo de la pantalla. Cada donación de bits cuelga una bola y cada sub pone un regalo con su nombre.',
    /* Botones «Probar» del PANEL (la pieza los recibe por postMessage con vista=1) */
    acciones:[['bits','Donar bits'],['bitsGrande','Donar muchos bits'],['sub','Sub']],
    probarTxt:'Mira cómo llega cada bola y cada regalo. Estas pruebas no se guardan.',
    pasos:[
      {t:'Cómo se ve', f:'Ya viene listo. Cambia solo lo que quieras.', campos:['pos','tamano','luces','adornos','color_adornos','regalos','nombres','nieve']},
      {t:'Tu canal', f:'Cada donación de bits cuelga una bola y cada sub pone un regalo. No hay que conectar nada más.', twitch:{ sinCanal:'Sin tu canal es un árbol decorado: no recibe bits ni subs.' }, campos:[]}
    ],
    avanzado:['parpadeo','bits_grande','demo','vaciar'],
    avanzadoNota:'· parpadeo, bolas grandes, vaciar el árbol y otro canal',
    params:[ /* canal, nombres, bits_grande, demo y vaciar: tanda de feedback (05-nov). Sin canal se ve igual que siempre */
      {k:'canal', l:'Canal de Twitch', t:'text', def:'', ph:'tucanal', help:'Solo el nombre, sin twitch.tv/. Vacío = árbol decorativo, sin donaciones',
        lPaso:'Tu canal de Twitch', helpPaso:'Solo el nombre, tal como sale en twitch.tv/tucanal (sin twitch.tv/).', listo:'✓ Listo: el árbol ve las donaciones de {canal}.'},
      {k:'pos', l:'Esquina', t:'select', def:'izq', ui:'botones', lPaso:'¿En qué esquina?', botones:[['izq','Izquierda'],['der','Derecha']], o:[['izq','Abajo a la izquierda'],['der','Abajo a la derecha']]},
      {k:'tamano', l:'Tamaño', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?', botones:[[0.7,'Chico'],[1,'Normal'],[1.4,'Grande']], help:'1 = medio alto de la pantalla · 2 = casi toda la altura'},
      {k:'luces', l:'Colores de las luces', t:'select', def:'clasica', ui:'botones', lPaso:'Colores de las luces', botones:[['clasica','Muchos colores'],['calida','Cálidas'],['rojoverde','Rojo y verde'],['fria','Frías']], o:[['clasica','Clásica (multicolor)'],['calida','Cálida (blanco y dorado)'],['rojoverde','Rojo y verde'],['fria','Fría (azul y blanco)']]},
      {k:'parpadeo', l:'Parpadeo de las luces', t:'select', def:'suave', o:[['suave','Suave'],['secuencia','En secuencia (persecución)'],['ninguno','Fijas, sin parpadeo']]},
      {k:'adornos', l:'Bolas del árbol', t:'select', def:'variados', ui:'botones', lPaso:'Bolas del árbol', botones:[['variados','De colores'],['color','De un color'],['ninguno','Sin bolas']], o:[['variados','De muchos colores'],['color','De un solo color'],['ninguno','Sin bolas']]},
      {k:'color_adornos', l:'Color de las bolas', t:'color', def:'e8424f', visibleSi:{adornos:'color'}},
      {k:'nieve', l:'Nieve en las ramas', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'regalos', l:'Regalos debajo', t:'num', def:3, min:0, max:5, step:1, ui:'botones', lPaso:'Regalos al empezar', helpPaso:'Los subs ponen los suyos encima, hasta 5.', botones:[[0,'Ninguno'],[3,'3'],[5,'5']], otro:'{regalos}', help:'0 = sin regalos. Los subs nuevos se ponen igual, hasta 5'},
      {k:'nombres', l:'Enseñar los nombres', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Da las gracias con el nombre', help:'Con «No» no sale el globo de gracias ni la etiqueta de los regalos'},
      {k:'bits_grande', l:'Bits para una bola grande', t:'num', def:500, min:100, max:10000, step:100, help:'Desde tantos bits en una sola donación, la bola sale más grande, dorada y con brillo'},
      {k:'demo', l:'Modo demo', t:'select', def:'no', o:SI_NO, help:'Llegan donaciones de mentira para probar o grabar. No se guardan. En esta vista previa, si no hay canal, ya sale en demo'},
      {k:'vaciar', l:'Vaciar el árbol', t:'text', def:'', ui:'vaciar', help:'Lo pone el botón del PANEL: si cambia este valor, el árbol borra sus donaciones una vez y vuelve a sus adornos'}
    ]},
  { id:'chimenea', grupo:'deco', archivo:'Chimenea y calcetas.html', nombre:'Chimenea y calcetas', transparente:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Chimenea de ladrillo con fuego y calcetas colgando con los nombres de tus últimos followers o suscriptores, o los que tú escribas. O solo la repisa con las calcetas, para el borde de arriba.',
    /* a[2]: el rótulo cambia según otra opción (con «Suscripciones», «Nuevo suscriptor») */
    acciones:[['follow','Nuevo follower', { k:'llenar', v:{ subs:'Nuevo suscriptor' } }]],
    probarTxt:'Mira cómo cambia la calceta más vieja. Esta prueba no se guarda.',
    pasos:[
      {t:'Cómo se ve', f:'Ya viene lista. Cambia solo lo que quieras.', campos:['modo','pos','pos_repisa','tamano','fuego','velas','colores','colores_propios']},
      {t:'Tus followers', f:'Cada calceta lleva el nombre de alguien que te sigue. Cuando llega uno nuevo, reemplaza al más viejo.',
        twitch:{ sinCodigo:'Conecta tu cuenta y las calcetas se llenan solas con tus últimos followers.', listo:'✓ Listo: las calcetas llevan tus últimos followers.', extra:'followers', sinTitulo:'Si no quieres conectar', sinTexto:'Si no conectas, escribe aquí los nombres.', manual:'nombres' }, campos:['llenar','cuantas'],
        /* 11-nov: con llenar=subs el paso cambia de título, de texto y de línea de Twitch (el PANEL lo cambia en vivo) */
        alt:{ k:'llenar', v:'subs', t:'Tus suscriptores', f:'Cada calceta lleva el nombre de alguien que se suscribe. También cuentan los que renuevan y los regalos (sale quien regala). Cuando llega uno nuevo, reemplaza al más viejo.',
          twitch:{ sinCanal:'Pon tu canal y las calcetas se llenan con tus nuevos suscriptores, sin conectar nada más.', sinCodigo:'', listo:'✓ Listo: las calcetas llevan tus nuevos suscriptores.', extra:'subs', sinTitulo:'Mientras no llegue nadie', sinTexto:'Escribe aquí los nombres que quieres ver hasta que llegue el primero.', manual:'nombres' } }}
    ],
    avanzado:['regalos'],
    avanzadoNota:'· regalos al lado y no usar tus canales',
    params:[ /* token: tanda de feedback (05-nov). Avanzados solo para pruebas en local, sin campo en el PANEL: eventsub=, helix=, bid=, clientid= */
      /* llenar y canal: 11-nov. canal solo cuenta con «Suscripciones» (sin conexión, los subs llegan por el chat); con followers no va en el link */
      {k:'llenar', l:'Quién va en las calcetas', t:'select', def:'followers', ui:'botones', lPaso:'¿Quién va en las calcetas?', helpPaso:'Puedes cambiarlo cuando quieras.',
        botones:[['followers','Followers'],['subs','Suscripciones']], o:[['followers','Tus últimos followers'],['subs','Tus últimos suscriptores (subs, renovaciones y regalos)']]},
      {k:'canal', l:'Canal de Twitch (para los suscriptores)', t:'text', def:'', ph:'tucanal', visibleSi:{llenar:'subs'},
        help:'Solo el nombre, sin twitch.tv/. Con «Suscripciones» y sin conectar tu cuenta, los subs llegan por el chat de este canal', listo:'✓ Listo: las calcetas llevan los nuevos suscriptores de {canal}.'},
      {k:'modo', l:'Qué mostrar', t:'select', def:'chimenea', ui:'botones', lPaso:'¿Qué quieres mostrar?', botones:[['chimenea','Chimenea completa'],['repisa','Solo la repisa']], o:[['chimenea','Chimenea completa (en una esquina de abajo)'],['repisa','Solo la repisa con calcetas (arriba)']]},
      {k:'pos', l:'Esquina', t:'select', def:'izq', ui:'botones', lPaso:'¿En qué esquina?', botones:[['izq','Izquierda'],['der','Derecha']], o:[['izq','Abajo a la izquierda'],['der','Abajo a la derecha']], visibleSi:{modo:'chimenea'}},
      {k:'pos_repisa', l:'Dónde va la repisa', t:'select', def:'centro', ui:'botones', lPaso:'¿Dónde va la repisa?', botones:[['izq','Izquierda'],['centro','Centro'],['der','Derecha']], o:[['izq','Arriba a la izquierda'],['centro','Arriba al centro'],['der','Arriba a la derecha']], visibleSi:{modo:'repisa'}},
      {k:'tamano', l:'Tamaño', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?', botones:[[0.7,'Chica'],[1,'Normal'],[1.4,'Grande']]},
      {k:'fuego', l:'Fuego encendido', t:'select', def:'si', o:SI_NO, ui:'interruptor', visibleSi:{modo:'chimenea'}},
      {k:'nombres', l:'Nombres en las calcetas', t:'text', def:'', ph:'Ana, Luis, Mods', lPaso:'Nombres de las calcetas', helpPaso:'Hasta 5, separados por comas.', help:'Hasta 5, separados por comas (10 letras como mucho cada uno). Vacío = calcetas sin nombre'},
      {k:'cuantas', l:'Cuántas calcetas (si no pones nombres)', t:'num', def:3, min:1, max:5, step:1, ui:'botones', lPaso:'¿Cuántas calcetas?', botones:[[1,'1'],[2,'2'],[3,'3'],[4,'4'],[5,'5']]},
      {k:'token', l:'Conexión con Twitch (opcional)', t:'token', def:'', ph:'pega aquí tu código', help:'Con ella las calcetas llevan tus últimos followers (o suscriptores) y se cambian solas. Nunca enseñes este código en directo'},
      {k:'colores', l:'Colores de las calcetas', t:'select', def:'clasica', ui:'botones', botones:[['clasica','Rojo, verde y blanco'],['rojas','Rojas'],['verdes','Verdes'],['pastel','Pastel'],['propios','Mis colores']], o:[['clasica','Rojo, verde y blanco'],['rojas','Rojas'],['verdes','Verdes'],['pastel','Pastel'],['propios','Mis colores']]},
      {k:'colores_propios', l:'Mis colores', t:'text', def:'e8424f, 2f8f5b, ffcf5c', ph:'e8424f, 2f8f5b, ffcf5c', ui:'colores', lPaso:'Elige tus colores', helpPaso:'Uno por calceta, hasta 5. Si hay más calcetas, se repiten.', visibleSi:{colores:'propios'}, help:'Códigos de color (hex) separados por comas, uno por calceta'},
      {k:'velas', l:'Velas encima de la repisa', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'regalos', l:'Regalos al lado', t:'num', def:2, min:0, max:4, step:1, visibleSi:{modo:'chimenea'}, help:'0 = sin regalos'}
    ]},
  { id:'marco', grupo:'deco', archivo:'Marco de webcam.html', nombre:'Marco de webcam', transparente:true,
    lienzo:function(v){ return v && v.formato === '4x3' ? [960, 720] : [1280, 720]; },
    tam:'1280 × 720 (16:9) o 960 × 720 (4:3)',
    desc:'Marco navideño para tu cámara: nieve encima, luces alrededor, adornos en las esquinas y un reno o una galleta que se asoma de vez en cuando. Ponlo encima de tu cámara.',
    pasos:[
      {t:'Tu cámara', f:'Casi todas son anchas. Si la tuya se ve más cuadrada, cámbialo aquí.', campos:['formato'],
        alt:{ k:'orientacion', v:'vertical', t:'Tu cámara', f:'En vertical el marco rodea toda la pantalla, para la cámara a pantalla completa. Si tu cámara ocupa menos, achica el marco en OBS.' }},
      {t:'El marco', f:'Elige los colores y el grosor. Si quieres, pon tu nombre.', campos:['marco','color','grosor','etiqueta']},
      {t:'Los adornos', f:'Ya vienen puestos. Cambia solo lo que quieras.', campos:['esquinas','luces','nieve','paleta']},
      {t:'Quién se asoma', f:'De vez en cuando sube por un borde, mira a los lados y se esconde.', campos:['asoma','cada']}
    ],
    /* Probar: recarga la vista previa y a los 2 segundos se asoma. La pieza no escucha mensajes */
    probarVista:{ t:'Que se asome ahora', visibleSi:{asoma:['reno','galleta']}, nota:'Tarda un par de segundos. En tu directo se asoma según lo que elijas en «¿Cada cuánto?».' },
    params:[
      {k:'formato', l:'Formato de tu cámara', t:'select', def:'16x9', ui:'botones', visibleSi:{orientacion:'horizontal'}, lPaso:'¿Cómo es tu cámara?', botones:[['16x9','Ancha (16:9)'],['4x3','Más cuadrada (4:3)']], o:[['16x9','16:9 (1280 × 720)'],['4x3','4:3 (960 × 720)']]},
      {k:'marco', l:'Color del marco', t:'color', def:'e8424f'},
      {k:'color', l:'Color del brillo', t:'color', def:'ffcf5c', help:'También es el color de la etiqueta'},
      {k:'grosor', l:'Grosor del marco', t:'num', def:1, min:0.4, max:2.5, step:0.1, ui:'botones', lPaso:'¿Qué tan grueso?', botones:[[0.6,'Delgado'],[1,'Normal'],[1.6,'Grueso']], fino:{menos:'Más delgado', mas:'Más grueso'}},
      {k:'etiqueta', l:'Texto en el marco', t:'text', def:'', ph:'@tucanal', helpPaso:'Por ejemplo tu @. Déjalo vacío si no quieres texto.', help:'Vacío = sin etiqueta'},
      {k:'nieve', l:'Nieve encima del marco', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'luces', l:'Luces alrededor', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'paleta', l:'Colores de las luces', t:'select', def:'clasica', ui:'tarjetas', lPaso:'¿De qué color son las luces?', mini:miniPaleta, nombres:NOMBRES_PALETA, o:[['clasica','Clásica (multicolor)'],['calida','Cálida (blanco y dorado)'],['rojoverde','Rojo y verde'],['fria','Fría (azul y blanco)']], visibleSi:{luces:'si'}},
      {k:'esquinas', l:'Adorno de las esquinas', t:'select', def:'acebo', ui:'tarjetas', lPaso:'¿Qué adorno lleva?', mini:miniEsquina, nombres:{muerdago:'Muérdago', bastones:'Bastones'}, o:[['acebo','Acebo'],['muerdago','Muérdago colgando'],['bastones','Bastones de caramelo'],['ninguna','Sin adorno']]},
      {k:'asoma', l:'Personaje que se asoma', t:'select', def:'reno', ui:'tarjetas', lPaso:'¿Quién se asoma?', mini:miniAsoma, nombres:{galleta:'Galleta', ninguno:'Nadie'}, o:[['reno','Reno'],['galleta','Galleta de jengibre'],['ninguno','Ninguno']]},
      {k:'cada', l:'Cada cuántos minutos se asoma', t:'num', def:3, min:0.1, max:60, step:0.1, ui:'botones', lPaso:'¿Cada cuánto?', botones:[[1,'Cada minuto'],[3,'Cada 3 min'],[10,'Cada 10 min']], otro:'cada {cada} min', fino:{menos:'Más seguido', mas:'Menos seguido'}, visibleSi:{asoma:['reno','galleta']},
        help:'Sube por un borde, mira a los lados y se esconde. En esta vista previa se asoma cada 10 s'}
    ]},
  { id:'cuenta', grupo:'deco', archivo:'Cuenta para Navidad.html', nombre:'Cuenta para Navidad', transparente:true,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Cartelito con nieve encima que dice cuántos días faltan para Navidad (o para la fecha que elijas). El último día cuenta en horas y el día de la fecha dice ¡Feliz Navidad!',
    pasos:[
      {t:'¿Para cuándo?', f:'Toca la fecha. El cartel cuenta solo y ese día felicita.', campos:['fecha','region']},
      {t:'¿Dónde sale?', f:'Elige el rincón de la pantalla y el tamaño.', campos:['pos','tamano']},
      {t:'Su estilo', f:'El borde del cartel y su adornito.', campos:['acento','adorno']}
    ],
    /* Plegado con lo que dice el cartel: el número va en una pastilla, sin {n} a la vista */
    textos:{ t:'Cambiar los textos', nota:'· lo que dice el cartel' },
    params:[ /* avanzado, solo para pruebas (sin campo en el PANEL): ahora=AAAA-MM-DDTHH:MM simula la fecha y hora */
      {k:'fecha', l:'Fecha', t:'text', def:'12-25', ph:'12-25', ui:'fecha', help:'Mes-día (12-25 = Navidad, cada año). Con año (2026-12-31) cuenta hasta esa fecha exacta',
        /* Tarjetas del paso 1. Al cambiar de fecha, los textos que sigan siendo de fábrica cambian con ella */
        fechas:[
          {v:'12-25', t:'Navidad', s:'25 dic', dib:'pino', plantilla:'Faltan {n} días para Navidad', texto_dia:'¡Feliz Navidad!'},
          {v:'12-24', t:'Nochebuena', s:'24 dic', dib:'estrella', plantilla:'Faltan {n} días para Nochebuena', texto_dia:'¡Feliz Nochebuena!'},
          {v:'01-01', t:'Año Nuevo', s:'1 ene', dib:'chispas', plantilla:'Faltan {n} días para Año Nuevo', texto_dia:'¡Feliz Año Nuevo!'}
        ],
        otra:{ t:'Otra fecha', s:'tú eliges', dib:'regalo', plantilla:'Faltan {n} días', texto_dia:'¡Llegó el día!' }},
      /* 11-nov: la cuenta llega a cero a las 00:00 de la fecha en esa región, aunque la PC tenga otra hora */
      {k:'region', l:'Región (para la hora)', t:'select', def:'cdmx', lPaso:'¿Con la hora de dónde?', reloj:true,
        helpPaso:'Llega a cero a las 12 de la noche de ese lugar. El horario de verano se ajusta solo.',
        help:'Llega a cero a las 12 de la noche de ese lugar. El horario de verano se ajusta solo',
        o:HW.REGIONES.map(function(r){ return [r[0], r[1]]; }), grupos:HW.REGIONES.map(function(r){ return r[3]; })},
      {k:'plantilla', l:'Texto', t:'text', def:'Faltan {n} días para Navidad', help:'{n} = días que faltan. Con 1 dice «Falta 1 día» solo'},
      {k:'plantilla_horas', l:'Texto del último día', t:'text', def:'Faltan {h} horas', help:'Cuando falta menos de un día. {h} = horas que faltan'},
      {k:'texto_dia', l:'Texto del día', t:'text', def:'¡Feliz Navidad!', help:'Lo que dice el mismo día de la fecha'},
      {k:'pos', l:'Posición', t:'select', def:'arriba-der', ui:'botones', lPaso:'¿En qué rincón?', botones:[['arriba-izq','Arriba izquierda'],['arriba-der','Arriba derecha'],['abajo-izq','Abajo izquierda'],['abajo-der','Abajo derecha'],['centro','Al centro']], o:[['arriba-der','Arriba a la derecha'],['arriba-izq','Arriba a la izquierda'],['abajo-der','Abajo a la derecha'],['abajo-izq','Abajo a la izquierda'],['centro','Al centro']]},
      {k:'tamano', l:'Tamaño', t:'num', def:1, min:0.5, max:2, step:0.1, ui:'botones', lPaso:'¿De qué tamaño?', botones:[[0.7,'Chico'],[1,'Normal'],[1.4,'Grande']]},
      {k:'acento', l:'Color del borde', t:'color', def:'e8424f', lPaso:'Color del borde del cartel'},
      {k:'adorno', l:'Adornito', t:'select', def:'estrella', ui:'tarjetas', lPaso:'Su adornito', mini:miniAdorno, nombres:{ninguno:'Sin adornito'}, o:[['estrella','Estrella'],['acebo','Acebo'],['ninguno','Ninguno']]}
    ]},
  /* ── Fondos (cada uno: ?modo=pantalla|fondo) ── */
  { id:'fondo-jengibre', grupo:'fondo', archivo:'Fondo - Casa de jengibre.html', nombre:'Fondo: Casa de jengibre', transparente:false,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Dentro de una casita de jengibre: pared de galleta, ventana de caramelo con nieve (y una cocina gigante al otro lado), chimenea encendida y lámpara de piruleta. Con texto (Empezamos / Vuelvo / Fin) o limpio para poner tu cámara o el juego encima.',
    pasos:[
      {t:'Qué pantalla es', f:'Elige si lleva texto o si es un fondo limpio para tu cámara o tu juego.', campos:['modo','tipo','titulo','subtitulo','cuenta','minutos']},
      {t:'La casita', f:'Ya viene lista. Cambia solo lo que quieras.', campos:['fuego','guirnalda','luz','acento','nieve']}
    ],
    params:camposFondo([
      {k:'fuego', l:'Chimenea encendida', t:'select', def:'si', o:SI_NO, ui:'interruptor'},
      {k:'luz', l:'Luz', t:'select', def:'calida', ui:'botones', lPaso:'¿Qué luz tiene?', botones:[['calida','De noche'],['atardecer','Atardecer']], o:[['calida','Cálida (de noche)'],['atardecer','Atardecer (luz de caramelo por la ventana)']]}
    ], {
      acento:{ lPaso:'Color de la decoración', helpPaso:'Pinta las columnas de caramelo, la guirnalda, la alfombra, los regalos y las bolas del árbol. También el cartel.' },
      modo:{ ui:'botones', lPaso:'¿Lleva texto?', botones:[['pantalla','Con texto'],['fondo','Fondo limpio']] },
      tipo:{ ui:'botones', lPaso:'¿Qué pantalla es?', botones:[['soon','Empezamos pronto'],['brb','Vuelvo enseguida'],['ending','Fin del directo']] },
      titulo:{ ph:'(el que ya trae)', helpPaso:'Déjalo vacío y sale el que ya trae cada pantalla.' },
      subtitulo:{ ph:'(el que ya trae)', helpPaso:'Igual: si lo dejas vacío sale el que ya trae.' },
      cuenta:{ ui:'interruptor', lPaso:'Con cuenta atrás' },
      minutos:{ ui:'botones', lPaso:'¿Cuántos minutos de cuenta?', botones:[[3,'3 min'],[5,'5 min'],[10,'10 min'],[15,'15 min']], otro:'{minutos} min', fino:{menos:'Menos', mas:'Más'} },
      nieve:{ ui:'botones', lPaso:'¿Cuánta nieve se ve por la ventana?', botones:[[0,'Nada'],[0.3,'Poca'],[0.6,'Normal'],[1.5,'Mucha'],[3,'Tormenta']], fino:{menos:'Menos', mas:'Más'} },
      guirnalda:{ ui:'interruptor', lPaso:'Guirnalda arriba' }
    })},
  { id:'fondo-cocina', grupo:'fondo', archivo:'Fondo - Cocina de Navidad.html', nombre:'Fondo: Cocina de Navidad', transparente:false,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Cocina navideña: la Sra. Claus cocina paso a paso una casita de jengibre en el mostrador, desde la harina hasta las gomitas. Con texto (Empezamos / Vuelvo / Fin) sobre una pizarra, o limpio para poner tu cámara o el juego encima.',
    acciones:[['reiniciar','Desde el principio'],['etapa2','Masa'],['etapa3','Rodillo'],['etapa4','Cortar'],['etapa5','Horno'],['etapa6','Armar'],['etapa7','Glasear'],['etapa8','Gomitas'],['etapa9','Casa lista']],
    probarTxt:'Salta a cada momento de la cocina. Solo en esta vista previa: no cambia nada de tu directo.',
    pasos:[
      {t:'Qué pantalla es', f:'Elige si lleva texto o si es un fondo limpio para tu cámara o tu juego.', campos:['modo','tipo','titulo','subtitulo','cuenta','minutos']},
      {t:'La cocina', f:'La Sra. Claus empieza con el mostrador limpio y termina con la casa lista. Si la pantalla tiene cuenta atrás, acaba justo en el cero.', campos:['cocina','repetir','cocina_min','reiniciar','acento']}
    ],
    avanzado:['ventana','horno','nieve','guirnalda'],
    avanzadoNota:'· ventana, horno, nieve y guirnalda',
    params:camposFondo([
      {k:'ventana', l:'Por la ventana', t:'select', def:'noche', o:[['noche','Noche (luna y estrellas)'],['atardecer','Atardecer (cielo rosado)']]},
      {k:'horno', l:'Horno encendido', t:'select', def:'si', o:SI_NO, help:'Luz cálida que late dentro del horno, con las galletas horneándose. Con la Sra. Claus, el horno se enciende solo cuando le toca'},
      {k:'cocina', l:'La Sra. Claus cocina la casa', t:'select', def:'si', o:SI_NO, ui:'interruptor', help:'Con «No» la casa ya está hecha y no sale la Sra. Claus'},
      {k:'cocina_min', l:'Cuánto tarda en cocinar', t:'num', def:20, min:2, max:240, step:1, ui:'botones', lPaso:'¿Cuánto tarda en cocinar la casa?', helpPaso:'Si la pantalla tiene cuenta atrás, manda la cuenta.', visibleSi:{cocina:'si'},
        botones:[[10,'10 min'],[20,'20 min'],[30,'30 min'],[60,'1 hora']], otro:'{cocina_min} min', help:'Si la pantalla tiene cuenta atrás, manda la cuenta: la casa queda lista justo al llegar a cero'},
      {k:'repetir', l:'Al terminar, volver a empezar', t:'select', def:'no', o:SI_NO, ui:'interruptor', visibleSi:{cocina:'si'}, help:'Con «Sí», un rato después de terminar limpia la cocina y empieza otra casa'},
      {k:'reiniciar', l:'Empezar de nuevo', t:'text', def:'', ui:'vaciar', boton:'Empezar de nuevo', etiqueta:'La cocina', nota:'Listo. Ahora copia el link y pégalo otra vez en OBS: la Sra. Claus empieza desde el principio.', ayuda:'La cocina recuerda por dónde iba aunque cambies de escena. Este botón la manda al principio.', visibleSi:{cocina:'si'}, help:'Lo pone el botón del PANEL: si cambia este valor, la cocina vuelve al principio una vez'}
    ], {
      acento:{ lPaso:'Color de la decoración', helpPaso:'Pinta las cortinas, el faldón, los moños y la cenefa de la pared. También el cartel.' },
      modo:{ ui:'botones', lPaso:'¿Lleva texto?', botones:[['pantalla','Con texto'],['fondo','Fondo limpio']] },
      tipo:{ ui:'botones', lPaso:'¿Qué pantalla es?', botones:[['soon','Empezamos pronto'],['brb','Vuelvo enseguida'],['ending','Fin del directo']] },
      cuenta:{ ui:'interruptor', lPaso:'Con cuenta atrás' },
      minutos:{ ui:'botones', lPaso:'¿Cuántos minutos de cuenta?', botones:[[3,'3 min'],[5,'5 min'],[10,'10 min'],[15,'15 min']], otro:'{minutos} min', fino:{menos:'Menos', mas:'Más'} }
    })},
  { id:'fondo-blanca', grupo:'fondo', archivo:'Fondo - Blanca Navidad.html', nombre:'Fondo: Blanca Navidad', transparente:false,
    lienzo:FHD, tam:'1920 × 1080',
    desc:'Noche nevada en el bosque: aurora boreal que ondula, luna, cabaña de troncos con las ventanas encendidas, muñeco de nieve y pinos con luces. Pasan un zorro, un ciervo o un búho y el trineo de Santa cruza la luna. Con texto (Empezamos / Vuelvo / Fin) en un letrero de madera, o limpio para poner tu cámara o el juego encima.',
    /* 11-nov: sin alertas (ni bits, ni subs, ni raids, ni chat). Probar = lo que pasa solo en la escena */
    acciones:[['trineo','Trineo de Santa'],['zorro','Zorro'],['ciervo','Ciervo'],['buho','Búho']],
    probarTxt:'Haz que pase ahora. Solo en esta vista previa: en tu directo pasan solos de vez en cuando. Lo que hayas apagado abajo no se prueba.',
    pasos:[
      {t:'Qué pantalla es', f:'Elige si lleva texto en un letrero o si es un fondo limpio para tu cámara o tu juego.', campos:['modo','tipo','titulo','subtitulo','cuenta','minutos','acento']},
      {t:'El cielo', f:'Elige la hora. Funciona sin conectar nada.', campos:['hora','hora_min','luna']},
      {t:'Qué pasa en la escena', f:'Todo esto ya viene encendido. Apaga lo que no quieras.', campos:['aurora','animales','trineo','guirnalda','nieve']}
    ],
    avanzado:[],
    params:camposFondo([
      {k:'aurora', l:'Aurora boreal', t:'select', def:'si', o:SI_NO, ui:'interruptor', help:'Cortinas de luz verde y violeta que ondulan en el cielo'},
      {k:'animales', l:'Animales', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Animales de vez en cuando', help:'Cada minuto o dos se asoma un zorro, un ciervo o un búho'},
      {k:'trineo', l:'Trineo de Santa', t:'select', def:'si', o:SI_NO, ui:'interruptor', lPaso:'Trineo de Santa de vez en cuando', help:'Cruza por delante de la luna cada minuto o minuto y medio'},
      {k:'luna', l:'Luna', t:'select', def:'llena', ui:'botones', lPaso:'La luna', botones:[['llena','Llena'],['creciente','Creciente']], o:[['llena','Llena'],['creciente','Creciente']]},
      {k:'hora', l:'Hora del cielo', t:'select', def:'noche', ui:'tarjetas', lPaso:'¿A qué hora es?', help:'Con cielos claros la aurora se ve más suave',
        o:[['noche','Noche'],['azul','Hora azul'],['atardecer','Atardecer'],['amanecer','Amanecer'],['ciclo','Cambia solo']],
        mini:{ noche:cieloMini(['#060a22','#232560','#634184'],'#fbf0cd',30), azul:cieloMini(['#17306c','#6577bd','#dba6c4'],'#fff4d8',30), atardecer:cieloMini(['#2a2468','#c75a78','#ffc070'],'#ffe2a0',66), amanecer:cieloMini(['#12296a','#a68cc8','#ffe0ae'],'#fff0c0',66), ciclo:cieloMini(['#060a22','#c75a78','#ffe0ae'],'#ffe2a0',46) }},
      {k:'hora_min', l:'Cada cuánto cambia el cielo', t:'num', def:10, min:1, max:120, step:1, ui:'botones', lPaso:'¿Cada cuánto cambia?', botones:[[5,'5 min'],[10,'10 min'],[20,'20 min'],[30,'30 min']], otro:'{hora_min} min', visibleSi:{hora:'ciclo'}, help:'Va de noche a amanecer y a atardecer, y se funde despacio'},
    ], {
      acento:{ lPaso:'Color de la decoración', helpPaso:'Pinta las bolas del árbol, su falda, los regalos, la bufanda del muñeco y el buzón. También el letrero.' },
      modo:{ ui:'botones', lPaso:'¿Lleva texto?', botones:[['pantalla','Con texto'],['fondo','Fondo limpio']] },
      tipo:{ ui:'botones', lPaso:'¿Qué pantalla es?', botones:[['soon','Empezamos pronto'],['brb','Vuelvo enseguida'],['ending','Fin del directo']] },
      cuenta:{ ui:'interruptor', lPaso:'Con cuenta atrás' },
      minutos:{ ui:'botones', lPaso:'¿Cuántos minutos de cuenta?', botones:[[3,'3 min'],[5,'5 min'],[10,'10 min'],[15,'15 min']], otro:'{minutos} min', fino:{menos:'Menos', mas:'Más'} },
      nieve:{def:1, ui:'botones', lPaso:'¿Cuánta nieve cae?', botones:[[0,'Nada'],[0.5,'Poca'],[1,'Normal'],[2,'Mucha'],[3,'Tormenta']], otro:'{nieve}', help:'0 = sin nieve. Cae en 3 capas (lejos, medio y cerca). Más de 2 puede pesar en PCs modestos'},
      guirnalda:{l:'Luces en la cabaña', ui:'interruptor', help:'Focos de colores en el alero de la cabaña y en el letrero (los pinos llevan sus luces siempre)'}
    })}
];
/* Formato (11-nov): todas las piezas pueden ir en vertical (1080 × 1920, TikTok, Reels, Shorts). Va al final de params:
   de fábrica es horizontal y no entra en el link, así los links de antes siguen iguales. El PANEL lo pone arriba de las opciones */
HW.FORMATO = {k:'orientacion', l:'Formato', t:'select', def:'horizontal', o:[['horizontal','Horizontal (1920 × 1080)'],['vertical','Vertical (1080 × 1920: TikTok, Reels, Shorts)']]};
HW.PIEZAS.forEach(function(p){ p.params.push(HW.FORMATO); });
/* Zona segura de la vertical (px de 1080 × 1920): arriba va la barra de la app, abajo el texto y los comentarios,
   y a la derecha los botones. Lo importante (nombres, textos, alertas) se queda dentro de este rectángulo */
HW.SEGURA_V = { x0:60, x1:930, y0:170, y1:1480 };
HW.GRUPOS = [['chat','Chat'],['deco','Decoración'],['fondo','Fondos']];
HW.pieza = function(id){ for (var i=0;i<HW.PIEZAS.length;i++) if (HW.PIEZAS[i].id===id) return HW.PIEZAS[i]; return null; };
/* Tamaño del lienzo de una pieza según sus valores (vista previa y OBS) */
HW.lienzo = function(p, valores){
  if (valores && valores.orientacion === 'vertical') return [1080, 1920];
  var l = p && p.lienzo;
  if (typeof l === 'function') l = l(valores || {});
  return (l && l.length === 2) ? l : FHD;
};
/* Visibilidad condicional de un campo: d.visibleSi = {param: valor | [valores]}.
   '*' = "ese param no está vacío". Se cumple si cada param vale eso y además
   ese param está visible (cadenas). */
HW.visible = function(p, valores, d, prof){
  if (!d || !d.visibleSi || (prof || 0) > 8) return true;
  return Object.keys(d.visibleSi).every(function(k){
    var quiere = [].concat(d.visibleSi[k]).map(String), dk = null, v = String(valores[k] == null ? '' : valores[k]);
    p.params.forEach(function(x){ if (x.k === k) dk = x; });
    var ok = quiere.indexOf(v) >= 0 || (quiere.indexOf('*') >= 0 && v.trim() !== '');
    return ok && HW.visible(p, valores, dk, (prof || 0) + 1);
  });
};

/* ── 2. Leer parámetros ─────────────────────────────────────── */
/* Parámetros del link: lo de después de ? y, encima, lo de después de # (12-nov: el código de Twitch va en el #,
   que no viaja en ninguna petición ni sale en el registro de OBS). Con codigo=1 y sin token en el link, el token es el de
   Datos/codigo.js (ver arriba). Los links viejos con ?token= siguen valiendo. */
HW.query = function(){
  var out = {};
  [location.search || '', location.hash || ''].forEach(function(q){
    q = q.replace(/^[?#]/, '');
    if (!q) return;
    q.split('&').forEach(function(par){
      if (!par) return;
      var i = par.indexOf('='), k = i<0 ? par : par.slice(0,i), v = i<0 ? '' : par.slice(i+1);
      try { k = decodeURIComponent(k.replace(/\+/g,' ')); v = decodeURIComponent(v.replace(/\+/g,' ')); } catch(e){}
      out[k.toLowerCase()] = v;
    });
  });
  if (!out.token && HW.esSi(out.codigo || '') && !HW.esSi(out.vista || '') && typeof window.NV_CODIGO === 'string') out.token = HW.limpiarToken(window.NV_CODIGO);
  return out;
};
HW.esSi = function(v){ return /^(1|si|sí|s|true|yes|on)$/i.test(String(v).trim()); };
HW.hex = function(v, def){
  v = String(v == null ? '' : v).trim().replace(/^#/, '');
  if (/^[0-9a-f]{3}$/i.test(v)) v = v.replace(/(.)/g,'$1$1');
  return /^[0-9a-f]{6}$/i.test(v) ? '#'+v.toLowerCase() : (def ? HW.hex(def) : null);
};
/* Quita tildes (á → a, ñ → n) para comparar o limpiar texto */
HW.sinTildes = function(v){
  v = String(v == null ? '' : v);
  return v.normalize ? v.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : v;
};
/* Mapa de canjes / lista de palabras: minúsculas, sin tildes, solo [a-z0-9:,_- y espacio], ≤ 2000 */
HW.limpiarMapa = function(v){
  return HW.sinTildes(v).toLowerCase().replace(/[^a-z0-9:,_\- ]/g, '').slice(0, 2000);
};
/* Token de Twitch: solo letras y números, ≤ 64. Acepta que lo peguen con "oauth:" delante.
   Si no cumple, '' (mejor sin token que con basura en la URL). */
HW.limpiarToken = function(v){
  v = String(v == null ? '' : v).trim().replace(/^oauth:/i, '');
  return (/^[a-z0-9]+$/i.test(v) && v.length <= 64) ? v : '';
};
/* Convierte un valor crudo (de la URL o del PANEL) al tipo del campo d */
HW.valorCampo = function(d, v){
  if (d.t === 'num'){ var n = parseFloat(v); if (isNaN(n)) n = d.def; return Math.min(d.max, Math.max(d.min, n)); }
  if (d.t === 'color') return HW.hex(v, d.def);
  if (d.t === 'select'){
    if (d.o === SI_NO) return HW.esSi(v);
    var ok = d.o.some(function(o){ return o[0] === v; }); return ok ? v : d.def;
  }
  if (d.t === 'mapa' || d.t === 'palabras') return HW.limpiarMapa(v);
  if (d.t === 'token') return HW.limpiarToken(v);
  if (d.t === 'lista'){
    /* Lista de interruptores "a,b,c": solo claves conocidas, en el orden del catálogo */
    var pide = String(v == null ? '' : v).toLowerCase().split(',').map(function(x){ return x.trim(); });
    return d.o.map(function(o){ return o[0]; }).filter(function(k){ return pide.indexOf(k) >= 0; }).join(',');
  }
  return String(v == null ? '' : v).slice(0, 200);
};
/* Devuelve {param: valor} ya tipado, con los valores de fábrica del catálogo */
HW.leer = function(id){
  var p = HW.pieza(id), q = HW.query(), r = {};
  (p ? p.params : []).forEach(function(d){
    var has = Object.prototype.hasOwnProperty.call(q, d.k), v = has ? q[d.k] : d.def;
    r[d.k] = HW.valorCampo(d, v);
  });
  return r;
};
/* ¿La pieza va en vertical? (orientacion=vertical). Pone la clase hw-v en <html> para el CSS de cada pieza */
HW.esVertical = function(){
  var v = String(HW.query().orientacion || '').toLowerCase() === 'vertical';
  if (v && document.documentElement) document.documentElement.classList.add('hw-v');
  return v;
};
/* Fondos en vertical: la escena sigue dibujándose en px del diseño 1920 × 1080 (sus SVG y sus divs en %), pero se
   enseña por una ventana de 1080 × 1920 px de pantalla: x de x0 a x0 + 1080·s y y de y0 a y0 + 1920·s (s = px del diseño
   por px de pantalla; 1 = mismo tamaño que en horizontal). Lo que la vertical añade (piso, cielo, letrero) se dibuja en esas
   mismas coordenadas, fuera de 0-1080 en y. Solo transform: el lienzo mide 100vw de ancho como siempre, así lo que va en vw
   (la Sra. Claus) sigue cuadrando. capa(el): esa capa cubre toda la ventana (nieve, viñeta) */
HW.encuadreVertical = function(lienzo, op){
  var x0 = +op.x0 || 0, y0 = +op.y0 || 0, s = +op.s || 1;
  lienzo.style.left = '0'; lienzo.style.top = '0'; lienzo.style.overflow = 'visible'; lienzo.style.transformOrigin = '0 0';
  lienzo.style.transform = 'translate(' + (-x0 / s / 10.8).toFixed(4) + 'vw,' + (-y0 / s / 10.8).toFixed(4) + 'vw) scale(' + (1920 / 1080 / s).toFixed(5) + ')';
  var caja = { x: x0, y: y0, w: 1080 * s, h: 1920 * s };
  caja.capa = function(el){
    el.style.left = (x0 / 19.2).toFixed(3) + '%'; el.style.top = (y0 / 10.8).toFixed(3) + '%';
    el.style.width = (caja.w / 19.2).toFixed(3) + '%'; el.style.height = (caja.h / 10.8).toFixed(3) + '%';
    el.style.right = 'auto'; el.style.bottom = 'auto';
    return el;
  };
  return caja;
};
/* ¿La pieza está dentro de la vista previa del PANEL? (&vista=1) */
HW.esVista = function(){ return HW.esSi(HW.query().vista || ''); };

/* ── 3. Utilidades ──────────────────────────────────────────── */
HW.hash = function(s){ s = String(s).toLowerCase(); var h = 2166136261; for (var i=0;i<s.length;i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
HW.azar = function(seed){ var a = seed >>> 0 || 1; return function(){ a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
HW.rgb = function(hex){ hex = HW.hex(hex, '#ffffff'); return [parseInt(hex.substr(1,2),16), parseInt(hex.substr(3,2),16), parseInt(hex.substr(5,2),16)]; };
HW.rgba = function(hex, a){ var c = HW.rgb(hex); return 'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')'; };
/* Aclara un color hasta que se lea sobre fondo oscuro */
HW.legible = function(hex){
  var c = HW.rgb(hex), n = 0;
  var lum = function(c){ return (0.2126*c[0] + 0.7152*c[1] + 0.0722*c[2]) / 255; };
  while (lum(c) < 0.55 && n < 12){ c = c.map(function(x){ return Math.round(x + (255 - x) * 0.18); }); n++; }
  return '#' + c.map(function(x){ return ('0' + x.toString(16)).slice(-2); }).join('');
};
/* Mezcla dos colores hex (t = 0 → a, 1 → b) */
HW.mezcla = function(a, b, t){
  var x = HW.rgb(a), y = HW.rgb(b);
  return '#' + x.map(function(v, i){ return ('0' + Math.round(v + (y[i] - v) * t).toString(16)).slice(-2); }).join('');
};
/* Cartel de aviso (html fijo del pack, nunca texto del chat) */
HW.aviso = function(titulo, html){
  var d = document.createElement('div'); d.className = 'hw-aviso';
  var b = document.createElement('b'); b.textContent = titulo; d.appendChild(b);
  var s = document.createElement('div'); s.innerHTML = html; d.appendChild(s);
  document.body.appendChild(d); return d;
};
/* ¿Esta página la está mostrando OBS (fuente de navegador o panel)? */
HW.enObs = function(){ return !!window.obsstudio; };
/* Cartel «Falta tu canal» de las piezas de chat. Dentro de OBS lo normal es el panel Navidad (que pone las piezas solo);
   fuera de OBS, el PANEL y su link. Texto fijo del pack (sin datos de nadie) */
HW.avisoSinCanal = function(){
  var html = HW.enObs()
    ? 'Pon tu canal de <b>Twitch</b> o de <b>Kick</b> en <b>Mis canales</b>, arriba del panel <b>Navidad</b> de OBS. Si pegaste este link a mano, ponlo en <b>PANEL</b> y copia el link otra vez.'
    : 'Abre <b>PANEL</b>, pon tu canal de <b>Twitch</b> o de <b>Kick</b> en <b>Mis canales</b> y copia el link otra vez.';
  return HW.aviso('Falta tu canal', html + '<br>Para probar sin chat, activa el <b>modo demo</b> de esta pieza.');
};
HW.canal = function(v){ return String(v || '').trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^(www\.)?twitch\.tv\//,'').replace(/^[#@]/,'').replace(/[^a-z0-9_]/g,''); };
HW.canalKick = function(v){ return String(v || '').trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^(www\.)?kick\.com\//,'').replace(/^[#@]/,'').replace(/[\/?#].*$/,'').replace(/[^a-z0-9_-]/g,''); };
HW.numero = function(v){ return String(v || '').replace(/[^0-9]/g,'').slice(0, 15); };

/* ── Hora por región (Cuenta para Navidad). Todo en milisegundos; «pared» = la hora que marca el reloj de ese lugar ── */
HW.zonaDe = function(region){
  for (var i = 0; i < HW.REGIONES.length; i++) if (HW.REGIONES[i][0] === region) return HW.REGIONES[i][2];
  return HW.REGIONES[0][2];
};
var formatos = {};
/* {y, m, d, h, mi, s} de la pared en esa zona ('' = la de la computadora). Si Intl no conoce la zona, la de la computadora */
HW.paredEn = function(ms, zona){
  var f = null;
  if (zona && window.Intl && Intl.DateTimeFormat){
    try {
      f = formatos[zona] || (formatos[zona] = new Intl.DateTimeFormat('en-US', { timeZone:zona, hourCycle:'h23', year:'numeric', month:'numeric', day:'numeric', hour:'numeric', minute:'numeric', second:'numeric' }));
    } catch(e){ f = formatos[zona] = null; }
  }
  if (!f){ var dl = new Date(ms); return { y:dl.getFullYear(), m:dl.getMonth() + 1, d:dl.getDate(), h:dl.getHours(), mi:dl.getMinutes(), s:dl.getSeconds() }; }
  var o = {};
  f.formatToParts(new Date(ms)).forEach(function(x){ o[x.type] = +x.value; });
  return { y:o.year, m:o.month, d:o.day, h:o.hour % 24, mi:o.minute, s:o.second };
};
/* Instante (ms) en que la pared de esa zona marca y-m-d h:mi:s (los desbordes de día o mes se acomodan solos) */
HW.instanteEn = function(y, m, d, h, mi, s, zona){
  if (!zona) return new Date(y, m - 1, d, h || 0, mi || 0, s || 0).getTime();
  var pared = Date.UTC(y, m - 1, d, h || 0, mi || 0, s || 0), t = pared;
  for (var i = 0; i < 3; i++){
    var w = HW.paredEn(t, zona), dif = Date.UTC(w.y, w.m - 1, w.d, w.h, w.mi, w.s) - pared;
    if (!dif) break;
    t -= dif;
  }
  return t;
};
/* Lo que dice el cartel: fecha "MM-DD" (cada año) o "AAAA-MM-DD", región y ahora (ms).
   {tipo:'dia', pasada} el mismo día (o ya pasada una fecha exacta) · {tipo:'horas', v} menos de un día · {tipo:'dias', v} */
HW.cuentaRegresiva = function(fecha, region, ahora){
  var m = /^\s*(?:(\d{4})-)?(\d{1,2})-(\d{1,2})\s*$/.exec(String(fecha || '')), ok = m && +m[2] >= 1 && +m[2] <= 12 && +m[3] >= 1 && +m[3] <= 31;
  var anio = ok && m[1] ? +m[1] : 0, mes = ok ? +m[2] : 12, dia = ok ? +m[3] : 25;
  var zona = region === 'pc' ? '' : HW.zonaDe(region), w = HW.paredEn(ahora, zona), y = anio || w.y;
  var ini = HW.instanteEn(y, mes, dia, 0, 0, 0, zona), fin = HW.instanteEn(y, mes, dia + 1, 0, 0, 0, zona);
  if (!anio && ahora >= fin){ y++; ini = HW.instanteEn(y, mes, dia, 0, 0, 0, zona); fin = HW.instanteEn(y, mes, dia + 1, 0, 0, 0, zona); }
  if (ahora >= ini) return { tipo:'dia', pasada:!!anio && ahora >= fin };
  if (ini - ahora < 86400000) return { tipo:'horas', v:Math.max(1, Math.ceil((ini - ahora) / 3600000)) };
  return { tipo:'dias', v:Math.round((Date.UTC(y, mes - 1, dia) - Date.UTC(w.y, w.m - 1, w.d)) / 86400000), objetivo:y + '-' + mes + '-' + dia };
};

/* ── 4. Chat de Twitch anónimo (IRC por WebSocket, sin librería) ── */
function desescapar(v){
  return v.replace(/\\(.)/g, function(m, c){ return c === 's' ? ' ' : c === ':' ? ';' : c === 'r' ? '\r' : c === 'n' ? '\n' : c; }).replace(/\\$/, '');
}
HW.parseIRC = function(linea){
  var m = { tags:{}, prefix:'', cmd:'', params:[], texto:'' }, pos = 0;
  if (linea.charAt(0) === '@'){
    var fin = linea.indexOf(' ');
    linea.slice(1, fin).split(';').forEach(function(t){ var i = t.indexOf('='); m.tags[i<0 ? t : t.slice(0,i)] = i<0 ? '' : desescapar(t.slice(i+1)); });
    pos = fin + 1;
  }
  while (linea.charAt(pos) === ' ') pos++;
  if (linea.charAt(pos) === ':'){ var f2 = linea.indexOf(' ', pos); m.prefix = linea.slice(pos+1, f2); pos = f2 + 1; }
  var resto = linea.slice(pos), ti = resto.indexOf(' :');
  if (ti >= 0){ m.texto = resto.slice(ti + 2); resto = resto.slice(0, ti); }
  var partes = resto.split(' ').filter(Boolean);
  m.cmd = partes.shift() || ''; m.params = partes;
  m.nick = m.prefix.split('!')[0];
  return m;
};
/* "broadcaster/1,subscriber/3012" → {broadcaster:'1', subscriber:'3012'} */
HW.insignias = function(v){
  var r = {};
  String(v || '').split(',').forEach(function(b){
    if (!b) return;
    var i = b.indexOf('/'), k = i < 0 ? b : b.slice(0, i);
    if (k) r[k] = i < 0 ? '' : b.slice(i + 1);
  });
  return r;
};
/* new HW.Chat('canal', { mensaje(m), estado(texto), evento(ev) })
   · mensaje(m): PRIVMSG con m.usuario, m.login, m.color, m.texto y además
       m.recompensa (id del canje de puntos o ''), m.bits (número), m.primeraVez,
       m.destacado, m.insignias {broadcaster:'1',…}, m.esStreamer, m.esMod,
       m.idMsg, m.plataforma = 'twitch'.
   · evento(ev) (opcional): {tipo:'sub'|'resub'|'regalo'|'regalo-masivo'|'raid'|'bits',
       nombre, cantidad, texto, meses, plataforma:'twitch'}. Los regalos sueltos que
       forman parte de un regalo masivo ya avisado NO se repiten.
   El texto del viewer (m.texto / ev.texto) se pinta solo con textContent. */
HW.Chat = function(canal, cb){
  this.canal = HW.canal(canal); this.cb = cb || {}; this.espera = 1000; this.ws = null; this.vivo = true; this._t = null;
  this._masivos = {};
  this.conectar();
};
HW.Chat.prototype.conectar = function(){
  var self = this, ws;
  try { ws = new WebSocket('wss://irc-ws.chat.twitch.tv:443'); } catch(e){ self.reintentar(); return; }
  self.ws = ws;
  ws.onopen = function(){
    ws.send('CAP REQ :twitch.tv/tags twitch.tv/commands');
    ws.send('PASS SCHMOOPIIE');
    ws.send('NICK justinfan' + (10000 + Math.floor(Math.random() * 80000)));
    ws.send('JOIN #' + self.canal);
  };
  ws.onmessage = function(ev){
    String(ev.data).split('\r\n').forEach(function(l){ self.procesar(l); });
  };
  ws.onclose = function(){ if (self.cb.estado) self.cb.estado('desconectado'); self.reintentar(); };
  ws.onerror = function(){ try { ws.close(); } catch(e){} };
};
HW.Chat.prototype.enviar = function(txt){ try { if (this.ws) this.ws.send(txt); } catch(e){} };
/* Procesa UNA línea IRC (sin \r\n). Se puede llamar a mano para probar:
   chat.procesar('@badges=…;custom-reward-id=… :x!x@x.tmi.twitch.tv PRIVMSG #canal :hola') */
HW.Chat.prototype.procesar = function(l){
  if (!l) return null;
  var self = this, cb = self.cb, m = HW.parseIRC(String(l).replace(/\r?\n$/, ''));
  if (m.cmd === 'PING'){ self.enviar('PONG :' + (m.texto || 'tmi.twitch.tv')); return m; }
  if (m.cmd === 'RECONNECT'){ try { self.ws.close(); } catch(e){} return m; }
  if (m.cmd === 'ROOMSTATE' || m.cmd === '366'){ self.espera = 1000; if (cb.estado) cb.estado('conectado'); return m; }
  var t = m.tags;
  if (m.cmd === 'PRIVMSG'){
    m.usuario = t['display-name'] || m.nick;
    m.login = String(m.nick || m.usuario || '').toLowerCase();
    m.color = t.color || '';
    m.recompensa = t['custom-reward-id'] || '';
    m.bits = parseInt(t.bits, 10) || 0;
    if (m.bits < 0) m.bits = 0;
    m.primeraVez = t['first-msg'] === '1';
    m.destacado = t['msg-id'] === 'highlighted-message';
    m.insignias = HW.insignias(t.badges);
    m.esStreamer = Object.prototype.hasOwnProperty.call(m.insignias, 'broadcaster');
    m.esMod = Object.prototype.hasOwnProperty.call(m.insignias, 'moderator') || t.mod === '1';
    m.idMsg = t.id || '';
    m.plataforma = 'twitch';
    if (cb.mensaje) cb.mensaje(m);
    if (m.bits > 0 && cb.evento) cb.evento({ tipo:'bits', nombre:m.usuario, cantidad:m.bits, texto:m.texto, meses:0, plataforma:'twitch' });
    return m;
  }
  if (m.cmd === 'USERNOTICE' && cb.evento){
    var ev = self.evento(m);
    if (ev) cb.evento(ev);
  }
  return m;
};
/* USERNOTICE → evento (o null si no interesa / ya se avisó dentro de un regalo masivo) */
HW.Chat.prototype.evento = function(m){
  var t = m.tags, id = t['msg-id'], nombre = t['display-name'] || t.login || m.nick || '';
  var num = function(k, def){ var n = parseInt(t[k], 10); return isNaN(n) ? def : n; };
  var ev = { tipo:'', nombre:nombre, cantidad:1, texto:m.texto || '', meses:0, plataforma:'twitch' };
  if (id === 'sub'){ ev.tipo = 'sub'; ev.meses = num('msg-param-cumulative-months', 1) || 1; }
  else if (id === 'resub'){ ev.tipo = 'resub'; ev.meses = num('msg-param-cumulative-months', 0); }
  else if (id === 'subgift' || id === 'anonsubgift'){
    var g = t['msg-param-community-gift-id'] || '';
    if (g && this._masivos[g] > 0){ this._masivos[g]--; if (!this._masivos[g]) delete this._masivos[g]; return null; }
    ev.tipo = 'regalo'; ev.para = t['msg-param-recipient-display-name'] || '';
    ev.meses = num('msg-param-gift-months', 1) || 1;
  }
  else if (id === 'submysterygift' || id === 'anonsubmysterygift'){
    ev.tipo = 'regalo-masivo'; ev.cantidad = num('msg-param-mass-gift-count', 1) || 1;
    var gm = t['msg-param-community-gift-id'] || '';
    if (gm){
      var claves = Object.keys(this._masivos);
      if (claves.length > 50) delete this._masivos[claves[0]];
      this._masivos[gm] = (this._masivos[gm] || 0) + ev.cantidad;
    }
  }
  else if (id === 'raid'){ ev.tipo = 'raid'; ev.nombre = t['msg-param-displayName'] || nombre; ev.cantidad = num('msg-param-viewerCount', 0); }
  else return null;
  return ev;
};
HW.Chat.prototype.reintentar = function(){
  var self = this; if (!self.vivo || self._t) return;
  self._t = setTimeout(function(){ self._t = null; self.conectar(); }, self.espera);
  self.espera = Math.min(self.espera * 2, 30000);
};
/* Deja de escuchar (no reconecta) */
HW.Chat.prototype.cerrar = function(){
  this.vivo = false; clearTimeout(this._t); this._t = null;
  try { if (this.ws) this.ws.close(); } catch(e){}
};

/* ── 4b. Chat de Kick anónimo (Pusher por WebSocket, sin librería ni login) ──
   new HW.ChatKick('canal', 'chatroom opcional', { mensaje(m), estado(s), error(codigo) })
   · Si no hay número de chatroom, lo pide a kick.com/api/v2/channels/<canal>
     (Kick responde con permiso CORS también para páginas file:///).
   · error: 'noexiste' (canal no encontrado), 'sinid' (no se pudo pedir el número),
     'clave' (Kick cambió su conexión). Cada error deja de intentar o reintenta solo. */
HW.KICK_PUSHER = { key:'34bf7a0ff419a2a775b9', cluster:'us2' };
HW.kickTexto = function(t){
  return String(t || '').replace(/\[emote:\d+:([^\]]*)\]/g, function(m, n){ return ' ' + n + ' '; }).replace(/\s+/g, ' ').trim();
};
HW.ChatKick = function(canal, chatroom, cb){
  this.canal = HW.canalKick(canal); this.room = HW.numero(chatroom); this.cb = cb || {};
  this.espera = 1000; this.ws = null; this.vivo = true; this._t = null; this._p = null;
  if (this.room) this.conectar(); else this.resolver(this.canal);
};
HW.ChatKick.prototype.resolver = function(slug){
  var self = this;
  if (typeof fetch !== 'function'){ if (self.cb.error) self.cb.error('sinid'); return; }
  fetch('https://kick.com/api/v2/channels/' + encodeURIComponent(slug), { headers:{ 'Accept':'application/json' } })
    .then(function(r){
      if (r.status === 404) return { noexiste:true };
      if (!r.ok) throw new Error('http ' + r.status);
      return r.json();
    })
    .then(function(j){
      if (j && j.noexiste){
        /* Kick usa guiones donde el nombre tiene guion bajo */
        if (slug.indexOf('_') >= 0) return self.resolver(slug.replace(/_/g, '-'));
        if (self.cb.error) self.cb.error('noexiste'); return;
      }
      var id = j && j.chatroom && j.chatroom.id;
      if (!id) throw new Error('sin chatroom');
      self.room = String(id); self.espera = 1000; self.conectar();
    })
    .catch(function(){
      if (self.cb.error) self.cb.error('sinid');
      if (!self.vivo) return;
      setTimeout(function(){ self.resolver(slug); }, self.espera);
      self.espera = Math.min(self.espera * 2, 60000);
    });
};
HW.ChatKick.prototype.conectar = function(){
  var self = this, ws, K = HW.KICK_PUSHER;
  try { ws = new WebSocket('wss://ws-' + K.cluster + '.pusher.com/app/' + K.key + '?protocol=7&client=js&version=8.4.0&flash=false'); } catch(e){ self.reintentar(); return; }
  self.ws = ws;
  var mandar = function(o){ try { ws.send(JSON.stringify(o)); } catch(e){} };
  ws.onmessage = function(ev){
    var m; try { m = JSON.parse(ev.data); } catch(e){ return; }
    var ev2 = String(m.event || '');
    if (ev2 === 'pusher:connection_established'){
      mandar({ event:'pusher:subscribe', data:{ auth:'', channel:'chatrooms.' + self.room + '.v2' } });
      /* Pusher pide señales de vida si el chat está callado */
      clearInterval(self._p); self._p = setInterval(function(){ mandar({ event:'pusher:ping', data:{} }); }, 60000);
      return;
    }
    if (ev2 === 'pusher:ping'){ mandar({ event:'pusher:pong', data:{} }); return; }
    if (ev2 === 'pusher_internal:subscription_succeeded'){ self.espera = 1000; if (self.cb.estado) self.cb.estado('conectado'); return; }
    if (ev2 === 'pusher:error'){
      var d0 = m.data || {}; if (typeof d0 === 'string'){ try { d0 = JSON.parse(d0); } catch(e){ d0 = {}; } }
      if (d0.code >= 4000 && d0.code < 4100 && self.cb.error) self.cb.error('clave');
      return;
    }
    if (/ChatMessage/.test(ev2)){
      var d; try { d = typeof m.data === 'string' ? JSON.parse(m.data) : m.data; } catch(e){ return; }
      if (!d || !d.sender) return;
      var s = d.sender;
      if (self.cb.mensaje) self.cb.mensaje({
        usuario: String(s.username || s.slug || ''),
        login: String(s.slug || s.username || '').toLowerCase(),
        color: (s.identity && s.identity.color) || '',
        texto: HW.kickTexto(d.content)
      });
    }
  };
  ws.onclose = function(){ clearInterval(self._p); if (self.cb.estado) self.cb.estado('desconectado'); self.reintentar(); };
  ws.onerror = function(){ try { ws.close(); } catch(e){} };
};
HW.ChatKick.prototype.reintentar = function(){
  var self = this; if (!self.vivo || self._t) return;
  self._t = setTimeout(function(){ self._t = null; self.conectar(); }, self.espera);
  self.espera = Math.min(self.espera * 2, 30000);
};

/* ── 4c. Login opcional: Helix, validar token y EventSub ─────────
   Solo lo usa la Mascota cuando el link trae token= (y nunca dentro del PANEL).
   · HW.Helix(token, clientId, base)  → get(ruta, params) / post(ruta, cuerpo) → Promise {status, json}
   · HW.validarToken(token, base)     → Promise {ok, login, user_id, client_id, scopes, expires_in, status}
   · HW.EventSub(op)                  → WebSocket de EventSub con suscripciones, keepalive,
                                        session_reconnect, revocation, reintentos y dedupe.
   Seguridad: las direcciones alternativas (mock de pruebas) solo se aceptan si apuntan a
   127.0.0.1 o localhost; cualquier otra se ignora y se usa la oficial de Twitch.
   El token NUNCA se escribe en la consola ni en el texto de los estados.
   ───────────────────────────────────────────────────────────── */
HW.HELIX_URL = 'https://api.twitch.tv/helix';
HW.ID_URL = 'https://id.twitch.tv';
HW.EVENTSUB_URL = 'wss://eventsub.wss.twitch.tv/ws';
/* ¿La dirección apunta a esta misma computadora? (protocolos: lista como ['http','https']) */
HW.esLocal = function(url, protocolos){
  var m = /^([a-z]+):\/\/(127\.0\.0\.1|localhost)(:\d{1,5})?(\/[^\s]*)?$/i.exec(String(url || '').trim());
  if (!m) return false;
  return !protocolos || protocolos.indexOf(m[1].toLowerCase()) >= 0;
};
/* Base alternativa solo si es local; si no, la oficial. Sin barra final. */
HW.baseLocal = function(base, oficial, protocolos){
  base = String(base || '').trim().replace(/\/+$/, '');
  return (base && HW.esLocal(base, protocolos || ['http', 'https'])) ? base : oficial;
};
function aQuery(params){
  var partes = [];
  Object.keys(params || {}).forEach(function(k){
    [].concat(params[k]).forEach(function(v){
      if (v == null || v === '') return;
      partes.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
    });
  });
  return partes.length ? '?' + partes.join('&') : '';
}
/* fetch que nunca lanza: red caída o CORS → {status:0, json:null} */
function pedirJSON(url, op){
  if (typeof fetch !== 'function') return Promise.resolve({ status:0, json:null });
  return fetch(url, op).then(function(r){
    return r.text().then(function(t){ var j = null; try { j = t ? JSON.parse(t) : null; } catch(e){} return { status:r.status, json:j }; });
  }, function(){ return { status:0, json:null }; });
}
HW.Helix = function(token, clientId, base){
  this.token = HW.limpiarToken(token);
  this.clientId = String(clientId || '').replace(/[^a-z0-9]/gi, '').slice(0, 64);
  this.base = HW.baseLocal(base, HW.HELIX_URL);
};
HW.Helix.prototype.cabeceras = function(json){
  var h = { 'Authorization':'Bearer ' + this.token, 'Client-Id':this.clientId };
  if (json) h['Content-Type'] = 'application/json';
  return h;
};
HW.Helix.prototype.get = function(ruta, params){
  return pedirJSON(this.base + ruta + aQuery(params), { method:'GET', headers:this.cabeceras(false), cache:'no-store' });
};
HW.Helix.prototype.post = function(ruta, cuerpo){
  return pedirJSON(this.base + ruta, { method:'POST', headers:this.cabeceras(true), body:JSON.stringify(cuerpo || {}) });
};
/* GET /oauth2/validate (Twitch pide repetirlo cada hora mientras se usa el token) */
HW.validarToken = function(token, base){
  var tk = HW.limpiarToken(token);
  if (!tk) return Promise.resolve({ ok:false, status:401, login:'', user_id:'', client_id:'', scopes:[], expires_in:0 });
  var url = HW.baseLocal(base, HW.ID_URL) + '/oauth2/validate';
  return pedirJSON(url, { method:'GET', headers:{ 'Authorization':'OAuth ' + tk }, cache:'no-store' }).then(function(r){
    var j = r.json || {};
    return {
      ok: r.status === 200 && !!j.user_id,
      status: r.status,
      login: String(j.login || ''),
      user_id: String(j.user_id || ''),
      client_id: String(j.client_id || ''),
      scopes: Array.isArray(j.scopes) ? j.scopes.map(String) : [],
      expires_in: parseInt(j.expires_in, 10) || 0
    };
  });
};
/* Permisos que faltan comparando con HW.SCOPES */
HW.faltanScopes = function(scopes){
  scopes = scopes || [];
  return HW.SCOPES.filter(function(s){ return scopes.indexOf(s) < 0; });
};

/* Suscripciones de EventSub. ev = interruptor de op.eventos que la activa.
   v = versiones a probar en orden (si Twitch responde 400 a una, se prueba la siguiente). */
HW.EVENTSUB_TIPOS = [
  { ev:'canje',  type:'channel.channel_points_custom_reward_redemption.add', v:['1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'follow', type:'channel.follow', v:['2'], cond:function(b){ return { broadcaster_user_id:b, moderator_user_id:b }; } },
  { ev:'bits',   type:'channel.cheer', v:['1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'raid',   type:'channel.raid', v:['1'], cond:function(b){ return { to_broadcaster_user_id:b }; } },
  { ev:'sub',    type:'channel.subscribe', v:['1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'sub',    type:'channel.subscription.gift', v:['1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'sub',    type:'channel.subscription.message', v:['1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'hype',   type:'channel.hype_train.begin', v:['2', '1'], cond:function(b){ return { broadcaster_user_id:b }; } },
  { ev:'hype',   type:'channel.hype_train.end', v:['2', '1'], cond:function(b){ return { broadcaster_user_id:b }; } }
];
/* notification de EventSub → evento con el contrato de mascota.evento (o null si no interesa) */
HW.normalizarEventSub = function(tipo, e){
  e = e || {};
  var nom = function(an){ return an ? 'Anónimo' : String(e.user_name || e.user_login || ''); };
  var n = function(v, def){ v = parseInt(v, 10); return isNaN(v) ? def : v; };
  var base = { nombre:nom(false), login:String(e.user_login || '').toLowerCase(), cantidad:1, texto:'', meses:0, plataforma:'twitch', origen:'eventsub' };
  var r = function(extra){ Object.keys(extra).forEach(function(k){ base[k] = extra[k]; }); return base; };
  switch (tipo){
    case 'channel.channel_points_custom_reward_redemption.add':
      var rw = e.reward || {};
      return r({ tipo:'canje', texto:String(e.user_input || ''), recompensa:{ id:String(rw.id || ''), titulo:String(rw.title || '') } });
    case 'channel.follow': return r({ tipo:'follow' });
    case 'channel.cheer': return r({ tipo:'bits', nombre:nom(e.is_anonymous), cantidad:Math.max(0, n(e.bits, 0)), texto:String(e.message || '') });
    case 'channel.raid':
      return r({ tipo:'raid', nombre:String(e.from_broadcaster_user_name || e.from_broadcaster_user_login || ''),
        login:String(e.from_broadcaster_user_login || '').toLowerCase(), cantidad:Math.max(0, n(e.viewers, 0)) });
    case 'channel.subscribe':
      if (e.is_gift) return null;   /* el regalo ya llega como channel.subscription.gift */
      return r({ tipo:'sub', meses:1 });
    case 'channel.subscription.message':
      return r({ tipo:'resub', meses:Math.max(0, n(e.cumulative_months, 0)), texto:String((e.message && e.message.text) || '') });
    case 'channel.subscription.gift':
      var total = Math.max(1, n(e.total, 1));
      return r({ tipo:total > 1 ? 'regalo-masivo' : 'regalo', nombre:nom(e.is_anonymous), cantidad:total });
    case 'channel.hype_train.begin': return r({ tipo:'hype-inicio', nombre:'', login:'', cantidad:Math.max(1, n(e.level, 1)) });
    case 'channel.hype_train.end': return r({ tipo:'hype-fin', nombre:'', login:'', cantidad:Math.max(1, n(e.level, 1)) });
  }
  return null;
};

/* new HW.EventSub({ token, clientId, broadcasterId, login, url, helix, eventos:{follow,sub,bits,raid,hype,canje},
                     validar (base de /oauth2/validate, o false para no revalidar: modo mock), onEvento(ev), onEstado(estado, detalle) })
   Estados: 'conectando' · 'conectado' {login, n, total} · 'reconectando' · 'sin-permiso' {tipos:[…]}
            · 'caducado' · 'revocado' {tipo, motivo} · 'error' {tipos, status, motivo}.
   ('validando' lo emite quien llama antes de crear la instancia.) */
HW.EventSub = function(op){
  op = op || {};
  this.op = op;
  this.token = HW.limpiarToken(op.token);
  this.bid = String(op.broadcasterId || '').replace(/[^0-9]/g, '');
  this.login = String(op.login || '');
  this.url = HW.esLocal(op.url, ['ws', 'wss']) ? String(op.url).trim() : HW.EVENTSUB_URL;
  this.helix = op.helix || new HW.Helix(this.token, op.clientId);
  this.eventos = op.eventos || { follow:true, sub:true, bits:true, raid:true, hype:true, canje:true };
  this.margen = op._margen != null ? op._margen : 5;      /* s extra sobre keepalive_timeout_seconds */
  this.vivo = true; this.ws = null; this.wsNuevo = null; this.sesion = null; this.keepalive = 10;
  this.espera = 1000; this._t = null; this._vig = null; this._val = null;
  this.activas = {};          /* type → id de suscripción */
  this.versiones = {};        /* type → versión que funcionó (hype_train: '2' o '1') */
  this.avisados = {};         /* tipos ya avisados como sin permiso (una vez) */
  this.vistos = []; this.vistosSet = {};
  this.estado('conectando');
  this.abrir(this.url, false);
  var self = this;
  if (op.validar !== false){
    this._val = setInterval(function(){ self.revalidar(); }, 3600 * 1000);
  }
};
/* Twitch exige validar el token cada hora mientras se usa: 401 → caducado (se para) */
HW.EventSub.prototype.revalidar = function(){
  var self = this;
  return HW.validarToken(self.token, self.op.validar).then(function(r){
    if (self.vivo && r.status === 401) self.morir('caducado');
    return r.status;
  });
};
HW.EventSub.prototype.estado = function(e, d){ try { if (this.op.onEstado) this.op.onEstado(e, d || {}); } catch(x){} };
HW.EventSub.prototype.abrir = function(url, reconexion){
  var self = this, ws;
  try { ws = new WebSocket(url); } catch(e){ if (!reconexion) self.reintentar(); return; }
  ws._reconexion = !!reconexion;
  if (reconexion) self.wsNuevo = ws; else self.ws = ws;
  ws.onmessage = function(ev){ if (self.vivo && !ws._viejo) self.recibir(String(ev.data), ws); };
  ws.onclose = function(ev){ self.cerrado(ws, ev && ev.code); };
  ws.onerror = function(){ try { ws.close(); } catch(e){} };
  if (!reconexion) self.vigilar(ws, 15);       /* sin welcome en 15 s → reintento */
};
/* Perro guardián: si pasan keepalive + margen segundos sin ningún mensaje → cerrar y reconectar */
HW.EventSub.prototype.vigilar = function(ws, seg){
  var self = this;
  clearTimeout(self._vig);
  self._vig = setTimeout(function(){
    if (!self.vivo || ws !== self.ws) return;
    self.soltar(ws);
    self.ws = null; self.sesion = null; self.activas = {};
    self.estado('reconectando', { motivo:'keepalive' });
    self.reintentar(true);
  }, seg * 1000);
};
HW.EventSub.prototype.soltar = function(ws){
  if (!ws) return;
  ws._viejo = true;
  try { ws.close(); } catch(e){}
};
HW.EventSub.prototype.recibir = function(texto, ws){
  var self = this, m;
  try { m = JSON.parse(texto); } catch(e){ return; }
  var meta = m.metadata || {}, pay = m.payload || {}, tipo = meta.message_type;
  if (ws === self.ws || ws === self.wsNuevo){
    if (ws === self.ws || tipo === 'session_welcome') self.vigilar(ws, (self.keepalive || 10) + self.margen);
  }
  /* Dedupe: Twitch puede repetir un mensaje (mismo message_id) */
  var mid = meta.message_id;
  if (mid){
    if (self.vistosSet[mid]) return;
    self.vistosSet[mid] = 1; self.vistos.push(mid);
    if (self.vistos.length > 100) delete self.vistosSet[self.vistos.shift()];
  }
  if (tipo === 'session_welcome'){
    var s = pay.session || {};
    self.keepalive = parseInt(s.keepalive_timeout_seconds, 10) || 10;
    self.vigilar(ws, self.keepalive + self.margen);
    if (ws._reconexion){
      /* reconexión pedida por Twitch: las suscripciones pasan solas a la sesión nueva (no se resuscribe) */
      ws._reconexion = false;
      var viejo = self.ws; self.ws = ws; self.wsNuevo = null; if (viejo !== ws) self.soltar(viejo);
      self.sesion = s; self.espera = 1000;
      self.estado('conectado', { login:self.login, n:Object.keys(self.activas).length, total:self.totalPedidas(), reconexion:true });
      return;
    }
    self.sesion = s; self.espera = 1000;
    self.suscribir(String(s.id || ''));
    return;
  }
  if (tipo === 'session_keepalive') return;
  if (tipo === 'session_reconnect'){
    var url = (pay.session || {}).reconnect_url;
    if (!url || ws !== self.ws) return;
    /* La URL la da Twitch: solo twitch.tv exacto o un subdominio (wss) o, en pruebas, una local */
    if (!(/^wss:\/\/([a-z0-9-]+\.)*twitch\.tv(:\d+)?\//i.test(url) || HW.esLocal(url, ['ws', 'wss']))) return;
    self.estado('reconectando', { motivo:'reconnect' });
    self.abrir(url, true);
    return;
  }
  if (tipo === 'notification'){
    var sub = pay.subscription || {}, ev = HW.normalizarEventSub(sub.type || meta.subscription_type, pay.event);
    if (ev && self.op.onEvento){ try { self.op.onEvento(ev); } catch(e){} }
    return;
  }
  if (tipo === 'revocation'){
    var rs = pay.subscription || {}, t = rs.type || meta.subscription_type, motivo = String(rs.status || '');
    delete self.activas[t];
    if (motivo === 'authorization_revoked' || motivo === 'user_removed') return self.morir('revocado', { tipo:t, motivo:motivo });
    self.estado('error', { tipos:[t], motivo:motivo });
  }
};
HW.EventSub.prototype.totalPedidas = function(){
  var ev = this.eventos;
  return HW.EVENTSUB_TIPOS.filter(function(d){ return ev[d.ev]; }).length;
};
/* POST /eventsub/subscriptions por cada tipo activado */
HW.EventSub.prototype.suscribir = function(sid){
  var self = this, ev = self.eventos;
  var lista = HW.EVENTSUB_TIPOS.filter(function(d){ return ev[d.ev]; });
  var res = { ok:[], permiso:[], red:[], otros:[], caducado:false };
  function uno(d, i){
    var versiones = self.versiones[d.type] ? [self.versiones[d.type]] : d.v;
    var v = versiones[i];
    return self.helix.post('/eventsub/subscriptions', {
      type:d.type, version:v, condition:d.cond(self.bid), transport:{ method:'websocket', session_id:sid }
    }).then(function(r){
      if (!self.sesion || String(self.sesion.id) !== sid) return;      /* la sesión cambió mientras tanto */
      if (r.status === 202 || r.status === 409){
        self.versiones[d.type] = v;
        self.activas[d.type] = (r.json && r.json.data && r.json.data[0] && r.json.data[0].id) || 'ya';
        res.ok.push(d.type); return;
      }
      if (r.status === 400 && i + 1 < versiones.length) return uno(d, i + 1);
      if (r.status === 401){ res.caducado = true; return; }
      if (r.status === 403){ res.permiso.push(d.ev); return; }
      if (r.status === 0){ res.red.push(d.type); return; }
      res.otros.push({ type:d.type, status:r.status });
    });
  }
  Promise.all(lista.map(function(d){ return uno(d, 0); })).then(function(){
    if (!self.vivo || !self.sesion || String(self.sesion.id) !== sid) return;
    if (res.caducado) return self.morir('caducado');
    var total = lista.length;
    var nuevosSinPermiso = res.permiso.filter(function(t, i, a){ return a.indexOf(t) === i && !self.avisados[t]; });
    nuevosSinPermiso.forEach(function(t){ self.avisados[t] = 1; });
    if (!res.ok.length && !res.red.length){
      /* Ninguna suscripción posible: Twitch cerraría la conexión a los 10 s y se repetiría sin fin */
      if (nuevosSinPermiso.length) self.estado('sin-permiso', { tipos:nuevosSinPermiso });
      if (res.otros.length) self.estado('error', { tipos:res.otros.map(function(o){ return o.type; }), status:res.otros[0].status, motivo:'suscripcion' });
      self.destruir();
      if (!nuevosSinPermiso.length && !res.otros.length) self.estado('error', { motivo:'sin-suscripciones' });
      return;
    }
    self.estado('conectado', { login:self.login, n:res.ok.length, total:total });
    if (nuevosSinPermiso.length) self.estado('sin-permiso', { tipos:nuevosSinPermiso });
    if (res.red.length) self.estado('error', { tipos:res.red, status:0, motivo:'red' });
    if (res.otros.length) self.estado('error', { tipos:res.otros.map(function(o){ return o.type; }), status:res.otros[0].status, motivo:'suscripcion' });
  });
};
HW.EventSub.prototype.cerrado = function(ws, code){
  var self = this;
  if (ws._viejo) return;
  if (ws === self.wsNuevo){ self.wsNuevo = null; return; }   /* falló la reconexión: sigue la vieja hasta que cierre */
  if (ws !== self.ws) return;
  clearTimeout(self._vig);
  if (self.wsNuevo){
    /* Twitch cerró la vieja antes del welcome de la nueva: la nueva pasa a ser la principal */
    self.ws = self.wsNuevo; self.wsNuevo = null; self.vigilar(self.ws, 15);
    return;
  }
  self.ws = null; self.sesion = null; self.activas = {};
  if (!self.vivo) return;
  self.estado('reconectando', { code:code || 0 });
  self.reintentar();
};
HW.EventSub.prototype.reintentar = function(ya){
  var self = this; if (!self.vivo || self._t) return;
  self._t = setTimeout(function(){ self._t = null; if (self.vivo) self.abrir(self.url, false); }, ya ? 0 : self.espera);
  if (!ya) self.espera = Math.min(self.espera * 2, 30000);
};
/* Se para para siempre (token caducado/revocado o sin suscripciones posibles) */
HW.EventSub.prototype.morir = function(estado, detalle){
  if (!this.vivo) return;
  this.destruir();
  if (estado === 'caducado' || estado === 'revocado') this.estado(estado, detalle);
  else this.estado('error', { motivo:estado });
};
HW.EventSub.prototype.destruir = function(){
  this.vivo = false;
  clearTimeout(this._t); clearTimeout(this._vig); clearInterval(this._val);
  this._t = null;
  this.soltar(this.ws); this.soltar(this.wsNuevo);
  this.ws = null; this.wsNuevo = null; this.sesion = null;
};

/* ── 5. Nieve con copos HTML ────────────────────────────────────
   HW.nieve(div, { cantidad, viento (-1..1), tam (escala), semilla, acumula, giro (false = sin giro: escenas muy cargadas) })
   · div: contenedor con position (fixed/absolute/relative) o el body.
   · Cada copo = 3 elementos: un envoltorio que cae (hw-nevar, lineal) con la
     altura de la capa, un div que se mece y gira despacio (hw-mecer-suave) y el
     copo. Solo se animan transform/opacity. 3 profundidades: lejos (chicos,
     tenues, lentos), medio y cerca (grandes, opacos, rápidos y con más deriva).
   · El copo es un div con imagen de fondo: las formas de A.copo(0) y A.copo(1)
     (nunca la 2) se generan UNA vez como data URI SVG, así cada copo cuesta lo
     mismo que un círculo. Los lejanos usan una versión de trazo más gordo y
     nunca bajan de COPO_MIN px: siguen leyéndose como copos, no como puntos.
   · Tope duro: 300 copos.
   Devuelve { el, copos, destruir() }. */
var COPO_MIN = 11, COPO_MAX = 42;
function cssCopos(){
  if (document.getElementById('hw-copos')) return;
  var imagen = function(n, grosor){
    /* Sin contorno oscuro (a este tamaño ensucia): solo un filo azulado muy suave para que se lea sobre fondos claros */
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="-11.4 -11.4 22.8 22.8" width="64" height="64">' +
      A.copo(n, { grosor:grosor, borde:'rgba(84,96,170,.4)', anchoBorde:grosor + .6 }) + '</svg>';
    return 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';
  };
  var st = document.createElement('style'); st.id = 'hw-copos';
  /* f0-f1: cerca y medio · g0-g1: lejos (mismo copo con el trazo más gordo) */
  st.textContent = '.hw-copo.f0{background-image:' + imagen(0, 1.45) + '}.hw-copo.f1{background-image:' + imagen(1, 1.7) + '}' +
    '.hw-copo.g0{background-image:' + imagen(0, 1.7) + '}.hw-copo.g1{background-image:' + imagen(1, 2) + '}';
  document.head.appendChild(st);
}
/* Franja de nieve del borde de abajo (pieza Nieve, op.acumula). Cada x tiene su altura: crece despacio hasta
   el tope y la máquina del duende la baja solo por donde ya pasó (HW.nieve().franja: raspar, pala, llenar…).
   Se guarda como fracción del tope, así un lienzo de otro tamaño no cambia nada. Es un canvas que se repinta
   una vez por segundo; solo mientras pasa el duende se repinta en cada fotograma. */
var TOPE_NIEVE = 31 / 1080;   /* a tam 1, en 1920×1080: menos que los 43 px que llegaban a medir los montoncitos */
function ondas(rnd, largos){
  var fase = largos.map(function(){ return rnd() * 6.2832; });
  return function(x){
    var s = 0, peso = 0;
    largos.forEach(function(l, i){ var a = l / largos[0]; s += a * Math.sin(x / l * 6.2832 + fase[i]); peso += a; });
    return s / peso;
  };
}
function franjaNieve(capa, op, tam){
  var rnd = HW.azar((op.semilla || 7) * 31 + 5);
  var cv = document.createElement('canvas'); cv.className = 'hw-franja';
  var g = cv.getContext('2d'), dpr = Math.min(2, window.devicePixelRatio || 1);
  var W = 0, H = 0, tope = 0, alto = 0, degradado = null;
  var n = Math.max(40, Math.ceil((capa.clientWidth || window.innerWidth || 1920) / 6) + 1);
  var relleno = Math.max(5, +op.relleno || 250);       /* segundos para volver al tope */
  /* tam mueve poco la altura: copos grandes no pueden tapar el juego */
  var porTam = Math.max(.85, Math.min(1.3, 1 + (tam - 1) * .3));
  var per = [], bajo = [], f = [], vel = [], mult = [], i;
  /* per: la forma final (lomas suaves, la más alta toca el tope) · mult: cada x crece a su ritmo */
  var loma = ondas(rnd, [310, 170, 92]), ritmoX = ondas(rnd, [420, 150]), hmax = 0;
  for (i = 0; i < n; i++){ per[i] = .8 + .26 * loma(i * 6); hmax = Math.max(hmax, per[i]); }
  for (i = 0; i < n; i++){
    per[i] = per[i] / hmax; f[i] = op.lleno ? per[i] : 0;
    mult[i] = 1.1 + .1 * ritmoX(i * 6); vel[i] = 0; bajo[i] = 0;
  }
  var pala = null, ultimo = performance.now(), reloj = 0, alLlenarse = null, sucio = true;
  function ritmo(k, seg){ vel[k] = Math.max(0, per[k] - f[k]) * mult[k] / seg; }
  for (i = 0; i < n; i++) ritmo(i, relleno);
  function equis(k){ return k * W / (n - 1); }
  function medir(){
    W = capa.clientWidth || window.innerWidth || 1920;
    H = capa.clientHeight || window.innerHeight || 1080;
    tope = Math.max(8, (op.vertical ? W : H) * TOPE_NIEVE * porTam);   /* vertical: mide lo mismo en px que en horizontal */
    alto = Math.ceil(tope * 2.8 + 8);
    cv.width = Math.round(W * dpr); cv.height = Math.round(alto * dpr);
    cv.style.height = alto + 'px';
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    degradado = g.createLinearGradient(0, alto - tope * .75, 0, alto);
    degradado.addColorStop(0, '#fffdf7'); degradado.addColorStop(.72, '#f4f1ea'); degradado.addColorStop(1, '#dfe1f0');
    sucio = true;
  }
  /* Lo que se ve en cada x: la nieve y, delante de la pala, el montoncito que va empujando */
  function vista(k){
    var h = f[k] * tope;
    if (!pala || !pala.monton) return h;
    /* u: px por delante del filo. La nieve se mete en el hueco de la pala, se redondea y baja hasta el suelo */
    var u = (equis(k) - pala.x) * pala.dir, L = tope * 4.2, plano = L * .2;
    if (u <= -20 || u >= L) return h;
    var s = Math.min(1, (u + 20) / 15), c = u > plano ? Math.cos((u - plano) / (L - plano) * 1.5708) : 1;
    return h + pala.monton * s * s * (3 - 2 * s) * c * c * (1 + .1 * Math.sin(u * .13 + pala.fase) + .06 * Math.sin(u * .31 - pala.fase * 1.7));
  }
  function trazar(ys){
    g.moveTo(-6, ys[0]);
    for (var k = 1; k < n; k++){
      var x0 = equis(k - 1), x1 = equis(k);
      g.quadraticCurveTo(x0, ys[k - 1], (x0 + x1) / 2, (ys[k - 1] + ys[k]) / 2);
    }
    g.lineTo(W + 6, ys[n - 1]);
  }
  var ys = [];
  function pintar(){
    sucio = false;
    g.clearRect(0, 0, W, alto);
    for (var k = 0; k < n; k++) ys[k] = alto - vista(k);
    g.beginPath(); trazar(ys); g.lineTo(W + 6, alto + 4); g.lineTo(-6, alto + 4); g.closePath();
    g.fillStyle = degradado; g.fill();
    /* filo azulado muy suave, como el de los copos: se lee sobre fondos claros */
    g.beginPath(); trazar(ys); g.lineWidth = 1.5; g.strokeStyle = 'rgba(84,96,170,.42)'; g.stroke();
    for (k = 0; k < n; k++) ys[k] += 2;
    g.beginPath(); trazar(ys); g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,.9)'; g.stroke();
  }
  function crecer(seg){
    for (var k = 0; k < n; k++) if (f[k] < per[k]){ f[k] = Math.min(per[k], f[k] + vel[k] * seg); sucio = true; }
  }
  function lleno(){ for (var k = 0; k < n; k++) if (f[k] < per[k] - .002) return false; return true; }
  function latido(){
    var ahora = performance.now(), seg = Math.min(5, (ahora - ultimo) / 1000);
    ultimo = ahora; crecer(seg);
    if (sucio && !pala) pintar();
    if (alLlenarse && lleno()) alLlenarse();
  }
  capa.appendChild(cv);
  medir(); pintar();
  reloj = setInterval(latido, 1000);
  window.addEventListener('resize', medir);
  return {
    el: cv,
    tope: function(){ return tope; },
    /* Altura de la nieve en cada columna, en px (sin el montoncito que empuja la pala) */
    alturas: function(){ return f.map(function(v){ return v * tope; }); },
    equis: equis,
    lleno: lleno,
    alLlenarse: function(fn){ alLlenarse = fn; },
    /* Empieza una pasada: cómo va a quedar el suelo esta vez (bajo, sin llegar a vaciarse, con bordes irregulares) */
    pasada: function(){
      var ru = ondas(rnd, [120, 47, 19]), d = ondas(rnd, [33, 11]);
      for (var k = 0; k < n; k++) bajo[k] = .375 + .065 * ru(k * 6) + .035 * d(k * 6);
    },
    /* La pala ya pasó entre x0 y x1: ahí baja y vuelve a crecer despacio */
    raspar: function(x0, x1){
      var a = Math.max(0, Math.ceil(Math.min(x0, x1) / W * (n - 1))), b = Math.min(n - 1, Math.floor(Math.max(x0, x1) / W * (n - 1)));
      for (var k = a; k <= b; k++) if (f[k] > bajo[k]){ f[k] = bajo[k]; ritmo(k, relleno); sucio = true; }
    },
    /* Dónde va la pala este fotograma (null al terminar). monton: px por encima de la nieve */
    pala: function(p){ pala = p; sucio = true; },
    /* Llega al tope en seg segundos (Probar). Con seg 0, de golpe */
    llenar: function(seg){
      for (var k = 0; k < n; k++){ if (seg) ritmo(k, seg); else f[k] = per[k]; }
      sucio = true;
    },
    /* Un paso de reloj a mano: lo usa el bucle del duende y las pruebas */
    avanzar: function(seg){ ultimo = performance.now(); crecer(seg); if (sucio) pintar(); },
    manual: function(si){ clearInterval(reloj); if (!si) reloj = setInterval(latido, 1000); },
    parar: function(){ clearInterval(reloj); window.removeEventListener('resize', medir); }
  };
}
HW.nieve = function(div, op){
  op = op || {};
  var rnd = HW.azar(op.semilla || 7);
  cssCopos();
  var total = Math.round(+op.cantidad); if (isNaN(total)) total = 120;
  total = Math.max(0, Math.min(300, total));
  var viento = Math.max(-1, Math.min(1, +op.viento || 0));
  var tam = Math.max(0.3, Math.min(3, +op.tam || 1));
  var capa = document.createElement('div'); capa.className = 'hw-nieve';
  div.appendChild(capa);
  var W = capa.clientWidth || div.clientWidth || window.innerWidth || 1920;
  var H = capa.clientHeight || div.clientHeight || window.innerHeight || 1080;
  var recorrido = H + 120;                       /* lo que baja un copo (px) */
  var ritmo = Math.max(0.35, recorrido / 1200);  /* misma velocidad en capas chicas */
  var chica = Math.max(.7, Math.min(1, H / 1080 + .3));  /* en una ventanita los copos no se ven enormes */
  var PROF = [
    { parte:.45, t:[13, 16], o:[.5, .68],  dur:[17, 24], a:[4, 8],   v:.55, f:'g' },
    { parte:.35, t:[18, 23], o:[.72, .88], dur:[11, 15], a:[8, 14],  v:.8,  f:'f' },
    { parte:.20, t:[26, 34], o:[.9, 1],    dur:[7, 10],  a:[12, 22], v:1,   f:'f' }
  ];
  var entre = function(r){ return r[0] + rnd() * (r[1] - r[0]); };
  var frag = document.createDocumentFragment(), n = 0;
  PROF.forEach(function(pr, ip){
    var cuantos = ip === PROF.length - 1 ? total - n : Math.round(total * pr.parte);
    for (var i = 0; i < cuantos; i++, n++){
      var dur = entre(pr.dur) * ritmo, vx = viento * recorrido * 0.6 * pr.v;
      /* con viento, los copos nacen también fuera del lado de donde sopla */
      var x0 = Math.min(0, -vx), x1 = W + Math.max(0, -vx);
      var x = x0 + rnd() * (x1 - x0), s = Math.min(COPO_MAX, Math.max(COPO_MIN, entre(pr.t) * tam * chica));
      var cae = document.createElement('div'); cae.className = 'hw-copo-cae';
      cae.style.left = (x / W * 100).toFixed(3) + '%';
      cae.style.animationDuration = dur.toFixed(2) + 's';
      cae.style.animationDelay = (-rnd() * dur).toFixed(2) + 's';
      cae.style.setProperty('--vx', vx.toFixed(1) + 'px');
      var mece = document.createElement('div'); mece.className = 'hw-copo-mece';
      var dm = 2.4 + rnd() * 3.2;
      mece.style.animationDuration = dm.toFixed(2) + 's';
      mece.style.animationDelay = (-rnd() * dm).toFixed(2) + 's';
      mece.style.setProperty('--a', entre(pr.a).toFixed(1) + 'px');
      /* giro lento solo en los de cerca (va en el mismo vaivén): en los chicos no se nota y girar capas cuesta */
      var giro = 14 + rnd() * 26;
      mece.style.setProperty('--g', (ip === PROF.length - 1 && op.giro !== false ? giro.toFixed(1) : '0') + 'deg');
      mece.style.marginLeft = (-s / 2).toFixed(1) + 'px';
      var c = document.createElement('i'); c.className = 'hw-copo ' + pr.f + (rnd() < .55 ? '0' : '1');
      c.style.width = c.style.height = s.toFixed(1) + 'px';
      c.style.opacity = entre(pr.o).toFixed(2);
      c.style.transform = 'rotate(' + (rnd() * 60).toFixed(0) + 'deg)';
      mece.appendChild(c); cae.appendChild(mece); frag.appendChild(cae);
    }
  });
  capa.appendChild(frag);
  /* Nieve que se junta abajo */
  var franja = op.acumula ? franjaNieve(capa, op, tam) : null;
  return {
    el: capa, copos: n, franja: franja,
    alturas: function(){ return franja ? franja.alturas() : []; },
    destruir: function(){ if (franja) franja.parar(); if (capa.parentNode) capa.parentNode.removeChild(capa); }
  };
};

/* ── 6. Arte SVG propio ─────────────────────────────────────────
   Todo devuelve un string SVG (sin <svg>), estilo redondeado con contorno
   --tinta. Los ids internos (degradados, recortes) son únicos por llamada;
   si se pasa op.id se usa como prefijo (p. ej. '__CID__' para plantillas
   que luego se reemplazan por un id único, como en el desfile).
   Fase 7: HW.arte.jengibre (casa, ventana, gomita, glaseado) y HW.pantalla
   van justo antes de la guirnalda (sección 7).
   ───────────────────────────────────────────────────────────── */
var A = HW.arte = {};
var TINTA = '#1d1a2e';
HW.TINTA = TINTA;
var C = HW.COLORES = {
  rojo:'#e8424f', rojoOsc:'#b52a3a', verde:'#2f8f5b', verdeOsc:'#1f5a3a', verdeClaro:'#4fb37a',
  dorado:'#ffcf5c', doradoOsc:'#e0a530', nieve:'#fffaf0', canela:'#c47a3d', canelaOsc:'#8f5428',
  crema:'#fff4dd', rosa:'#ff9fb4', azul:'#4fb3ff'
};
var nId = 0;
function prefijo(op){ return op && op.id ? String(op.id) : 'nv' + (++nId); }
function f1(n){ return (Math.round(n * 10) / 10).toString(); }
function circ(cx, cy, r, fill, extra){ return '<circle cx="'+f1(cx)+'" cy="'+f1(cy)+'" r="'+f1(r)+'" fill="'+fill+'"'+(extra || '')+'/>'; }
var TRAZO = ' stroke="'+TINTA+'" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"';

/* Chispa de 4 puntas centrada en 0,0 (radio 10) */
A.chispa = function(color){ return '<path d="M0-10Q1.6-1.6 10 0Q1.6 1.6 0 10Q-1.6 1.6-10 0Q-1.6-1.6 0-10Z" fill="'+(color || '#fff1b8')+'"/>'; };

/* Foco tipo C9 colgando hacia abajo desde 0,0.
   Capa apagada (color oscurecido) + capa encendida (op.clase/op.estilo para
   animar su opacidad) + contorno encima. */
var BULBO = 'M-8 11C-15 22-13 37 0 47 13 37 15 22 8 11Z';
A.foco = function(color, op){
  op = op || {};
  var apagado = HW.mezcla(color, TINTA, .5);
  return '<rect x="-7" y="0" width="14" height="12" rx="3" fill="#2c5e40" stroke="'+TINTA+'" stroke-width="2"/>' +
    '<path d="'+BULBO+'" fill="'+apagado+'"/>' +
    '<path d="'+BULBO+'" fill="'+color+'"' + (op.clase ? ' class="'+op.clase+'"' : '') + (op.estilo ? ' style="'+op.estilo+'"' : '') + '/>' +
    '<path d="'+BULBO+'" fill="none" stroke="'+TINTA+'" stroke-width="2" stroke-linejoin="round"/>' +
    '<path d="M-3.5 17c-4 6-4 13-1.5 18" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".55"/>';
};

/* Estrella esponjosa de 5 puntas centrada en 0,0.
   op: { r (20), color (dorado), cara (false), brillo (false) } */
function caminoEstrella(R){
  var ri = R * 0.5, rc = R * 1.55, d = '', i, a;
  var ang = function(k){ return -Math.PI / 2 + k * Math.PI / 5; };
  a = ang(9); d = 'M' + f1(ri * Math.cos(a)) + ' ' + f1(ri * Math.sin(a));
  for (i = 0; i < 5; i++){
    var ao = ang(2 * i), ai = ang(2 * i + 1);
    d += 'Q' + f1(rc * Math.cos(ao)) + ' ' + f1(rc * Math.sin(ao)) + ' ' + f1(ri * Math.cos(ai)) + ' ' + f1(ri * Math.sin(ai));
  }
  return d + 'Z';
}
A.estrella = function(op){
  op = op || {};
  var R = op.r || 20, col = op.color || C.dorado, claro = HW.mezcla(col, '#ffffff', .45);
  var s = '<g class="nv-estrella">';
  if (op.brillo) s += circ(0, 0, R * 1.9, col, ' opacity=".18"') + circ(0, 0, R * 1.35, col, ' opacity=".22"');
  s += '<path d="'+caminoEstrella(R)+'" fill="'+col+'"'+TRAZO+'/>' +
    '<path d="'+caminoEstrella(R * .55)+'" fill="'+claro+'" opacity=".55" transform="translate('+f1(-R*.06)+' '+f1(-R*.08)+')"/>' +
    '<path d="M'+f1(-R*.42)+' '+f1(-R*.12)+'Q'+f1(-R*.38)+' '+f1(-R*.42)+' '+f1(-R*.12)+' '+f1(-R*.5)+'" fill="none" stroke="#fff" stroke-width="'+f1(Math.max(1.5, R*.09))+'" stroke-linecap="round" opacity=".75"/>';
  if (op.cara){
    s += circ(-R*.2, R*.02, R*.075, TINTA) + circ(R*.2, R*.02, R*.075, TINTA) +
      circ(-R*.17, -R*.01, R*.025, '#fff') + circ(R*.23, -R*.01, R*.025, '#fff') +
      '<path d="M'+f1(-R*.1)+' '+f1(R*.14)+'Q0 '+f1(R*.25)+' '+f1(R*.1)+' '+f1(R*.14)+'" fill="none" stroke="'+TINTA+'" stroke-width="'+f1(Math.max(1.4, R*.06))+'" stroke-linecap="round"/>' +
      '<ellipse cx="'+f1(-R*.34)+'" cy="'+f1(R*.14)+'" rx="'+f1(R*.09)+'" ry="'+f1(R*.05)+'" fill="'+C.rosa+'" opacity=".8"/>' +
      '<ellipse cx="'+f1(R*.34)+'" cy="'+f1(R*.14)+'" rx="'+f1(R*.09)+'" ry="'+f1(R*.05)+'" fill="'+C.rosa+'" opacity=".8"/>';
  }
  return s + '</g>';
};

/* Copo de nieve SVG centrado en 0,0 (radio ~10). n = 0, 1 o 2 (variante).
   op (opcional, para la nieve que cae): { grosor (trazo blanco, 2.2), borde (color del contorno; de fábrica la tinta), anchoBorde } */
A.copo = function(n, op){
  op = op || {};
  n = Math.abs(parseInt(n, 10) || 0) % 3;
  var grosor = op.grosor || 2.2, borde = op.borde || TINTA, anchoBorde = op.anchoBorde || 4.4, fino = op.borde ? anchoBorde - grosor : 0;
  var brazo, brazos = 6, extra = '';
  if (n === 0) brazo = 'M0 0V-10M0-6L-3.2-9M0-6L3.2-9M0-3L-2-5M0-3L2-5';
  else if (n === 1){ brazo = 'M0-2.5V-8.2M0-5.2L-2.6-7M0-5.2L2.6-7'; extra = 'c'; }
  else { brazo = 'M0 0V-10'; brazos = 8; }
  var una = function(color, w){
    var s = '';
    for (var i = 0; i < brazos; i++){
      var largo = (n === 2 && i % 2) ? ' transform="rotate('+(i * 360 / brazos)+') scale(.62)"' : ' transform="rotate('+(i * 360 / brazos)+')"';
      s += '<path d="'+brazo+'"'+largo+'/>';
    }
    return '<g fill="none" stroke="'+color+'" stroke-width="'+w+'" stroke-linecap="round" stroke-linejoin="round">' + s + '</g>';
  };
  var s = '<g class="nv-copo">' + una(borde, anchoBorde) + una(C.nieve, grosor);
  if (extra === 'c'){
    s += circ(0, 0, 3.2, C.nieve, ' stroke="'+borde+'" stroke-width="'+(fino || 1.8)+'"');
    for (var i = 0; i < 6; i++){ var a = (i * 60 - 90) * Math.PI / 180; s += circ(9.4 * Math.cos(a), 9.4 * Math.sin(a), 1.7, C.nieve, ' stroke="'+borde+'" stroke-width="'+(fino || 1.2)+'"'); }
  } else if (n === 2){
    s += circ(0, 0, 2.4, C.nieve, ' stroke="'+TINTA+'" stroke-width="1.4"');
  }
  return s + '</g>';
};

/* Pino centrado abajo en 0,0 (alto ~205, ancho ~150).
   op: { detalle:'silueta'|'simple'|'completo', nieve (bool), luces (true | [colores] | false),
         color, semilla }
   · silueta: una sola mancha de color sin contorno (para planos lejanos)
   · simple: tres pisos con contorno y tronco
   · completo: + sombreado, guirnalda dorada y (si luces) foquitos que titilan */
var PISOS = [ /* [abajo, arriba, ancho, ondas] */
  [-30, -112, 150, 4], [-78, -158, 118, 3], [-122, -205, 84, 3]
];
function piso(yb, yt, w, ondas){
  var x = -w / 2, paso = w / ondas, d = 'M' + f1(x) + ' ' + f1(yb);
  for (var i = 0; i < ondas; i++) d += 'Q' + f1(x + paso * (i + .5)) + ' ' + f1(yb + 11) + ' ' + f1(x + paso * (i + 1)) + ' ' + f1(yb);
  return d + 'L4.5 ' + f1(yt + 4) + 'Q0 ' + f1(yt - 3) + ' -4.5 ' + f1(yt + 4) + 'Z';
}
/* Gorrito de nieve en la punta de un piso (parte de arriba del triángulo, borde ondulado) */
function nievePiso(yb, yt, w){
  var hh = (yb - yt) * .36, y = yt + hh, mw = (w / 2) * (hh / (yb - yt)) + 3, d = 'M' + f1(-mw) + ' ' + f1(y);
  d += 'Q' + f1(-mw * .5) + ' ' + f1(y + 8) + ' 0 ' + f1(y + 1) + 'Q' + f1(mw * .5) + ' ' + f1(y + 9) + ' ' + f1(mw) + ' ' + f1(y);
  return d + 'L4.5 ' + f1(yt + 4) + 'Q0 ' + f1(yt - 3) + ' -4.5 ' + f1(yt + 4) + 'Z';
}
A.pino = function(op){
  op = op || {};
  var det = op.detalle || 'simple', col = op.color || C.verde, rnd = HW.azar(op.semilla || 3);
  var s = '<g class="nv-pino">';
  if (det === 'silueta'){
    s += '<rect x="-10" y="-34" width="20" height="34" rx="3" fill="'+col+'"/>';
    PISOS.forEach(function(p){ s += '<path d="'+piso(p[0], p[1], p[2], p[3])+'" fill="'+col+'"/>'; });
    return s + '</g>';
  }
  var osc = HW.mezcla(col, TINTA, .35), claro = HW.mezcla(col, '#d8f5c0', .3);
  s += '<rect x="-12" y="-36" width="24" height="36" rx="5" fill="'+C.canelaOsc+'"'+TRAZO+'/>' +
    '<path d="M-5-30V-6" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".18"/>';
  PISOS.forEach(function(p){
    var yb = p[0], yt = p[1], w = p[2];
    s += '<path d="'+piso(yb, yt, w, p[3])+'" fill="'+col+'"'+TRAZO+'/>';
    if (det === 'completo'){
      /* sombra del lado derecho y reflejo del izquierdo */
      s += '<path d="M4 '+f1(yt + 8)+'L'+f1(w / 2 - 6)+' '+f1(yb - 2)+'Q'+f1(w / 4)+' '+f1(yb + 6)+' 6 '+f1(yb + 2)+'Z" fill="'+osc+'" opacity=".45"/>' +
        '<path d="M-6 '+f1(yt + 16)+'L'+f1(-w / 2 + 16)+' '+f1(yb - 8)+'" stroke="'+claro+'" stroke-width="3" stroke-linecap="round" opacity=".55"/>';
    }
    if (op.nieve) s += '<path d="'+nievePiso(yb, yt, w)+'" fill="'+C.nieve+'" stroke="'+TINTA+'" stroke-width="2.5" stroke-linejoin="round"/>';
  });
  if (det === 'completo'){
    var cols = op.luces === true || !op.luces ? (HW.PALETAS ? HW.PALETAS.clasica : [C.rojo, C.dorado, C.azul]) : op.luces;
    PISOS.forEach(function(p, ip){
      var yb = p[0], yt = p[1], w = p[2], h = yb - yt;
      /* guirnalda dorada en diagonal: de un borde a otro del piso */
      var ya = yt + h * .45, yb2 = yt + h * .8, xa = -(w / 2) * .45 - 2, xb = (w / 2) * .8;
      var cx = (xa + xb) / 2, cy = Math.max(ya, yb2) + 8;
      s += '<path d="M'+f1(xa)+' '+f1(ya)+'Q'+f1(cx)+' '+f1(cy)+' '+f1(xb)+' '+f1(yb2)+'" fill="none" stroke="'+C.doradoOsc+'" stroke-width="4.5" stroke-linecap="round"/>' +
        '<path d="M'+f1(xa)+' '+f1(ya)+'Q'+f1(cx)+' '+f1(cy)+' '+f1(xb)+' '+f1(yb2)+'" fill="none" stroke="'+C.dorado+'" stroke-width="2" stroke-linecap="round" stroke-dasharray="1 5"/>';
      if (op.luces){
        var k = 5 - ip;
        for (var i = 0; i < k; i++){
          var t = (i + .5) / k, x = (1-t)*(1-t)*xa + 2*(1-t)*t*cx + t*t*xb, y = (1-t)*(1-t)*ya + 2*(1-t)*t*cy + t*t*yb2;
          var c = cols[(i + ip * 2) % cols.length], dur = (1.8 + rnd() * 2.4).toFixed(2), del = (-rnd() * 4).toFixed(2);
          s += '<g transform="translate('+f1(x)+' '+f1(y + 3)+')">' +
            '<g class="hw-luz" style="animation-duration:'+dur+'s;animation-delay:'+del+'s">' + circ(0, 0, 9, c, ' opacity=".35"') + '</g>' +
            circ(0, 0, 4.4, c, ' stroke="'+TINTA+'" stroke-width="1.8"') + circ(-1.3, -1.4, 1.3, '#fff', ' opacity=".8"') + '</g>';
        }
      }
    });
  }
  return s + '</g>';
};

/* Regalo centrado abajo en 0,0. op: { color, lazo, w (60), h (46) } */
A.regalo = function(op){
  op = op || {};
  var w = op.w || 60, h = op.h || 46, col = op.color || C.rojo, lazo = op.lazo || C.dorado;
  var tapa = HW.mezcla(col, '#ffffff', .18), osc = HW.mezcla(col, TINTA, .3), lz = HW.mezcla(lazo, TINTA, .25);
  var yt = -h - 12;
  return '<g class="nv-regalo">' +
    '<rect x="'+f1(-w/2)+'" y="'+f1(-h)+'" width="'+f1(w)+'" height="'+f1(h)+'" rx="6" fill="'+col+'"'+TRAZO+'/>' +
    '<rect x="'+f1(w/2 - w*.22)+'" y="'+f1(-h + 3)+'" width="'+f1(w*.2)+'" height="'+f1(h - 6)+'" rx="4" fill="'+osc+'" opacity=".35"/>' +
    '<rect x="-6" y="'+f1(-h)+'" width="12" height="'+f1(h)+'" fill="'+lazo+'" stroke="'+TINTA+'" stroke-width="2.5"/>' +
    '<rect x="'+f1(-w/2 - 4)+'" y="'+f1(yt)+'" width="'+f1(w + 8)+'" height="15" rx="6" fill="'+tapa+'"'+TRAZO+'/>' +
    '<rect x="-6" y="'+f1(yt)+'" width="12" height="15" fill="'+lazo+'" stroke="'+TINTA+'" stroke-width="2.5"/>' +
    '<path d="M'+f1(-w/2 + 2)+' '+f1(yt + 4)+'H'+f1(-10)+'" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".45"/>' +
    /* moño: dos lazadas, dos colitas y el nudo */
    '<path d="M0 '+f1(yt)+'C-6 '+f1(yt - 16)+' -24 '+f1(yt - 18)+' -22 '+f1(yt - 6)+'C-21 '+f1(yt + 1)+' -8 '+f1(yt + 1)+' 0 '+f1(yt)+'Z" fill="'+lazo+'"'+TRAZO+'/>' +
    '<path d="M0 '+f1(yt)+'C6 '+f1(yt - 16)+' 24 '+f1(yt - 18)+' 22 '+f1(yt - 6)+'C21 '+f1(yt + 1)+' 8 '+f1(yt + 1)+' 0 '+f1(yt)+'Z" fill="'+lazo+'"'+TRAZO+'/>' +
    '<path d="M-14 '+f1(yt - 8)+'Q-10 '+f1(yt - 11)+' -6 '+f1(yt - 6)+'M14 '+f1(yt - 8)+'Q10 '+f1(yt - 11)+' 6 '+f1(yt - 6)+'" fill="none" stroke="'+lz+'" stroke-width="2" stroke-linecap="round"/>' +
    '<ellipse cx="0" cy="'+f1(yt - 1)+'" rx="6" ry="5" fill="'+lazo+'"'+TRAZO+'/>' +
    '</g>';
};

/* Calceta colgando de 0,0 (alto ~88, la punta mira a la derecha).
   op: { color (rojo), patron:'rayas'|'lunares'|'copo'|'liso', id } */
var CALCETA = 'M-14 20V64Q-14 87 8 87H25Q41 87 41 73Q41 60 27 60H14V20Z';
A.calceta = function(op){
  op = op || {};
  var p = prefijo(op), col = op.color || C.rojo, pat = op.patron || 'rayas';
  var cc = HW.rgb(col), dib = (cc[0] > 215 && cc[1] > 215) ? C.rojo : C.nieve;
  var parche = HW.mezcla(col, C.nieve, .7);
  var s = '<g class="nv-calceta"><defs><clipPath id="'+p+'-cal"><path d="'+CALCETA+'"/></clipPath></defs>' +
    '<path d="M-5 8Q-6-3 0-3Q6-3 5 8" fill="none" stroke="'+TINTA+'" stroke-width="2.6" stroke-linecap="round"/>' +
    '<path d="'+CALCETA+'" fill="'+col+'"/>' +
    '<g clip-path="url(#'+p+'-cal)">';
  if (pat === 'rayas'){ for (var y = 30; y < 90; y += 14) s += '<rect x="-20" y="'+y+'" width="70" height="6" fill="'+dib+'" opacity=".9"/>'; }
  else if (pat === 'lunares'){
    [[-6,30],[6,40],[-6,50],[6,60],[-4,72],[20,74],[32,70]].forEach(function(q){ s += circ(q[0], q[1], 3.4, dib, ' opacity=".9"'); });
  }
  else if (pat === 'copo'){
    s += '<g transform="translate(0 44) scale(1.05)">' + A.copo(0) + '</g><g transform="translate(26 73) scale(.6)">' + A.copo(1) + '</g>';
  }
  s += circ(31, 75, 13, parche) + circ(-14, 80, 12, parche) + '</g>' +
    '<path d="'+CALCETA+'" fill="none"'+TRAZO+'/>' +
    '<path d="M-8 28V58" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".3"/>' +
    '<rect x="-19" y="5" width="38" height="19" rx="8" fill="'+C.nieve+'"'+TRAZO+'/>' +
    '<path d="M-12 12h6M2 11h7M-4 18h5" stroke="#d9dcef" stroke-width="2.4" stroke-linecap="round"/>' +
    '</g>';
  return s;
};

/* Bastón de caramelo colgando de 0,0 (gancho arriba, alto ~84) */
A.baston = function(){
  var d = 'M10 80V16Q10 1-2 1Q-14 1-14 14';
  return '<g class="nv-baston">' +
    '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="15" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="'+d+'" fill="none" stroke="'+C.nieve+'" stroke-width="9" stroke-linecap="round"/>' +
    '<path d="'+d+'" fill="none" stroke="'+C.rojo+'" stroke-width="9" stroke-dasharray="6 7"/>' +
    '<path d="M7 74V18" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" opacity=".6"/>' +
    '</g>';
};

/* Bola de árbol colgando de 0,0 (alto ~50) */
A.bola = function(color){
  var col = color || C.rojo, claro = HW.mezcla(col, '#ffffff', .4), osc = HW.mezcla(col, TINTA, .3);
  return '<g class="nv-bola">' +
    '<circle cx="0" cy="1" r="3.2" fill="none" stroke="'+C.doradoOsc+'" stroke-width="2"/>' +
    circ(0, 31, 18, col, TRAZO) +
    '<path d="M6 46Q16 42 17 31" fill="none" stroke="'+osc+'" stroke-width="4" stroke-linecap="round" opacity=".45"/>' +
    '<path d="M-16.2 30Q-11 25-5.5 30T5.5 30T16.2 30" fill="none" stroke="'+claro+'" stroke-width="3" stroke-linecap="round"/>' +
    '<ellipse cx="-7" cy="22" rx="4.5" ry="6.5" transform="rotate(30 -7 22)" fill="#fff" opacity=".6"/>' +
    '<rect x="-6" y="4" width="12" height="9" rx="2.5" fill="'+C.dorado+'" stroke="'+TINTA+'" stroke-width="2.4"/>' +
    '</g>';
};

/* Acebo (tres hojas y tres bayas) centrado en 0,0, ancho ~76 */
var HOJA_ACEBO = 'M0 0Q4-9 9-6Q12-13 18-9Q22-15 27-9Q32-10 36 0Q32 10 27 9Q22 15 18 9Q12 13 9 6Q4 9 0 0Z';
A.acebo = function(){
  var hoja = function(rot){
    return '<g transform="rotate('+rot+')"><path d="'+HOJA_ACEBO+'" fill="'+C.verde+'" stroke="'+TINTA+'" stroke-width="2.6" stroke-linejoin="round"/>' +
      '<path d="M4 0Q18-2 32 0" fill="none" stroke="'+C.verdeOsc+'" stroke-width="1.8" stroke-linecap="round"/>' +
      '<path d="M8-3Q14-6 20-5" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" opacity=".35"/></g>';
  };
  var baya = function(x, y){ return circ(x, y, 6, C.rojo, ' stroke="'+TINTA+'" stroke-width="2.2"') + circ(x - 2, y - 2, 1.6, '#fff', ' opacity=".8"'); };
  return '<g class="nv-acebo">' + hoja(-18) + hoja(198) + hoja(-100) + baya(-5, 1) + baya(6, -1) + baya(0, 9) + '</g>';
};

/* Muérdago colgando de 0,0 (moño rojo arriba, alto ~62) */
A.muerdago = function(){
  var hv = '#8cc66a', ho = '#5c9a45';
  var hoja = function(x, y, rot){
    var t = ' transform="rotate('+rot+' '+x+' '+y+')"';
    return '<ellipse cx="'+x+'" cy="'+y+'" rx="6" ry="13"'+t+' fill="'+hv+'" stroke="'+TINTA+'" stroke-width="2.4"/>' +
      '<path d="M'+x+' '+(y - 9)+'V'+(y + 9)+'"'+t+' stroke="'+ho+'" stroke-width="1.6" stroke-linecap="round"/>';
  };
  var baya = function(x, y){ return circ(x, y, 3.8, C.nieve, ' stroke="'+TINTA+'" stroke-width="1.8"'); };
  return '<g class="nv-muerdago">' +
    '<path d="M0 10Q-6 26-12 38M0 10Q2 28 2 44M0 10Q8 24 14 36" fill="none" stroke="'+ho+'" stroke-width="3" stroke-linecap="round"/>' +
    hoja(-19, 40, 40) + hoja(-6, 46, 10) + hoja(10, 48, -12) + hoja(22, 38, -42) +
    baya(-8, 36) + baya(3, 40) + baya(-2, 33) + baya(9, 35) +
    '<path d="M0 8C-6-4-20-4-18 6C-17 12-6 11 0 8Z" fill="'+C.rojo+'"'+TRAZO+'/>' +
    '<path d="M0 8C6-4 20-4 18 6C17 12 6 11 0 8Z" fill="'+C.rojo+'"'+TRAZO+'/>' +
    '<path d="M-2 9L-8 22M2 9L8 21" stroke="'+TINTA+'" stroke-width="6" stroke-linecap="round"/>' +
    '<path d="M-2 9L-8 22M2 9L8 21" stroke="'+C.rojo+'" stroke-width="3" stroke-linecap="round"/>' +
    circ(0, 8, 4.5, C.rojoOsc, TRAZO) +
    '</g>';
};

/* Galleta de jengibre (muñequito) parada en 0,0 (alto ~82, ancho ~72).
   op: { cara:'feliz'|'guino'|'o', color, botones:[c1,c2] } */
var GALLETA_CUERPO = 'M-10-48Q-30-50-34-41Q-36-31-22-31H-14L-18-9Q-20 1-10 1Q-3 1-2-6L0-15L2-6Q3 1 10 1Q20 1 18-9L14-31H22Q36-31 34-41Q30-50 10-48Z';
A.galletaJengibre = function(op){
  op = op || {};
  var col = op.color || C.canela, cara = op.cara || 'feliz', bot = op.botones || [C.rojo, C.verde];
  var cuerpo = '<path d="'+GALLETA_CUERPO+'"/><circle cx="0" cy="-62" r="17"/>';
  var s = '<g class="nv-galleta">' +
    /* contorno de la unión (cabeza + cuerpo sin raya en el cuello) */
    '<g fill="'+TINTA+'" stroke="'+TINTA+'" stroke-width="6" stroke-linejoin="round">' + cuerpo + '</g>' +
    '<g fill="'+col+'">' + cuerpo + '</g>' +
    '<path d="M-9-74Q-4-79 3-78" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".35"/>' +
    /* glaseado: zigzag en muñecas y tobillos */
    '<g fill="none" stroke="'+C.nieve+'" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M-30-41q1.5-3 3 0t3 0 3 0"/><path d="M21-41q1.5-3 3 0t3 0 3 0"/>' +
      '<path d="M-16-10q1.5-2.6 3 0t3 0"/><path d="M10-10q1.5-2.6 3 0t3 0"/>' +
    '</g>' +
    circ(0, -40, 3.4, bot[0], ' stroke="'+TINTA+'" stroke-width="1.6"') +
    circ(0, -29, 3.4, bot[1 % bot.length], ' stroke="'+TINTA+'" stroke-width="1.6"') +
    '<ellipse cx="-10" cy="-57" rx="3.6" ry="2" fill="'+C.rosa+'" opacity=".85"/><ellipse cx="10" cy="-57" rx="3.6" ry="2" fill="'+C.rosa+'" opacity=".85"/>';
  if (cara === 'guino') s += circ(-6, -65, 2.4, TINTA) + '<path d="M3-65q3-2.5 6 0" fill="none" stroke="'+TINTA+'" stroke-width="2.2" stroke-linecap="round"/>';
  else s += circ(-6, -65, 2.4, TINTA) + circ(6, -65, 2.4, TINTA) + circ(-5.3, -65.8, .8, '#fff') + circ(6.7, -65.8, .8, '#fff');
  if (cara === 'o') s += '<ellipse cx="0" cy="-56" rx="2.8" ry="3.4" fill="'+TINTA+'"/>';
  else s += '<path d="M-6-57Q0-51 6-57" fill="none" stroke="'+C.nieve+'" stroke-width="2.4" stroke-linecap="round"/>';
  return s + '</g>';
};

/* Taza de chocolate caliente apoyada en 0,0 (alto ~50 sin vapor).
   op: { color (rojo), vapor (true) } — el vapor usa .hw-vapor */
A.taza = function(op){
  op = op || {};
  var col = op.color || C.rojo, osc = HW.mezcla(col, TINTA, .3);
  var s = '<g class="nv-taza">';
  if (op.vapor !== false){
    [[-9, 0], [1, .9], [11, 1.8]].forEach(function(v){
      s += '<path class="hw-vapor" style="animation-delay:-'+v[1]+'s" d="M'+v[0]+' -56q-5-6 0-12t0-12" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" opacity=".8"/>';
    });
  }
  s += '<path d="M22-36Q37-36 37-24Q37-12 22-14" fill="none" stroke="'+TINTA+'" stroke-width="9" stroke-linecap="round"/>' +
    '<path d="M22-36Q37-36 37-24Q37-12 22-14" fill="none" stroke="'+col+'" stroke-width="4" stroke-linecap="round"/>' +
    '<path d="M-22-44H22V-11Q22 0 11 0H-11Q-22 0-22-11Z" fill="'+col+'"'+TRAZO+'/>' +
    '<path d="M12-40V-10Q12-5 6-4" fill="none" stroke="'+osc+'" stroke-width="5" stroke-linecap="round" opacity=".35"/>' +
    '<path d="M-15-38V-14" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".35"/>' +
    '<g transform="translate(-2 -22) scale(.8)">' + A.copo(1) + '</g>' +
    '<ellipse cx="0" cy="-44" rx="22" ry="5.5" fill="#6b3a22" stroke="'+TINTA+'" stroke-width="2.6"/>' +
    '<rect x="-12" y="-50" width="9" height="8" rx="2.5" fill="#fff" stroke="'+TINTA+'" stroke-width="1.8" transform="rotate(-12 -7.5 -46)"/>' +
    '<rect x="2" y="-49" width="9" height="8" rx="2.5" fill="#ffe3ec" stroke="'+TINTA+'" stroke-width="1.8" transform="rotate(10 6.5 -45)"/>' +
    '</g>';
  return s;
};

/* Fuego de chimenea apoyado en 0,0 (ancho ~110, alto ~95). op: { llamas (true; false = solo troncos, fase 6),
   halo (true; false = sin la mancha de brillo, para poner uno propio más suave, fase 7) }
   Tres llamas con .hw-llama (vaivén) y brillo con .hw-vela (opacidad). */
A.fuego = function(op){
  op = op || {};
  var llama = function(x, esc, del, capas){
    var s = '<g transform="translate('+x+' -12) scale('+esc+')"><g class="hw-llama" style="animation-delay:-'+del+'s">';
    s += '<path d="M0 0C-26 0-30-26-16-44C-14-30-6-30-6-38C-6-54 4-66 14-74C10-58 26-50 26-30C26-12 18 0 0 0Z" fill="'+capas[0]+'" stroke="'+TINTA+'" stroke-width="3" stroke-linejoin="round"/>';
    s += '<path d="M0-2C-15-2-18-18-9-30C-8-22-2-22-2-28C-2-38 5-46 11-50C9-40 18-34 18-21C18-9 12-2 0-2Z" fill="'+capas[1]+'"/>';
    s += '<path d="M1-4C-6-4-8-12-4-18C-3-14 0-14 0-17C0-22 4-26 7-28C6-22 10-19 10-13C10-7 7-4 1-4Z" fill="'+capas[2]+'"/>';
    return s + '</g></g>';
  };
  var s = '<g class="nv-fuego">' +
    /* el brillo va dentro de un <g> con su opacidad: la animación .hw-vela pisa la opacidad del propio elemento */
    (op.llamas === false || op.halo === false ? '' : '<g opacity=".2"><ellipse cx="0" cy="-30" rx="70" ry="48" fill="#ffb547" class="hw-vela"/></g>') +
    (op.llamas === false ? '' :
    llama(-24, .78, .5, ['#ff7a3d', '#ffb547', '#fff1b8']) +
    llama(24, .72, 1.1, ['#ff7a3d', '#ffb547', '#fff1b8']) +
    llama(0, 1, 0, ['#ff8a3d', '#ffc95c', '#fff6d0'])) +
    /* troncos cruzados */
    '<g transform="rotate(-9)"><rect x="-52" y="-16" width="96" height="16" rx="8" fill="#8a4f2a"'+TRAZO+'/>' +
      '<ellipse cx="38" cy="-8" rx="5" ry="6.5" fill="#d9a066" stroke="'+TINTA+'" stroke-width="2.4"/></g>' +
    '<g transform="rotate(8)"><rect x="-44" y="-14" width="96" height="16" rx="8" fill="#9a5a32"'+TRAZO+'/>' +
      '<ellipse cx="-38" cy="-6" rx="5" ry="6.5" fill="#d9a066" stroke="'+TINTA+'" stroke-width="2.4"/>' +
      '<path d="M-20-9H10" stroke="#6b3a20" stroke-width="2" stroke-linecap="round"/></g>' +
    (op.llamas === false ? circ(-14, -3, 2.6, '#6b4a3a') + circ(12, -1, 2.2, '#6b4a3a') :
    circ(-14, -3, 3, '#ffcf5c', ' class="hw-vela" style="animation-delay:-.7s"') + circ(12, -1, 2.4, '#ff8a3d', ' class="hw-vela" style="animation-delay:-1.6s"')) +
    '</g>';
  return s;
};

/* ── fase 6: repisa, chimenea, vela y personajes que se asoman ── */
/* Repisa de madera: superficie de arriba en y = 0, centrada en x = 0, alto 34.
   op: { ancho (480), mensulas (true: dos soportes debajo, para la repisa de pared) } */
A.repisa = function(op){
  op = op || {};
  var w = op.ancho || 480, x = -w / 2, s = '<g class="nv-repisa">';
  if (op.mensulas !== false){
    [x + w * .14, -x - w * .14].forEach(function(cx){
      s += '<path d="M'+f1(cx - 13)+' 28V64Q'+f1(cx - 13)+' 84 '+f1(cx + 9)+' 86Q'+f1(cx + 14)+' 86 '+f1(cx + 13)+' 78V28Z" fill="#7a4424"'+TRAZO+'/>' +
        '<path d="M'+f1(cx - 6)+' 38V62" stroke="#a8683a" stroke-width="2.6" stroke-linecap="round"/>';
    });
  }
  s += '<rect x="'+f1(x)+'" y="0" width="'+f1(w)+'" height="34" rx="8" fill="#8a4f2a"'+TRAZO+'/>' +
    '<rect x="'+f1(x + 7)+'" y="5" width="'+f1(w - 14)+'" height="7" rx="3.5" fill="#b8713f" opacity=".9"/>' +
    '<path d="M'+f1(x + 26)+' 22H'+f1(x + w * .36)+'M'+f1(x + w * .5)+' 25H'+f1(-x - 34)+'" stroke="#6b3a20" stroke-width="2.4" stroke-linecap="round"/>' +
    '</g>';
  return s;
};

/* Chimenea de ladrillo apoyada en y = 0, centrada en x = 0.
   op: { ancho (420), alto (420), fuego (true), ladrillo (#b5523b), semilla, id,
         fase 7: junta (#e6c7a4), marco (#d8cbb8), piso (#8d8496), tonos ([3 colores]), repisa (true) }
   Arriba lleva la repisa (más ancha que la chimenea): su superficie queda en y = -alto
   y su borde de abajo en y = -alto + 34 (de ahí se cuelgan las calcetas). */
A.chimenea = function(op){
  op = op || {};
  var p = prefijo(op), W = op.ancho || 420, H = op.alto || 420, x0 = -W / 2, yT = -H + 34, rnd = HW.azar(op.semilla || 5);
  var lad = op.ladrillo || '#b5523b', tonos = op.tonos || [lad, HW.mezcla(lad, '#ffffff', .12), HW.mezcla(lad, TINTA, .16)];
  var aw = W * .6, ah = H * .55, ax = -aw / 2, k = ah * .34, ay = -16 - ah;
  var arco = 'M'+f1(ax)+' -16V'+f1(ay + k)+'A'+f1(aw / 2)+' '+f1(k)+' 0 0 1 '+f1(-ax)+' '+f1(ay + k)+'V-16Z';
  var s = '<g class="nv-chimenea"><defs><clipPath id="'+p+'-cu"><rect x="'+f1(x0)+'" y="'+f1(yT)+'" width="'+f1(W)+'" height="'+f1(H - 34)+'" rx="6"/></clipPath>' +
    '<radialGradient id="'+p+'-luz" cx=".5" cy=".85" r=".75"><stop offset="0" stop-color="#ffb547" stop-opacity=".9"/><stop offset=".55" stop-color="#ff7a3d" stop-opacity=".35"/><stop offset="1" stop-color="#ff7a3d" stop-opacity="0"/></radialGradient></defs>';
  /* cuerpo: juntas claras y ladrillos redondeados encima, fila sí fila no desplazados */
  s += '<rect x="'+f1(x0)+'" y="'+f1(yT)+'" width="'+f1(W)+'" height="'+f1(H - 34)+'" rx="6" fill="'+(op.junta || '#e6c7a4')+'"/><g clip-path="url(#'+p+'-cu)">';
  var bh = 26, bw = 58, fila = 0;
  for (var y = yT + 3; y < 0; y += bh + 4, fila++){
    for (var x = x0 - (fila % 2 ? bw / 2 : 4); x < -x0; x += bw + 4){
      s += '<rect x="'+f1(x)+'" y="'+f1(y)+'" width="'+bw+'" height="'+bh+'" rx="5" fill="'+tonos[Math.floor(rnd() * 3)]+'"/>';
      if (rnd() < .3) s += '<path d="M'+f1(x + 7)+' '+f1(y + 6)+'h'+f1(10 + rnd() * 14)+'" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".22"/>';
    }
  }
  s += '</g><rect x="'+f1(x0)+'" y="'+f1(yT)+'" width="'+f1(W)+'" height="'+f1(H - 34)+'" rx="6" fill="none"'+TRAZO+'/>';
  /* boca: marco de piedra, hueco oscuro, luz del fuego */
  s += '<path d="'+arco+'" fill="none" stroke="'+TINTA+'" stroke-width="24" stroke-linejoin="round"/>' +
    '<path d="'+arco+'" fill="none" stroke="'+(op.marco || '#d8cbb8')+'" stroke-width="18" stroke-linejoin="round"/>' +
    '<path d="'+arco+'" fill="#2b1d26"'+TRAZO+'/>' +
    '<path d="M'+f1(ax + 14)+' -24V'+f1(ay + k + 6)+'" stroke="#3d2a35" stroke-width="10" stroke-linecap="round"/>';
  if (op.fuego !== false) s += '<g opacity=".85"><ellipse cx="0" cy="'+f1(-16 - ah * .45)+'" rx="'+f1(aw * .48)+'" ry="'+f1(ah * .52)+'" fill="url(#'+p+'-luz)" class="hw-vela"/></g>';
  s += '<g transform="translate(0 -16) scale('+(aw / 150).toFixed(2)+')">' + A.fuego({ llamas: op.fuego !== false }) + '</g>';
  /* piso de piedra delante y repisa arriba */
  s += '<rect x="'+f1(x0 - 16)+'" y="-18" width="'+f1(W + 32)+'" height="18" rx="7" fill="'+(op.piso || '#8d8496')+'"'+TRAZO+'/>' +
    '<path d="M'+f1(x0 - 6)+' -12H'+f1(-x0 * .4)+'" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".3"/>';
  if (op.repisa !== false) s += '<g transform="translate(0 '+f1(-H)+')">' + A.repisa({ ancho: W + 56, mensulas: false }) + '</g>';
  return s + '</g>';
};

/* Vela apoyada en y = 0. op: { color (rojo), alto (54, solo la cera), ancho (18), retraso (s), id }
   La llama usa .hw-llama (vaivén) y el halo .hw-vela (opacidad, dentro de un <g> con su opacidad). */
A.vela = function(op){
  op = op || {};
  var col = op.color || C.rojo, h = op.alto || 54, w = op.ancho || 18, x = -w / 2, d = (+op.retraso || 0).toFixed(2);
  var claro = HW.mezcla(col, '#ffffff', .35), gx = -w * .1, p = prefijo(op);
  return '<g class="nv-vela"><defs><radialGradient id="'+p+'-h"><stop offset="0" stop-color="#ffd98a" stop-opacity=".9"/><stop offset=".45" stop-color="#ffcf5c" stop-opacity=".35"/><stop offset="1" stop-color="#ffcf5c" stop-opacity="0"/></radialGradient></defs>' +
    '<g opacity=".8"><circle cx="0" cy="'+f1(-h - 14)+'" r="30" fill="url(#'+p+'-h)" class="hw-vela" style="animation-delay:-'+d+'s"/></g>' +
    '<rect x="'+f1(x)+'" y="'+f1(-h)+'" width="'+w+'" height="'+h+'" rx="5" fill="'+col+'"'+TRAZO+'/>' +
    '<path d="M'+f1(x + 4.5)+' '+f1(-h + 22)+'V-9" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".35"/>' +
    '<path d="M'+f1(x)+' '+f1(-h + 6)+'Q'+f1(x)+' '+f1(-h)+' '+f1(x + 6)+' '+f1(-h)+'H'+f1(-x - 6)+'Q'+f1(-x)+' '+f1(-h)+' '+f1(-x)+' '+f1(-h + 6)+
      'V'+f1(-h + 9)+'Q'+f1(-x - 4)+' '+f1(-h + 12)+' '+f1(gx)+' '+f1(-h + 9)+'V'+f1(-h + 17)+'Q'+f1(gx - 3)+' '+f1(-h + 22)+' '+f1(gx - 6)+' '+f1(-h + 17)+
      'V'+f1(-h + 9)+'Q'+f1(x + 3)+' '+f1(-h + 12)+' '+f1(x)+' '+f1(-h + 9)+'Z" fill="'+claro+'" stroke="'+TINTA+'" stroke-width="2.4" stroke-linejoin="round"/>' +
    '<path d="M0 '+f1(-h)+'V'+f1(-h - 6)+'" stroke="'+TINTA+'" stroke-width="2.6" stroke-linecap="round"/>' +
    '<g transform="translate(0 '+f1(-h - 4)+')"><g class="hw-llama" style="animation-duration:1.1s;animation-delay:-'+d+'s">' +
      '<path d="M0 0C-7 0-8-8-4-13C-2-16 0-20 0-25C3-19 8-14 8-8C8-3 5 0 0 0Z" fill="#ffb547" stroke="'+TINTA+'" stroke-width="2.2" stroke-linejoin="round"/>' +
      '<path d="M0-2C-3-2-4-6-2-9C-1-11 0-13 0-15C2-12 4-9 4-6C4-3 2-2 0-2Z" fill="#fff6d0"/></g></g>' +
    '</g>';
};

/* Personajes que se asoman (Marco de webcam): solo cabeza y manos.
   Contrato: el borde por el que se asoman es la línea y = 0. La cabeza queda
   encima (y < 0, centro en 0,-66) y se dibuja DETRÁS del marco; las manos se
   agarran al borde (x = ±52, y ≈ 0) y se dibujan DELANTE del marco.
   op: { parte:'cabeza'|'manos' }. Los ojos van en <g class="ojos"> para animarlos. */
var CAFE = '#a86a3c', CAFE_OSC = '#8f5530', HOCICO = '#f3dcb8';
var S3 = ' stroke="'+TINTA+'" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"';
var S25 = ' stroke="'+TINTA+'" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"';
function ojosA(x1, x2, y){
  return '<g class="ojos"><ellipse cx="'+x1+'" cy="'+y+'" rx="5" ry="6.5" fill="'+TINTA+'"/><ellipse cx="'+x2+'" cy="'+y+'" rx="5" ry="6.5" fill="'+TINTA+'"/>' +
    '<circle cx="'+(x1 + 1.8)+'" cy="'+(y - 2.2)+'" r="1.9" fill="#fff"/><circle cx="'+(x2 + 1.8)+'" cy="'+(y - 2.2)+'" r="1.9" fill="#fff"/></g>';
}
function mejillasA(x1, x2, y){ return '<ellipse cx="'+x1+'" cy="'+y+'" rx="5.5" ry="3.2" fill="#ff8fab" opacity=".7"/><ellipse cx="'+x2+'" cy="'+y+'" rx="5.5" ry="3.2" fill="#ff8fab" opacity=".7"/>'; }
function ramaA(d, color, w){
  return '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="'+(w + 3.5)+'" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="'+w+'" stroke-linecap="round" stroke-linejoin="round"/>';
}
/* Coordenadas del desfile (cabeza en 60,57) llevadas a (0,-66) con escala 1.6 */
var A_ESC = '<g transform="translate(-96 -157.2) scale(1.6)">';
A.renoAsoma = function(op){
  op = op || {};
  if (op.parte === 'manos'){
    var pezuna = function(x){
      return '<g transform="translate('+x+' 0)"><rect x="-15" y="-16" width="30" height="28" rx="12" fill="'+CAFE_OSC+'"'+S3+'/>' +
        '<path d="M-14 4H14" stroke="'+TINTA+'" stroke-width="3"/><path d="M0 4V11" stroke="'+TINTA+'" stroke-width="2.6" stroke-linecap="round"/>' +
        '<path d="M-8-10q5-3 10-1" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".3"/></g>';
    };
    return '<g class="nv-asoma-manos">' + pezuna(-52) + pezuna(52) + '</g>';
  }
  return '<g class="nv-asoma-cabeza">' + A_ESC +
    '<rect x="45" y="70" width="30" height="60" rx="12" fill="'+CAFE+'"'+S3+'/>' +
    '<g class="astas">' + ramaA('M48 38Q45 24 40 13M45 26Q38 25 32 19M42 18Q44 11 49 7', '#e8c08a', 4.5) +
      ramaA('M72 38Q75 24 80 13M75 26Q82 25 88 19M78 18Q76 11 71 7', '#e8c08a', 4.5) + '</g>' +
    '<ellipse cx="33" cy="47" rx="11" ry="5.5" transform="rotate(-25 33 47)" fill="'+CAFE+'"'+S3+'/>' +
    '<ellipse cx="87" cy="47" rx="11" ry="5.5" transform="rotate(25 87 47)" fill="'+CAFE+'"'+S3+'/>' +
    '<ellipse cx="34" cy="47" rx="6" ry="2.4" transform="rotate(-25 34 47)" fill="#f2b5a6"/>' +
    '<ellipse cx="86" cy="47" rx="6" ry="2.4" transform="rotate(25 86 47)" fill="#f2b5a6"/>' +
    '<ellipse cx="60" cy="57" rx="25" ry="23" fill="'+CAFE+'"'+S3+'/>' +
    '<path d="M42 46q6-8 15-10" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".3"/>' +
    '<ellipse cx="60" cy="69" rx="14" ry="9.5" fill="'+HOCICO+'"/>' +
    ojosA(50, 70, 53) + mejillasA(39, 81, 63) +
    '<path d="M55 71q5 4 10 0" fill="none"'+S25+'/>' +
    '<path d="M38 80Q60 91 82 80L83 87Q60 98 37 87Z" fill="'+C.rojo+'"'+S3+'/>' +
    '<path d="M46 86.5v6M53 88.5v6M60 89.5v6M67 88.5v6M74 86.5v6" stroke="'+C.nieve+'" stroke-width="2.6" stroke-linecap="round" opacity=".9"/>' +
    '<circle cx="60" cy="64" r="6.2" fill="'+C.rojo+'"'+S25+'/><circle cx="58" cy="62" r="1.9" fill="#fff" opacity=".9"/>' +
    '</g></g>';
};
A.galletaAsoma = function(op){
  op = op || {};
  var CAN = C.canela, GLAS = ' fill="none" stroke="'+C.nieve+'" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"';
  if (op.parte === 'manos'){
    var mano = function(x){
      return '<g transform="translate('+x+' -2)"><circle cx="0" cy="0" r="14" fill="'+CAN+'"'+S3+'/>' +
        '<path d="M-8 3q2-3 4 0t4 0 4 0 4 0"'+GLAS+'/>' +
        '<path d="M-7-6q3-4 8-4" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".35"/></g>';
    };
    return '<g class="nv-asoma-manos">' + mano(-52) + mano(52) + '</g>';
  }
  /* cabeza + torso en una sola pieza (contorno ancho debajo, relleno encima: sin raya en el cuello) */
  var pieza = '<rect x="38" y="52" width="44" height="58" rx="16"/><circle cx="60" cy="38" r="22"/>';
  return '<g class="nv-asoma-cabeza"><g transform="translate(-96 -126.8) scale(1.6)">' +
    '<g fill="'+TINTA+'" stroke="'+TINTA+'" stroke-width="6" stroke-linejoin="round">' + pieza + '</g>' +
    '<g fill="'+CAN+'">' + pieza + '</g>' +
    '<path d="M46 26q5-7 13-8" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".35"/>' +
    '<path d="M45 64q3.75 3.5 7.5 0t7.5 0 7.5 0 7.5 0"'+GLAS+'/>' +
    '<path d="M50 21q2.5-3 5 0t5 0 5 0 5 0"'+GLAS+'/>' +
    ojosA(52, 68, 36) + mejillasA(44, 76, 45) +
    '<path d="M53 46q7 6 14 0"'+GLAS+'/>' +
    '<g transform="translate(76 22) rotate(18)"><path d="M0 0C-4-8-14-8-13-1C-12 4-4 3 0 0Z" fill="'+C.rojo+'"'+S25+'/>' +
      '<path d="M0 0C4-8 14-8 13-1C12 4 4 3 0 0Z" fill="'+C.rojo+'"'+S25+'/><circle cx="0" cy="0" r="3.4" fill="'+C.rojoOsc+'"'+S25+'/></g>' +
    '</g></g>';
};

/* ── fase 8: cosas de cocina (Fondo: Cocina de Navidad) ──────────
   · rodillo({ largo, grosor, color, harina }): rodillo de madera tumbado,
     centrado en x = 0 y apoyado en y = 0.
   · cortador(forma, { tam, color, plano }): cortador de galletas tumbado sobre
     la mesa (visto en perspectiva: plano = cuánto se aplasta en vertical).
     forma = 'estrella' | 'muneco' | 'arbol'. Centro de la forma en 0,0.
   · frasco({ ancho, alto, relleno, tapa, tela, etiqueta, id }): frasco de vidrio
     de pie en 0,0. relleno = 'harina' | 'azucar' | 'canela' | 'jengibre' |
     'bastones' (sin tapa, asoman por arriba) | 'galletas' | 'vacio'.
     La etiqueta es solo dibujo (un iconito), nunca texto. */
/* Aplasta en vertical un camino con comandos absolutos (M L H V Q C A Z) */
function aplanar(d, sy){
  var tk = String(d).match(/[MLHVQCAZ]|-?\d*\.?\d+/g) || [], out = '', cmd = '', args = [];
  var cuantos = { M:2, L:2, H:1, V:1, Q:4, C:6, A:7, Z:0 };
  function vaciar(){
    var n = cuantos[cmd];
    if (!n){ return; }
    for (var i = 0; i + n <= args.length; i += n){
      var a = args.slice(i, i + n).map(Number);
      if (cmd === 'V') a[0] *= sy;
      else if (cmd === 'A'){ a[1] *= sy; a[6] *= sy; }
      else if (cmd !== 'H') for (var j = 1; j < n; j += 2) a[j] *= sy;
      out += cmd + a.map(function(x){ return f1(x); }).join(' ');
    }
    args = [];
  }
  tk.forEach(function(t){
    if (/^[A-Z]$/.test(t)){ vaciar(); cmd = t; if (t === 'Z') out += 'Z'; }
    else args.push(t);
  });
  vaciar();
  return out;
}
A.rodillo = function(op){
  op = op || {};
  var L = op.largo || 190, g = op.grosor || 34, col = op.color || '#e0a96e', r = g / 2, yc = -r;
  var osc = HW.mezcla(col, TINTA, .3), claro = HW.mezcla(col, '#ffffff', .4);
  var s = '<g class="nv-rodillo"><ellipse cx="0" cy="1" rx="'+f1(L * .62 + g)+'" ry="'+f1(g * .16 + 2)+'" fill="'+TINTA+'" opacity=".2"/>';
  [-1, 1].forEach(function(sg){
    var xa = sg * L / 2, xn = sg * (L / 2 + g * .5), xk = sg * (L / 2 + g * 1.05);
    s += '<rect x="'+f1(Math.min(xa, xn) - 2)+'" y="'+f1(yc - g * .17)+'" width="'+f1(Math.abs(xn - xa) + 4)+'" height="'+f1(g * .34)+'" fill="'+osc+'"'+TRAZO+'/>' +
      '<ellipse cx="'+f1(xk)+'" cy="'+f1(yc)+'" rx="'+f1(g * .6)+'" ry="'+f1(g * .4)+'" fill="'+col+'"'+TRAZO+'/>' +
      '<ellipse cx="'+f1(xk - sg * g * .1)+'" cy="'+f1(yc - g * .14)+'" rx="'+f1(g * .3)+'" ry="'+f1(g * .1)+'" fill="'+claro+'" opacity=".8"/>';
  });
  s += '<rect x="'+f1(-L / 2)+'" y="'+f1(-g)+'" width="'+f1(L)+'" height="'+f1(g)+'" rx="'+f1(r * .5)+'" fill="'+col+'"/>' +
    '<rect x="'+f1(-L / 2 + 3)+'" y="'+f1(-g * .42)+'" width="'+f1(L - 6)+'" height="'+f1(g * .36)+'" rx="'+f1(g * .16)+'" fill="'+osc+'" opacity=".45"/>' +
    '<rect x="'+f1(-L / 2 + 8)+'" y="'+f1(-g * .84)+'" width="'+f1(L - 16)+'" height="'+f1(g * .16)+'" rx="'+f1(g * .08)+'" fill="#fff" opacity=".45"/>' +
    '<path d="M'+f1(-L * .3)+' '+f1(-g * .56)+'Q'+f1(-L * .1)+' '+f1(-g * .62)+' '+f1(L * .12)+' '+f1(-g * .54)+'M'+f1(L * .02)+' '+f1(-g * .3)+'Q'+f1(L * .2)+' '+f1(-g * .34)+' '+f1(L * .36)+' '+f1(-g * .28)+'" fill="none" stroke="'+osc+'" stroke-width="1.6" stroke-linecap="round" opacity=".55"/>' +
    '<rect x="'+f1(-L / 2)+'" y="'+f1(-g)+'" width="'+f1(L)+'" height="'+f1(g)+'" rx="'+f1(r * .5)+'" fill="none"'+TRAZO+'/>';
  if (op.harina !== false){
    var rnd = HW.azar(HW.hash('rod' + L + 'x' + g));
    for (var i = 0; i < 14; i++) s += circ(-L / 2 + 10 + rnd() * (L - 20), -g * (.2 + rnd() * .7), .9 + rnd() * 1.8, '#fffaf0', ' opacity="'+(.55 + rnd() * .4).toFixed(2)+'"');
  }
  return s + '</g>';
};
var CORTADORES = {
  estrella: caminoEstrella(17),
  muneco: 'M-6 -15A11 11 0 1 1 6 -15L21 -12Q29 -10 27 -3Q25 2 19 1L12 0L16 21Q18 29 10 29Q5 29 3 23L0 15L-3 23Q-5 29 -10 29Q-18 29 -16 21L-12 0L-19 1Q-25 2 -27 -3Q-29 -10 -21 -12Z',
  arbol: 'M0 -31L15 -11H8L21 8H11L24 25H5V32H-5V25H-24L-11 8H-21L-8 -11H-15Z',
  casa: 'M0 -28L24 -8V26H-24V-8Z',
  techo: 'M-26 -16H26V16H-26Z'
};
A.cortador = function(forma, op){
  op = op || {};
  var d0 = CORTADORES[forma] || CORTADORES.estrella, k = op.tam || 1, sy = op.plano == null ? .55 : op.plano;
  var col = op.color || '#d5d9e6', osc = HW.mezcla(col, TINTA, .38), claro = HW.mezcla(col, '#ffffff', .6);
  var d = aplanar(d0, sy), alto = 6;
  var s = '<g class="nv-cortador" transform="scale('+k+')">' +
    '<g transform="translate(2 '+(alto + 3)+')"><path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="7" stroke-linejoin="round" opacity=".18"/></g>' +
    '<g transform="translate(0 '+alto+')"><path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="8.4" stroke-linejoin="round"/><path d="'+d+'" fill="none" stroke="'+osc+'" stroke-width="4.4" stroke-linejoin="round"/></g>';
  for (var i = 1; i < alto; i += 2) s += '<g transform="translate(0 '+i+')"><path d="'+d+'" fill="none" stroke="'+osc+'" stroke-width="4.4" stroke-linejoin="round"/></g>';
  s += '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="8.4" stroke-linejoin="round"/>' +
    '<path d="'+d+'" fill="none" stroke="'+col+'" stroke-width="4.4" stroke-linejoin="round"/>' +
    '<path d="'+d+'" fill="none" stroke="'+claro+'" stroke-width="1.4" stroke-linejoin="round" stroke-dasharray="10 14" opacity=".9"/>';
  return s + '</g>';
};
A.frasco = function(op){
  op = op || {};
  var p = prefijo(op), w = op.ancho || 56, h = op.alto || 80, rel = op.relleno || 'harina', rr = Math.min(w * .2, 12);
  var tapa = op.tapa || C.rojo, rnd = HW.azar(HW.hash(p + rel + w + 'x' + h)), abierto = rel === 'bastones';
  var cuerpo = 'M'+f1(-w / 2 + rr)+' 0Q'+f1(-w / 2)+' 0 '+f1(-w / 2)+' '+f1(-rr)+'V'+f1(-h + rr * 1.4)+'Q'+f1(-w / 2)+' '+f1(-h + rr * .5)+' '+f1(-w * .36)+' '+f1(-h + rr * .3)+
    'H'+f1(w * .36)+'Q'+f1(w / 2)+' '+f1(-h + rr * .5)+' '+f1(w / 2)+' '+f1(-h + rr * 1.4)+'V'+f1(-rr)+'Q'+f1(w / 2)+' 0 '+f1(w / 2 - rr)+' 0Z';
  var s = '<g class="nv-frasco"><defs><clipPath id="'+p+'-fr"><path d="'+cuerpo+'"/></clipPath></defs>' +
    '<ellipse cx="0" cy="2" rx="'+f1(w * .58)+'" ry="4" fill="'+TINTA+'" opacity=".2"/>';
  /* bastones que asoman (detrás del vidrio de delante) */
  if (abierto){
    [[-w * .2, -h - 34, -8, C.rojo], [w * .02, -h - 46, 6, C.verde], [w * .22, -h - 28, 14, C.rojo]].forEach(function(b){
      var gx = b[0], gy = b[1], d = 'M'+f1(gx)+' '+f1(-6)+'V'+f1(gy + 10)+'Q'+f1(gx)+' '+f1(gy)+' '+f1(gx - 10)+' '+f1(gy)+'Q'+f1(gx - 19)+' '+f1(gy)+' '+f1(gx - 19)+' '+f1(gy + 9);
      s += '<g transform="rotate('+b[2]+' '+f1(gx)+' 0)"><path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="'+d+'" fill="none" stroke="'+C.nieve+'" stroke-width="7" stroke-linecap="round"/>' +
        '<path d="'+d+'" fill="none" stroke="'+b[3]+'" stroke-width="7" stroke-dasharray="5 6"/></g>';
    });
  }
  s += '<path d="'+cuerpo+'" fill="#e8f1fb" opacity=".5"/><g clip-path="url(#'+p+'-fr)">';
  var nivel = -h * (abierto ? .55 : .74), x0 = -w / 2;
  if (rel === 'harina' || rel === 'azucar' || rel === 'jengibre'){
    var cc = rel === 'jengibre' ? '#d9a35a' : rel === 'azucar' ? '#ffffff' : '#f6f0e2', mo = rel === 'jengibre' ? '#a8692e' : '#d8cfbd';
    s += '<path d="M'+f1(x0)+' '+f1(nivel + 4)+'Q'+f1(x0 + w * .3)+' '+f1(nivel - 5)+' '+f1(x0 + w * .55)+' '+f1(nivel)+'T'+f1(-x0)+' '+f1(nivel - 2)+'V4H'+f1(x0)+'Z" fill="'+cc+'"/>';
    for (var i = 0; i < Math.round(w * h / 160); i++){
      var px = x0 + 4 + rnd() * (w - 8), py = nivel + 6 + rnd() * (-nivel - 8);
      s += rel === 'azucar' ? '<rect x="'+f1(px)+'" y="'+f1(py)+'" width="2.6" height="2.6" fill="#dfe6f2" opacity=".9"/>' : circ(px, py, .8 + rnd() * 1.2, mo, ' opacity=".55"');
    }
  } else if (rel === 'canela'){
    s += '<rect x="'+f1(x0)+'" y="'+f1(nivel)+'" width="'+w+'" height="'+f1(-nivel + 4)+'" fill="#f3e3cc" opacity=".5"/>';
    for (var c = 0; c < 5; c++){
      var cx = x0 + w * (.14 + c * .18), top = nivel - 6 - rnd() * 10;
      s += '<rect x="'+f1(cx - 4.5)+'" y="'+f1(top)+'" width="9" height="'+f1(-top + 4)+'" rx="3" fill="'+(c % 2 ? '#8a4b23' : '#a65d2c')+'" stroke="'+TINTA+'" stroke-width="1.6" transform="rotate('+f1((rnd() - .5) * 10)+' '+f1(cx)+' 0)"/>';
    }
  } else if (rel === 'galletas'){
    for (var g = 0; g < 4; g++){
      var gy = -8 - g * (h * .17);
      s += '<ellipse cx="'+f1((rnd() - .5) * 6)+'" cy="'+f1(gy)+'" rx="'+f1(w * .4)+'" ry="'+f1(h * .08)+'" fill="'+(g % 2 ? C.canela : '#d9955a')+'" stroke="'+TINTA+'" stroke-width="1.8"/>';
    }
  } else if (abierto){
    s += '<rect x="'+f1(x0)+'" y="'+f1(nivel)+'" width="'+w+'" height="'+f1(-nivel + 4)+'" fill="#ffe2e6" opacity=".55"/>';
    for (var m = 0; m < 9; m++) s += circ(x0 + 6 + rnd() * (w - 12), nivel + 6 + rnd() * (-nivel - 10), 3.5 + rnd() * 2.5, [C.rojo, C.verde, '#fffaf0'][m % 3], ' stroke="'+TINTA+'" stroke-width="1.2"');
  }
  /* reflejos del vidrio */
  s += '<rect x="'+f1(x0 + w * .12)+'" y="'+f1(-h + rr * 1.6)+'" width="'+f1(w * .09)+'" height="'+f1(h * .7)+'" rx="'+f1(w * .045)+'" fill="#fff" opacity=".55"/>' +
    '<rect x="'+f1(-x0 - w * .2)+'" y="'+f1(-h * .62)+'" width="'+f1(w * .05)+'" height="'+f1(h * .4)+'" rx="'+f1(w * .025)+'" fill="#fff" opacity=".35"/></g>' +
    '<path d="'+cuerpo+'" fill="none"'+TRAZO+'/>';
  /* etiqueta (solo un iconito) */
  if (op.etiqueta !== false && !abierto){
    var ew = w * .62, eh = Math.min(h * .3, ew * .72), ey = -h * .48;
    s += '<rect x="'+f1(-ew / 2)+'" y="'+f1(ey - eh / 2)+'" width="'+f1(ew)+'" height="'+f1(eh)+'" rx="'+f1(eh * .22)+'" fill="#fff4dd" stroke="'+TINTA+'" stroke-width="2"/>' +
      '<rect x="'+f1(-ew / 2 + 3)+'" y="'+f1(ey - eh / 2 + 3)+'" width="'+f1(ew - 6)+'" height="'+f1(eh - 6)+'" rx="'+f1(eh * .16)+'" fill="none" stroke="'+tapa+'" stroke-width="1.4" stroke-dasharray="3 3"/>';
    var k = eh * .028, ic = '';
    if (rel === 'harina') ic = '<path d="M0 12V-12M0 -6L-6 -11M0 -6L6 -11M0 1L-7 -4M0 1L7 -4M0 8L-7 3M0 8L7 3" fill="none" stroke="#c99a4a" stroke-width="3" stroke-linecap="round"/>';
    else if (rel === 'azucar') ic = '<rect x="-12" y="-8" width="14" height="14" rx="2" fill="#fff" stroke="'+TINTA+'" stroke-width="2"/><rect x="0" y="-2" width="12" height="12" rx="2" fill="#fff" stroke="'+TINTA+'" stroke-width="2"/>';
    else if (rel === 'canela') ic = '<rect x="-12" y="-4" width="24" height="7" rx="3" fill="#a65d2c" stroke="'+TINTA+'" stroke-width="1.8" transform="rotate(-22)"/><rect x="-12" y="-4" width="24" height="7" rx="3" fill="#8a4b23" stroke="'+TINTA+'" stroke-width="1.8" transform="rotate(22)"/>';
    else if (rel === 'jengibre') ic = '<g transform="translate(0 13) scale(.3)">' + A.galletaJengibre({}) + '</g>';
    else ic = A.copo(1);
    s += '<g transform="translate(0 '+f1(ey)+') scale('+f1(k * 1.1)+')">' + ic + '</g>';
  }
  /* tapa: de rosca con tela a cuadros (op.tela) o lisa */
  if (!abierto){
    var tw = w * .82, ty = -h + rr * .3;
    s += '<rect x="'+f1(-tw / 2)+'" y="'+f1(ty - 12)+'" width="'+f1(tw)+'" height="14" rx="4" fill="'+tapa+'"'+TRAZO+'/>' +
      '<path d="M'+f1(-tw / 2 + 4)+' '+f1(ty - 8)+'H'+f1(tw / 2 - 4)+'" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".45"/>';
    if (op.tela){
      var cw = tw * 1.24, cy = ty - 14;
      s += '<path d="M'+f1(-cw / 2)+' '+f1(cy + 16)+'Q'+f1(-cw / 2 + 4)+' '+f1(cy - 2)+' 0 '+f1(cy - 6)+'Q'+f1(cw / 2 - 4)+' '+f1(cy - 2)+' '+f1(cw / 2)+' '+f1(cy + 16)+'Q'+f1(cw * .25)+' '+f1(cy + 10)+' 0 '+f1(cy + 13)+'Q'+f1(-cw * .25)+' '+f1(cy + 10)+' '+f1(-cw / 2)+' '+f1(cy + 16)+'Z" fill="'+op.tela+'"'+TRAZO+'/>' +
        '<path d="M'+f1(-cw * .3)+' '+f1(cy - 1)+'V'+f1(cy + 11)+'M'+f1(-cw * .1)+' '+f1(cy - 5)+'V'+f1(cy + 12)+'M'+f1(cw * .1)+' '+f1(cy - 5)+'V'+f1(cy + 12)+'M'+f1(cw * .3)+' '+f1(cy - 1)+'V'+f1(cy + 11)+'M'+f1(-cw * .42)+' '+f1(cy + 5)+'H'+f1(cw * .42)+'" stroke="#fff" stroke-width="2.4" opacity=".7"/>' +
        '<path d="M'+f1(-tw / 2)+' '+f1(ty - 1)+'H'+f1(tw / 2)+'" stroke="'+TINTA+'" stroke-width="5" stroke-linecap="round"/><path d="M'+f1(-tw / 2)+' '+f1(ty - 1)+'H'+f1(tw / 2)+'" stroke="#e9d3a6" stroke-width="2.4" stroke-linecap="round"/>';
    }
  }
  return s + '</g>';
};

/* ── fase 9: exterior nevado (Fondo: Blanca Navidad) ─────────────
   · montana({ ancho, alto, picos, color, colorNieve, luz, fondo, contorno, semilla }):
     cordillera de x = 0 a ancho con el pie en y = 0 (el relleno baja hasta y = fondo).
     luz = x de donde viene la luz: la cara del otro lado de cada pico queda en sombra.
   · cerca({ largo, alto, paso, color, nieve, semilla }): cerca de madera de x = 0 a
     largo, apoyada en y = 0, con nieve en postes, travesaños y al pie.
   · farol({ poste, brazo, luz, halo, metal, id }): farol de hierro con vela.
     poste = alto del poste (abajo al centro en 0,0); sin poste = farol de pared: la
     escuadra se clava en 0,0 y el farol cuelga a la derecha (brazo, 30).
     farol.centro(op) → [x, y] del centro del vidrio (para poner el halo encima).
   · munecoNieve({ bufanda, sombrero:'copa'|'gorro'|'ninguno', brazos, cola, id }):
     abajo al centro en 0,0 (~300 de alto con sombrero). Piezas sueltas para moverlas
     aparte: munecoNieve.brazo('i'|'d') (pivote en el hombro, 0,0),
     munecoNieve.cola(color) (pivote en el nudo, 0,0); pivotes en HOMBRO.i/.d y CUELLO.
   · trineo({ color, patin, nieve }): trineo de madera, abajo al centro en 0,0.
     trineo({ santa:true, renos (3), silueta, pose (0|1), dir (1 → mira a la derecha,
     -1 → a la izquierda), nariz }): el trineo de Santa volando con sus renos, en
     silueta de un solo color (para el cielo). Trineo en 0,0; los renos van delante.
   · cabana({ luz, luces, corona, farol, lena, humo, id }): cabaña de troncos, abajo al
     centro de la fachada en 0,0 (fachada 440 × 232, alero a ±262, cumbre en y = -420,
     chimenea hasta y ≈ -496). cabana.GEO: ventanas, ático, farol, humo y focos del
     alero (para poner encima lo que se mueve).
   · nieveLinea(...) y carambanos(...): ayudantes de nieve y hielo sobre un canto (los usa el letrero). */
var NIEVE_SOMBRA = '#c3cbef', HIELO = '#dcecff';
/* Montón de nieve blanda encima de un segmento (puede ir inclinado), grosor g */
function nieveLinea(x1, y1, x2, y2, g, rnd, color){
  var n = Math.max(2, Math.round(Math.abs(x2 - x1) / 24)), i;
  var X = function(t){ return x1 + (x2 - x1) * t; }, Y = function(t){ return y1 + (y2 - y1) * t; };
  var d = 'M'+f1(x1 - 2)+' '+f1(y1 + 2)+'Q'+f1(x1 - 5)+' '+f1(y1 - g * .7)+' '+f1(X(.5 / n))+' '+f1(Y(.5 / n) - g * .85);
  for (i = 1; i < n; i++) d += 'Q'+f1(X(i / n))+' '+f1(Y(i / n) - g * (1.1 + rnd() * .35))+' '+f1(X((i + .5) / n))+' '+f1(Y((i + .5) / n) - g * (.75 + rnd() * .3));
  d += 'Q'+f1(x2 + 5)+' '+f1(y2 - g * .7)+' '+f1(x2 + 2)+' '+f1(y2 + 2)+'Z';
  return '<path d="'+d+'" fill="'+(color || C.nieve)+'"'+TRAZO+'/>';
}
/* Carámbanos colgando de una recta (pueden ir en un alero inclinado) */
function carambanos(x1, y1, x2, y2, n, largo, rnd){
  var s = '';
  for (var i = 0; i < n; i++){
    var t = (i + .2 + rnd() * .6) / n, x = x1 + (x2 - x1) * t, y = y1 + (y2 - y1) * t;
    var L = largo[0] + rnd() * (largo[1] - largo[0]), w = 2.4 + L * .1;
    s += '<path d="M'+f1(x - w)+' '+f1(y - 1)+'Q'+f1(x - w * .5)+' '+f1(y + L * .5)+' '+f1(x)+' '+f1(y + L)+'Q'+f1(x + w * .45)+' '+f1(y + L * .5)+' '+f1(x + w)+' '+f1(y - 1)+'Z" fill="'+HIELO+'" stroke="'+TINTA+'" stroke-width="1.6" stroke-linejoin="round"/>' +
      '<path d="M'+f1(x - w * .35)+' '+f1(y + 2)+'L'+f1(x - w * .08)+' '+f1(y + L * .6)+'" stroke="#fff" stroke-width="1.4" stroke-linecap="round" opacity=".9"/>';
  }
  return s;
}
function pts(lista){ return lista.map(function(p){ return f1(p.x) + ' ' + f1(p.y); }).join('L'); }
A.nieveLinea = nieveLinea;   /* (x1, y1, x2, y2, grosor, rnd, color): montón de nieve sobre un canto */
A.carambanos = carambanos;   /* (x1, y1, x2, y2, n, [min, max], rnd): carámbanos colgando de un canto */

A.montana = function(op){
  op = op || {};
  var W = op.ancho || 1920, H = op.alto || 260, n = Math.max(1, Math.round(op.picos || 5)), rnd = HW.azar(op.semilla || 11);
  var col = op.color || '#3b4180', colN = op.colorNieve || '#e3e8ff', luz = op.luz == null ? W * .65 : op.luz, fondo = op.fondo == null ? 60 : op.fondo;
  var osc = HW.mezcla(col, TINTA, .42), nOsc = HW.mezcla(colN, col, .42), paso = W / n, picos = [], valles = [], i;
  for (i = 0; i < n; i++) picos.push({ x: paso * (i + .5) + (rnd() - .5) * paso * .4, y: -H * (.6 + rnd() * .4) });
  valles.push({ x: -30, y: picos[0].y * (.3 + rnd() * .2) });
  for (i = 1; i < n; i++){
    var a = picos[i - 1], b = picos[i], t = .35 + rnd() * .3;
    valles.push({ x: a.x + (b.x - a.x) * t, y: Math.max(a.y, b.y) * (.22 + rnd() * .3) });
  }
  valles.push({ x: W + 30, y: picos[n - 1].y * (.3 + rnd() * .2) });
  /* laderas con algo de roca: puntos intermedios desplazados de la recta */
  function ladera(p, q, us){
    var dx = q.x - p.x, dy = q.y - p.y, L = Math.sqrt(dx * dx + dy * dy), nx = -dy / L, ny = dx / L;
    return us.map(function(u){ var j = (rnd() - .5) * L * .07; return { x: p.x + dx * u + nx * j, y: p.y + dy * u + ny * j }; });
  }
  var cresta = [valles[0]], lados = [];
  for (i = 0; i < n; i++){
    var iz = ladera(valles[i], picos[i], [.3, .55, .7, .86]), de = ladera(picos[i], valles[i + 1], [.14, .3, .45, .7]);
    lados.push({ iz: iz, de: de });
    cresta = cresta.concat(iz, [picos[i]], de, [valles[i + 1]]);
  }
  var s = '<g class="nv-montana"><path d="M-30 '+fondo+'L'+pts(cresta)+'L'+(W + 30)+' '+fondo+'Z" fill="'+col+'"/>', sombras = '', gorros = '';
  for (i = 0; i < n; i++){
    var p = picos[i], vi = valles[i], vd = valles[i + 1], L = lados[i], izq = luz > p.x;
    /* cara en sombra: del pico al valle del lado contrario a la luz, hasta el pie */
    if (izq) sombras += '<path d="M'+f1(p.x)+' '+f1(p.y)+'L'+pts(L.iz.slice().reverse())+'L'+f1(vi.x)+' '+f1(vi.y)+'L'+f1(vi.x)+' '+fondo+'L'+f1(p.x + (vd.x - p.x) * .06)+' '+fondo+'Z" fill="'+osc+'" opacity=".55"/>';
    else sombras += '<path d="M'+f1(p.x)+' '+f1(p.y)+'L'+pts(L.de)+'L'+f1(vd.x)+' '+f1(vd.y)+'L'+f1(vd.x)+' '+fondo+'L'+f1(p.x - (p.x - vi.x) * .06)+' '+fondo+'Z" fill="'+osc+'" opacity=".55"/>';
    /* gorro de nieve: baja un 35-45 % de la ladera, borde de abajo en zigzag */
    var ti = .36 + rnd() * .1, td = .36 + rnd() * .1;
    var EI = { x: p.x + (vi.x - p.x) * ti, y: p.y + (vi.y - p.y) * ti }, ED = { x: p.x + (vd.x - p.x) * td, y: p.y + (vd.y - p.y) * td };
    var zig = [], k = 6;
    for (var j = 1; j < k; j++){
      var u = j / k, zx = ED.x + (EI.x - ED.x) * u, zy = ED.y + (EI.y - ED.y) * u + H * .07 * Math.sin(Math.PI * u);
      zig.push({ x: zx, y: zy + (j % 2 ? H * (.04 + rnd() * .05) : -H * .02) });
    }
    gorros += '<path d="M'+f1(EI.x)+' '+f1(EI.y)+'L'+pts([L.iz[2], L.iz[3], p, L.de[0], L.de[1], ED].concat(zig))+'Z" fill="'+colN+'"/>';
    var mitad = zig.filter(function(z){ return izq ? z.x < p.x : z.x > p.x; });
    if (izq) gorros += '<path d="M'+f1(p.x)+' '+f1(p.y)+'L'+pts([L.iz[3], L.iz[2], EI].concat(mitad.reverse()))+'L'+f1(p.x + 2)+' '+f1(p.y + H * .12)+'Z" fill="'+nOsc+'"/>';
    else gorros += '<path d="M'+f1(p.x)+' '+f1(p.y)+'L'+pts([L.de[0], L.de[1], ED].concat(mitad))+'L'+f1(p.x - 2)+' '+f1(p.y + H * .12)+'Z" fill="'+nOsc+'"/>';
  }
  s += sombras + gorros;
  if (op.contorno) s += '<path d="M'+pts(cresta)+'" fill="none"'+TRAZO+'/>';
  return s + '</g>';
};

A.cerca = function(op){
  op = op || {};
  var L = op.largo || 400, h = op.alto || 72, col = op.color || '#8a5a3a', rnd = HW.azar(op.semilla || 5), nv = op.nieve !== false;
  var osc = HW.mezcla(col, TINTA, .35), claro = HW.mezcla(col, '#ffffff', .16);
  var n = Math.max(1, Math.round(L / (op.paso || 66))), dx = L / n, s = '<g class="nv-cerca">', cuerpo = '', gorros = '', tablas = '', nieveT = '', i, hs = [];
  for (i = 0; i <= n; i++) s += '<ellipse cx="'+f1(i * dx + 5)+'" cy="2" rx="17" ry="4" fill="'+TINTA+'" opacity=".16"/>';
  for (i = 0; i <= n; i++){
    var x = i * dx, rot = ((rnd() - .5) * 4).toFixed(1), ph = h + 8 + rnd() * 10; hs.push(ph);
    cuerpo += '<g transform="rotate('+rot+' '+f1(x)+' 0)"><path d="M'+f1(x - 7)+' 2V'+f1(-ph + 7)+'L'+f1(x)+' '+f1(-ph - 1)+'L'+f1(x + 7)+' '+f1(-ph + 7)+'V2Z" fill="'+col+'"'+TRAZO+'/>' +
      '<path d="M'+f1(x + 2.5)+' '+f1(-ph + 9)+'V-6" stroke="'+osc+'" stroke-width="2" stroke-linecap="round" opacity=".6"/></g>';
    if (nv) gorros += '<g transform="rotate('+rot+' '+f1(x)+' 0)"><path d="M'+f1(x - 9.5)+' '+f1(-ph + 6)+'Q'+f1(x - 9)+' '+f1(-ph - 9)+' '+f1(x)+' '+f1(-ph - 10)+'Q'+f1(x + 9.5)+' '+f1(-ph - 9)+' '+f1(x + 9.5)+' '+f1(-ph + 6)+'Q'+f1(x)+' '+f1(-ph + 2)+' '+f1(x - 9.5)+' '+f1(-ph + 6)+'Z" fill="'+C.nieve+'" stroke="'+TINTA+'" stroke-width="2.2" stroke-linejoin="round"/></g>';
  }
  [.38, .76].forEach(function(r, k){
    for (i = 0; i < n; i++){
      var x1 = i * dx - 7, x2 = (i + 1) * dx + 7, y1 = -h * r + (rnd() - .5) * 5, y2 = -h * r + (rnd() - .5) * 5, g = 5.5;
      tablas += '<path d="M'+f1(x1)+' '+f1(y1 - g)+'L'+f1(x2)+' '+f1(y2 - g)+'L'+f1(x2)+' '+f1(y2 + g)+'L'+f1(x1)+' '+f1(y1 + g)+'Z" fill="'+((i + k) % 2 ? col : claro)+'"'+TRAZO+'/>' +
        '<path d="M'+f1(x1 + 7)+' '+f1(y1 + g - 2.6)+'L'+f1(x2 - 7)+' '+f1(y2 + g - 2.6)+'" stroke="'+osc+'" stroke-width="2" opacity=".5"/>' +
        circ(x1 + 11, y1, 1.8, TINTA, ' opacity=".7"') + circ(x2 - 11, y2, 1.8, TINTA, ' opacity=".7"');
      if (nv) nieveT += nieveLinea(x1 + 5, y1 - g, x2 - 5, y2 - g, k ? 8 : 5, rnd);
    }
  });
  s += cuerpo + tablas + nieveT + gorros;
  if (nv) s += nieveLinea(-16, 7, L + 16, 7, 11, rnd);
  return s + '</g>';
};

A.farol = function(op){
  op = op || {};
  var p = prefijo(op), poste = op.poste || 0, brazo = op.brazo || 30, metal = op.metal || '#2b2a3d', luz = op.luz !== false;
  var s = '<g class="nv-farol"><defs><radialGradient id="'+p+'-fv" cx=".5" cy=".62" r=".62"><stop offset="0" stop-color="#fff6c8"/><stop offset=".45" stop-color="#ffd27a"/><stop offset="1" stop-color="#ff9a3c"/></radialGradient>' +
    '<radialGradient id="'+p+'-fh"><stop offset="0" stop-color="#ffd98a" stop-opacity=".6"/><stop offset=".45" stop-color="#ffb04a" stop-opacity=".18"/><stop offset="1" stop-color="#ffb04a" stop-opacity="0"/></radialGradient></defs>';
  var ox = 0, oy = -poste;
  if (poste){
    s += '<ellipse cx="0" cy="2" rx="18" ry="5" fill="'+TINTA+'" opacity=".18"/>' +
      '<rect x="-5" y="'+f1(-poste)+'" width="10" height="'+f1(poste + 2)+'" rx="3" fill="'+metal+'"'+TRAZO+'/>' +
      '<rect x="-9" y="-16" width="18" height="18" rx="4" fill="'+metal+'"'+TRAZO+'/>' +
      '<path d="M-1.5 '+f1(-poste + 6)+'V-20" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".16"/>';
  } else {
    ox = brazo; oy = 75;
    var d = 'M0 0H'+ox+'V8M3 14Q'+f1(ox * .4)+' 3 '+f1(ox * .75)+' 0';
    s += '<rect x="-5" y="-10" width="10" height="28" rx="3" fill="'+metal+'"'+TRAZO+'/>' +
      '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="'+d+'" fill="none" stroke="'+metal+'" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>';
  }
  s += '<g transform="translate('+f1(ox)+' '+f1(oy)+')">';
  if (luz && op.halo !== false) s += '<circle cx="0" cy="-27" r="48" fill="url(#'+p+'-fh)"/>';
  s += '<circle cx="0" cy="-63" r="5" fill="none" stroke="'+TINTA+'" stroke-width="5"/><circle cx="0" cy="-63" r="5" fill="none" stroke="'+metal+'" stroke-width="2.4"/>' +
    '<rect x="-14" y="-46" width="28" height="38" rx="3" fill="'+(luz ? 'url(#'+p+'-fv)' : '#3a3f66')+'"/>';
  if (luz) s += '<rect x="-3.2" y="-23" width="6.4" height="14" rx="2" fill="#fff4dd" stroke="'+TINTA+'" stroke-width="1.4"/>' +
    '<path d="M0-35Q4.5-28 2.6-25Q0-23.6-2.6-25Q-4.5-28 0-35Z" fill="#fff9e0" stroke="#ff9a3c" stroke-width="1.2"/>';
  else s += '<path d="M-9-40L-3-16" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".25"/>';
  s += '<path d="M-14-46H14V-8H-14ZM0-46V-8" fill="none" stroke="'+TINTA+'" stroke-width="6.5" stroke-linejoin="round"/>' +
    '<path d="M-14-46H14V-8H-14ZM0-46V-8" fill="none" stroke="'+metal+'" stroke-width="3" stroke-linejoin="round"/>' +
    '<path d="M-19-46L-6-58H6L19-46Z" fill="'+metal+'"'+TRAZO+'/>' +
    '<path d="M-17 -8H17L14 0H-14Z" fill="'+metal+'"'+TRAZO+'/>' +
    '<path d="M-20-46Q-21-54-12-57Q-4-62 2-59Q12-61 15-54Q22-52 20-46Q10-49 0-48Q-10-49-20-46Z" fill="'+C.nieve+'" stroke="'+TINTA+'" stroke-width="2" stroke-linejoin="round"/>';
  if (luz) s += '<path d="M-10-42V-14" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".55"/>';
  return s + '</g></g>';
};
A.farol.centro = function(op){ op = op || {}; return op.poste ? [0, -op.poste - 27] : [op.brazo || 30, 48]; };

/* Muñeco de nieve: bolas (cx, cy, rx, ry), sombreadas con la luz de la luna */
var MN = { base:[0, -58, 68, 58], medio:[0, -150, 50, 46], cabeza:[0, -222, 38, 37] };
function bolaNieve(b){
  var cx = b[0], cy = b[1], rx = b[2], ry = b[3], hx = cx - rx * .38, hy = cy - ry * .45;
  return '<ellipse cx="'+cx+'" cy="'+cy+'" rx="'+rx+'" ry="'+ry+'" fill="'+NIEVE_SOMBRA+'"/>' +
    '<ellipse cx="'+f1(cx - rx * .1)+'" cy="'+f1(cy - ry * .12)+'" rx="'+f1(rx * .86)+'" ry="'+f1(ry * .84)+'" fill="#f7f8ff"/>' +
    '<ellipse cx="'+f1(hx)+'" cy="'+f1(hy)+'" rx="'+f1(rx * .26)+'" ry="'+f1(ry * .15)+'" transform="rotate(-28 '+f1(hx)+' '+f1(hy)+')" fill="#fff"/>' +
    '<ellipse cx="'+cx+'" cy="'+cy+'" rx="'+rx+'" ry="'+ry+'" fill="none"'+TRAZO+'/>';
}
function ramaBrazo(sg){
  var d = sg < 0 ? 'M0 0Q-34-8-70-36M-36-15Q-48-30-45-46M-70-36L-86-42M-70-36L-79-53M-70-36L-89-30'
                 : 'M0 0Q36 4 76-8M40 1Q52-10 55-26M76-8L91-6M76-8L88-21M76-8L87 4';
  return '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="'+d+'" fill="none" stroke="#6b4428" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="'+(sg < 0 ? 'M-47-23Q-53-31-45-32Q-38-31-40-24Z' : 'M31-3Q29-11 37-10Q43-8 41-3Z')+'" fill="'+C.nieve+'" stroke="'+TINTA+'" stroke-width="1.6" stroke-linejoin="round"/>';
}
function colaBufanda(col){
  var d = 'M-8 0Q-13 30-18 58L3 61Q5 30 9 0Z', flecos = 'M-16 61V70M-10 61.5V71M-4 62V71M2 62V70';
  return '<path d="'+d+'" fill="'+col+'"/>' +
    '<path d="M-11.5 22L6.4 23M-14.5 38L4.8 40" stroke="#fff4dd" stroke-width="4.5"/>' +
    '<path d="'+flecos+'" stroke="'+TINTA+'" stroke-width="5" stroke-linecap="round"/><path d="'+flecos+'" stroke="'+col+'" stroke-width="2.4" stroke-linecap="round"/>' +
    '<path d="'+d+'" fill="none"'+TRAZO+'/>';
}
A.munecoNieve = function(op){
  op = op || {};
  var buf = op.bufanda || C.rojo, som = op.sombrero || 'copa', H = A.munecoNieve.HOMBRO, CU = A.munecoNieve.CUELLO;
  var s = '<g class="nv-muneco"><ellipse cx="4" cy="2" rx="94" ry="13" fill="'+TINTA+'" opacity=".16"/>';
  if (op.brazos !== false) s += '<g transform="translate('+H.i[0]+' '+H.i[1]+')">' + ramaBrazo(-1) + '</g><g transform="translate('+H.d[0]+' '+H.d[1]+')">' + ramaBrazo(1) + '</g>';
  s += bolaNieve(MN.base) +
    '<path d="M-98 5Q-86-17-58-15Q-30-25 0-17Q34-25 62-14Q88-17 100 5Z" fill="#f2f4ff"/>' +
    '<path d="M-98 5Q-86-17-58-15Q-30-25 0-17Q34-25 62-14Q88-17 100 5" fill="none"'+TRAZO+'/>' +
    '<ellipse cx="6" cy="-108" rx="40" ry="9" fill="'+NIEVE_SOMBRA+'"/>' + bolaNieve(MN.medio) + bolaNieve(MN.cabeza);
  /* botones de carbón */
  [[2, -78, 5.6], [3, -46, 5.4], [-1, -168, 5.2], [1, -147, 5.6], [2, -126, 5.2]].forEach(function(b){
    s += circ(b[0], b[1], b[2], TINTA) + circ(b[0] - b[2] * .35, b[1] - b[2] * .35, b[2] * .3, '#fff', ' opacity=".45"');
  });
  /* cara: ojos, mejillas, zanahoria y sonrisa de carboncitos */
  s += circ(-12, -232, 4.8, TINTA) + circ(13, -232, 4.8, TINTA) + circ(-13.5, -233.6, 1.5, '#fff') + circ(11.5, -233.6, 1.5, '#fff') +
    '<ellipse cx="-22" cy="-215" rx="7" ry="4" fill="'+C.rosa+'" opacity=".75"/><ellipse cx="24" cy="-215" rx="7" ry="4" fill="'+C.rosa+'" opacity=".75"/>' +
    '<path d="M1-227L43-218.5L1-213.5Z" fill="#ff8a3d"'+TRAZO+'/>' +
    '<path d="M14-224L13-218M26-221.5L25.5-216.5" stroke="#c4581f" stroke-width="2" stroke-linecap="round"/>' +
    '<path d="M4-224.5L30-219.5" stroke="#ffc08a" stroke-width="2.2" stroke-linecap="round" opacity=".9"/>';
  [[-15, -205], [-8, -201], [0, -199.5], [8, -201], [15, -205]].forEach(function(m){ s += circ(m[0], m[1], 2.7, TINTA); });
  /* bufanda: vuelta al cuello y nudo */
  s += '<path d="M-41-197Q0-176 41-197L44-182Q0-159-44-182Z" fill="'+buf+'"'+TRAZO+'/>' +
    '<path d="M-26-188L-27-174M-6-183L-6-168M16-185L17-170M34-192L35-178" stroke="#fff4dd" stroke-width="4.5" stroke-linecap="round" opacity=".95"/>' +
    '<ellipse cx="'+CU[0]+'" cy="'+CU[1]+'" rx="10" ry="8.5" fill="'+buf+'"'+TRAZO+'/>';
  if (op.cola !== false) s += '<g transform="translate('+CU[0]+' '+CU[1]+')">' + colaBufanda(buf) + '</g>';
  /* sombrero */
  if (som === 'copa'){
    var hc = '#2b2a3d';
    s += '<g transform="rotate(-9 0 -255)"><ellipse cx="0" cy="-255" rx="43" ry="9.5" fill="'+hc+'"'+TRAZO+'/>' +
      '<path d="M-26-256V-301Q-26-306-20-306H20Q26-306 26-301V-256Z" fill="'+hc+'"'+TRAZO+'/>' +
      '<rect x="-26" y="-272" width="52" height="11" fill="'+(op.cinta || C.rojo)+'" stroke="'+TINTA+'" stroke-width="2.4"/>' +
      '<path d="M-43-255A43 9.5 0 0 0 43-255Q30-249 0-248.5Q-30-249-43-255Z" fill="'+hc+'"'+TRAZO+'/>' +
      '<path d="M-18-298V-276" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".22"/>' +
      '<ellipse cx="12" cy="-271" rx="8" ry="4" transform="rotate(-25 12 -271)" fill="'+C.verde+'" stroke="'+TINTA+'" stroke-width="1.6"/>' +
      '<ellipse cx="22" cy="-270" rx="8" ry="4" transform="rotate(20 22 -270)" fill="'+C.verdeClaro+'" stroke="'+TINTA+'" stroke-width="1.6"/>' +
      circ(16, -267, 3.2, C.rojo, ' stroke="'+TINTA+'" stroke-width="1.4"') + circ(19.5, -264, 2.8, C.rojoOsc, ' stroke="'+TINTA+'" stroke-width="1.4"') + '</g>';
  } else if (som === 'gorro'){
    s += '<path d="M-36-246Q-38-292 0-294Q38-292 36-246Z" fill="'+buf+'"'+TRAZO+'/>' +
      '<path d="M-20-258Q-18-282 0-286M4-286Q20-282 22-258" fill="none" stroke="#fff" stroke-width="2.4" opacity=".3" stroke-linecap="round"/>' +
      '<rect x="-40" y="-257" width="80" height="16" rx="8" fill="#fff4dd"'+TRAZO+'/>' + circ(4, -298, 12, '#fff4dd', TRAZO);
  }
  return s + '</g>';
};
A.munecoNieve.HOMBRO = { i:[-46, -164], d:[47, -160] };
A.munecoNieve.CUELLO = [-24, -186];
A.munecoNieve.brazo = function(lado){ return ramaBrazo(lado === 'i' ? -1 : 1); };
A.munecoNieve.cola = function(color){ return colaBufanda(color || C.rojo); };

/* Trineo: de madera (en el patio) o el de Santa volando, en silueta */
function renoSilueta(x, y, pose, k, nariz){
  var patas = pose ? 'M12-26L17-13L25-9M7-26L11-12L18-7M-12-27L-9-13L-17-7M-16-26L-14-12L-22-9'
                   : 'M12-27L28-20L35-14M8-27L23-16L28-9M-12-28L-29-20L-37-17M-16-27L-30-15L-38-14';
  var s = '<g transform="translate('+f1(x)+' '+f1(y)+')"><path d="'+patas+'" fill="none" stroke="'+k+'" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<ellipse cx="0" cy="-32" rx="22" ry="10.5" fill="'+k+'"/><path d="M-19-37Q-29-42-27-31Z" fill="'+k+'"/>' +
    '<path d="M11-39Q17-51 25-57L32-51Q24-45 19-30Z" fill="'+k+'"/>' +
    '<ellipse cx="31" cy="-55" rx="9" ry="6.2" transform="rotate(12 31 -55)" fill="'+k+'"/><path d="M35-59Q43-57 43-52Q42-48.5 36-50Z" fill="'+k+'"/>' +
    '<path d="M27-60Q23-64 20-60Z" fill="'+k+'"/>' +
    '<path d="M28-60Q24-72 17-78M23-70Q17-70 14-66M31-61Q33-74 39-80M34-71Q40-70 43-66" fill="none" stroke="'+k+'" stroke-width="2.3" stroke-linecap="round"/>' +
    circ(10, -25, 2.2, '#ffcf5c');
  if (nariz) s += circ(44, -52, 5.5, '#ff4d5e', ' opacity=".35"') + circ(44, -52, 2.8, '#ff6b78');
  return s + '</g>';
}
A.trineo = function(op){
  op = op || {};
  var s, rnd = HW.azar(op.semilla || 7);
  if (op.santa){
    var k = op.silueta || '#1a1838', n = Math.max(1, Math.min(4, op.renos || 3)), pose = op.pose ? 1 : 0;
    s = '<g class="nv-trineo-santa"' + (op.dir === -1 ? ' transform="scale(-1 1)"' : '') + '>';
    /* riendas y tiros (detrás de todo) */
    var riendas = 'M8-41Q46-34 '+f1(93)+' -32';
    for (var i = 0; i < n - 1; i++) riendas += 'M'+f1(84 + i * 64 + 18)+' '+f1(-6 - i * 5 - 34)+'Q'+f1(84 + i * 64 + 40)+' '+f1(-6 - i * 5 - 32)+' '+f1(84 + (i + 1) * 64 - 16)+' '+f1(-6 - (i + 1) * 5 - 34);
    s += '<path d="'+riendas+'" fill="none" stroke="'+k+'" stroke-width="1.6" stroke-linecap="round"/>';
    for (i = 0; i < n; i++) s += renoSilueta(84 + i * 64, -6 - i * 5, (pose + i) % 2, k, op.nariz !== false && i === n - 1);
    /* saco con regalos, Santa y el trineo */
    s += '<ellipse cx="-38" cy="-46" rx="14" ry="15" fill="'+k+'"/><rect x="-50" y="-68" width="11" height="11" transform="rotate(-14 -44 -62)" fill="'+k+'"/><rect x="-37" y="-67" width="9" height="9" transform="rotate(12 -32 -62)" fill="'+k+'"/>' +
      circ(-11, -38, 14, k) + circ(-6, -57, 8.5, k) +
      '<path d="M-14-61Q-13-73-3-72Q3-71 1-62Z" fill="'+k+'"/><path d="M-12-69Q-19-73-22-68" fill="none" stroke="'+k+'" stroke-width="3" stroke-linecap="round"/>' + circ(-23, -67, 3.6, k) +
      '<path d="M-3-44L9-41" stroke="'+k+'" stroke-width="5" stroke-linecap="round"/>' +
      '<path d="M-50-10Q-62-38-50-54Q-42-60-38-50Q-34-34-14-28H30Q46-28 48-16Q49-10 40-10Z" fill="'+k+'"/>' +
      '<path d="M-56 0H40Q58 0 58-14Q58-26 48-24M-36 0V-10M0 0V-10M30 0V-10" fill="none" stroke="'+k+'" stroke-width="3.6" stroke-linecap="round"/>' +
      circ(47, -22, 6, '#ffd98a', ' opacity=".35"') + circ(47, -22, 2.6, '#ffe6a8');
    return s + '</g>';
  }
  var col = op.color || '#b9773f', patin = op.patin || C.rojo, osc = HW.mezcla(col, TINTA, .35), claro = HW.mezcla(col, '#ffffff', .22);
  var pat = 'M-84-4H46Q74-4 76-24Q77-42 63-42Q53-41 55-32';
  s = '<g class="nv-trineo"><ellipse cx="-4" cy="3" rx="94" ry="8" fill="'+TINTA+'" opacity=".16"/>';
  [-62, -24, 14, 44].forEach(function(x){ s += '<path d="M'+x+'-5V-30" stroke="'+TINTA+'" stroke-width="8" stroke-linecap="round"/><path d="M'+x+'-5V-30" stroke="'+osc+'" stroke-width="4" stroke-linecap="round"/>'; });
  s += '<path d="'+pat+'" fill="none" stroke="'+TINTA+'" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/><path d="'+pat+'" fill="none" stroke="'+patin+'" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="M-78-5.5H42" stroke="#fff" stroke-width="1.4" opacity=".45"/>' +
    '<path d="M-90-34H50L61-46H-79Z" fill="'+claro+'"'+TRAZO+'/>' +
    '<path d="M-86-38H53M-82-42H57" stroke="'+osc+'" stroke-width="1.6" opacity=".6"/>' +
    '<rect x="-94" y="-35" width="148" height="11" rx="4" fill="'+col+'"'+TRAZO+'/>' +
    '<path d="M-80-30H-40M-20-28H30" stroke="'+osc+'" stroke-width="1.6" stroke-linecap="round" opacity=".7"/>' +
    '<path d="M58-38Q78-30 74-14Q70 0 86 6" fill="none" stroke="'+TINTA+'" stroke-width="4" stroke-linecap="round"/><path d="M58-38Q78-30 74-14Q70 0 86 6" fill="none" stroke="#e9d3a6" stroke-width="1.8" stroke-linecap="round"/>';
  if (op.nieve !== false) s += nieveLinea(-84, -44, 54, -44, 7, rnd);
  return s + '</g>';
};

/* Cabaña de troncos. Geometría fija (se escala desde fuera con transform). */
var CAB = (function(){
  var g = {
    ancho:440, alto:232, alero:262, cumbre:-420,
    techo:function(x){ return -420 + Math.min(262, Math.abs(x)) * 206 / 262; },   /* borde de arriba del faldón */
    ventanas:[{ cx:-158, cy:-146, w:92, h:100 }, { cx:158, cy:-146, w:92, h:100 }],
    atico:{ cx:0, cy:-304, r:22 }, puerta:{ cx:0, w:96, h:168 }, farol:[84, -102], humo:[149, -494], luces:[], clavos:[]
  };
  [-1, 1].forEach(function(sg){
    var xs = [254, 214, 174, 134, 94, 54, 14];
    for (var i = 0; i < xs.length; i++) g.clavos.push([sg * xs[i], g.techo(xs[i]) + 26]);
    for (i = 0; i < xs.length - 1; i++){
      var xm = (xs[i] + xs[i + 1]) / 2, ym = (g.techo(xs[i]) + g.techo(xs[i + 1])) / 2 + 26 + 10;
      g.luces.push([sg * xm, ym + 14.5, (i + (sg > 0 ? 3 : 0)) % 5, sg * xm, ym]);
    }
  });
  return g;
})();
function coronita(cx, cy, r){
  var s = '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="'+TINTA+'" stroke-width="'+f1(r * .62)+'"/>' +
    '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="#2c7a4c" stroke-width="'+f1(r * .5)+'"/>';
  var verdes = ['#3fa36a', '#277a4a', '#4fb37a', '#35905c'];
  for (var i = 0; i < 18; i++){
    var a = i / 18 * Math.PI * 2, d = r + (i % 2 ? 3.5 : -3.5), x = cx + d * Math.cos(a), y = cy + d * Math.sin(a), rot = a * 180 / Math.PI + 90 + (i % 2 ? 30 : -30);
    s += '<ellipse cx="'+f1(x)+'" cy="'+f1(y)+'" rx="'+f1(r * .3)+'" ry="'+f1(r * .16)+'" transform="rotate('+f1(rot)+' '+f1(x)+' '+f1(y)+')" fill="'+verdes[i % 4]+'" stroke="'+TINTA+'" stroke-width="1.2"/>';
  }
  for (i = 0; i < 6; i++){ var b = (i + .3) / 6 * Math.PI * 2; if (Math.sin(b) < .6) s += circ(cx + r * Math.cos(b), cy + r * Math.sin(b), r * .13, C.rojo, ' stroke="'+TINTA+'" stroke-width="1.2"'); }
  var by = cy + r;
  s += '<path d="M'+cx+' '+by+'l-7 15l4-1l3 4zM'+cx+' '+by+'l7 15l-4-1l-3 4z" fill="'+C.rojo+'" stroke="'+TINTA+'" stroke-width="1.8" stroke-linejoin="round"/>' +
    '<path d="M'+cx+' '+by+'c-4-10-17-11-16-3c1 5 10 5 16 3zM'+cx+' '+by+'c4-10 17-11 16-3c-1 5-10 5-16 3z" fill="'+C.rojo+'" stroke="'+TINTA+'" stroke-width="1.8" stroke-linejoin="round"/>' +
    circ(cx, by, 3.6, C.rojoOsc, ' stroke="'+TINTA+'" stroke-width="1.6"');
  return s;
}
A.cabana = function(op){
  op = op || {};
  var p = prefijo(op), G = CAB, luz = op.luz !== false, rnd = HW.azar(HW.hash('cabana' + (op.semilla || 3)));
  var cols = op.luces === false ? null : (op.luces && op.luces.length ? op.luces : HW.PALETAS.clasica);
  var MAD = '#8f5a36', MAD2 = '#82502f', MOSC = '#4e2c1a', TAB = '#5e3820', PIEDRA = ['#8d90aa', '#767a95', '#9a9db5'];
  var s = '<g class="nv-cabana"><defs>' +
    '<linearGradient id="'+p+'-vid" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset=".55" stop-color="#ffd27a"/><stop offset="1" stop-color="#ffa94c"/></linearGradient>' +
    '<radialGradient id="'+p+'-at" cx=".5" cy=".55" r=".55"><stop offset="0" stop-color="#fff3c4"/><stop offset="1" stop-color="#ffaa4e"/></radialGradient>' +
    '<clipPath id="'+p+'-fr"><path d="M-209-231L0-396L209-231Z"/></clipPath>' +
    '<clipPath id="'+p+'-pu"><path d="M-48 0V-120A48 48 0 0 1 48-120V0Z"/></clipPath>' +
    '<clipPath id="'+p+'-ch"><path d="M122-470H176V-312L122-352Z"/></clipPath>' +
    '</defs><ellipse cx="-20" cy="6" rx="330" ry="16" fill="'+TINTA+'" opacity=".2"/>';
  var VID = luz ? 'url(#'+p+'-vid)' : '#2d3561', i, x, y;
  /* leña apilada a la izquierda */
  if (op.lena !== false){
    s += '<rect x="-347" y="-100" width="9" height="102" rx="3" fill="'+MOSC+'"'+TRAZO+'/><rect x="-245" y="-100" width="9" height="102" rx="3" fill="'+MOSC+'"'+TRAZO+'/>';
    for (var r = 0; r < 4; r++){
      for (x = -327 + (r % 2) * 11.5; x <= -252; x += 23){
        y = -13 - r * 24 + (rnd() - .5) * 2; var rr = 11.5 + rnd() * 1.5;
        s += circ(x, y, rr, '#b98552', ' stroke="'+TINTA+'" stroke-width="2.4"') + circ(x - 1, y - 1, rr * .62, '#d9ab72') +
          '<circle cx="'+f1(x - 1)+'" cy="'+f1(y - 1)+'" r="'+f1(rr * .36)+'" fill="none" stroke="#a8743f" stroke-width="1.4"/>' + circ(x - 1, y - 1, 1.4, '#8f5a2e');
      }
    }
    s += nieveLinea(-352, -101, -232, -101, 14, rnd);
  }
  /* pared: relleno claro entre troncos + 7 troncos + cabezas de los troncos en las esquinas */
  s += '<rect x="-221" y="-233" width="442" height="215" fill="#d9c4a0"/>';
  for (i = 0; i < 7; i++){
    y = -52 - i * 30;
    s += '<rect x="-224" y="'+(y + 1)+'" width="448" height="28" rx="14" fill="'+(i % 2 ? MAD2 : MAD)+'"'+TRAZO+'/>' +
      '<path d="M-210 '+(y + 7)+'H210" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".16"/>' +
      '<path d="M-212 '+(y + 24)+'H212" stroke="'+MOSC+'" stroke-width="3" stroke-linecap="round" opacity=".35"/>';
    for (var v = 0; v < 3; v++){ var gx = -190 + rnd() * 360, gw = 20 + rnd() * 40; s += '<path d="M'+f1(gx)+' '+f1(y + 12 + rnd() * 8)+'h'+f1(gw)+'" stroke="'+MOSC+'" stroke-width="1.6" stroke-linecap="round" opacity=".45"/>'; }
    [-1, 1].forEach(function(sg){
      var cx = sg * 236, cy = y + 15;
      s += circ(cx, cy, 15, '#b98552', ' stroke="'+TINTA+'" stroke-width="2.6"') + circ(cx - 1, cy - 1, 10, '#d4a46c') +
        '<circle cx="'+f1(cx - 1)+'" cy="'+f1(cy - 1)+'" r="5.5" fill="none" stroke="#a8743f" stroke-width="1.4"/>';
    });
  }
  /* zócalo de piedra */
  for (x = -222; x < 222; x += 0){
    var w = 26 + rnd() * 18; if (x + w > 224) w = 224 - x;
    s += '<rect x="'+f1(x + 1)+'" y="-22" width="'+f1(w - 2)+'" height="22" rx="8" fill="'+PIEDRA[Math.floor(rnd() * 3)]+'" stroke="'+TINTA+'" stroke-width="2.4"/>';
    x += w;
  }
  /* frontón de tablas verticales con ventana redonda */
  s += '<g clip-path="url(#'+p+'-fr)">';
  for (x = -210, i = 0; x < 210; x += 21, i++) s += '<rect x="'+x+'" y="-400" width="21" height="170" fill="'+(i % 2 ? '#9a6440' : '#8e5b39')+'"/><path d="M'+x+'-400V-230" stroke="'+MOSC+'" stroke-width="2.4" opacity=".7"/>';
  s += '<path d="M-209-231L0-396L209-231" fill="none" stroke="#2a1608" stroke-width="22" opacity=".3"/></g>' +
    '<path d="M-221-232H221" stroke="'+TINTA+'" stroke-width="3"/>';
  var A0 = G.atico;
  s += circ(A0.cx, A0.cy, A0.r + 7, MOSC, TRAZO) + circ(A0.cx, A0.cy, A0.r, luz ? 'url(#'+p+'-at)' : '#2d3561', ' stroke="'+TINTA+'" stroke-width="2.4"') +
    '<path d="M'+(A0.cx - A0.r)+' '+A0.cy+'H'+(A0.cx + A0.r)+'M'+A0.cx+' '+(A0.cy - A0.r)+'V'+(A0.cy + A0.r)+'" stroke="'+MOSC+'" stroke-width="4"/>' +
    '<path d="M'+(A0.cx - 12)+' '+(A0.cy - 9)+'Q'+(A0.cx - 9)+' '+(A0.cy - 14)+' '+(A0.cx - 3)+' '+(A0.cy - 15)+'" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".6"/>';
  /* ventanas con cortinas, gatito y arbolito por dentro, alféizar con nieve */
  G.ventanas.forEach(function(vn, k){
    var x0 = vn.cx - vn.w / 2, y0 = vn.cy - vn.h / 2, x1 = x0 + vn.w, y1 = y0 + vn.h, cx = vn.cx;
    s += '<rect x="'+(x0 - 9)+'" y="'+(y0 - 9)+'" width="'+(vn.w + 18)+'" height="'+(vn.h + 18)+'" rx="5" fill="'+MOSC+'"'+TRAZO+'/>' +
      '<rect x="'+x0+'" y="'+y0+'" width="'+vn.w+'" height="'+vn.h+'" fill="'+VID+'" stroke="'+TINTA+'" stroke-width="2"/>';
    if (luz){
      var sil = '#c2652e';
      if (k === 0) s += '<g opacity=".7" fill="'+sil+'"><ellipse cx="'+(cx + 15)+'" cy="'+(y1 - 12)+'" rx="11" ry="12"/>' + circ(cx + 13, y1 - 28, 7.5, sil) +
        '<path d="M'+(cx + 7)+' '+(y1 - 32)+'l1-9l5 5zM'+(cx + 19)+' '+(y1 - 32)+'l-1-9l-5 5z"/><path d="M'+(cx + 24)+' '+(y1 - 4)+'q10 0 9-12" fill="none" stroke="'+sil+'" stroke-width="3.4" stroke-linecap="round"/></g>';
      else s += '<g opacity=".7" fill="'+sil+'"><path d="M'+(cx - 23)+' '+(y1 - 3)+'h8v-12h-8zM'+(cx - 19)+' '+(y1 - 46)+'l13 18h-6l9 12h-32l9-12h-6z"/>' + circ(cx - 19, y1 - 48, 2.6, '#fff3c4') + '</g>';
      /* cortinas recogidas */
      [-1, 1].forEach(function(sg){
        var xa = sg < 0 ? x0 : x1, d = 'M'+xa+' '+(y0 + 3)+'H'+(xa - sg * 30)+'Q'+(xa - sg * 15)+' '+(y0 + 42)+' '+(xa - sg * 13)+' '+(y0 + 54)+'Q'+(xa - sg * 17)+' '+(y0 + 66)+' '+(xa - sg * 18)+' '+y1+'H'+xa+'Z';
        s += '<path d="'+d+'" fill="'+C.rojo+'" stroke="'+TINTA+'" stroke-width="2" stroke-linejoin="round"/>' +
          '<path d="M'+(xa - sg * 8)+' '+(y0 + 8)+'Q'+(xa - sg * 7)+' '+(y0 + 50)+' '+(xa - sg * 9)+' '+(y1 - 4)+'" fill="none" stroke="#fff4dd" stroke-width="2" opacity=".6"/>' +
          '<path d="M'+(xa - sg * 2)+' '+(y0 + 52)+'L'+(xa - sg * 15)+' '+(y0 + 55)+'" stroke="'+C.dorado+'" stroke-width="4" stroke-linecap="round"/>';
      });
      s += '<path d="M'+x0+' '+(y0 + 2)+'H'+x1+'V'+(y0 + 11)+'Q'+(x1 - 8)+' '+(y0 + 17)+' '+(x1 - 15)+' '+(y0 + 11)+'Q'+(x1 - 23)+' '+(y0 + 17)+' '+(x1 - 31)+' '+(y0 + 11)+'Q'+(cx + 8)+' '+(y0 + 17)+' '+cx+' '+(y0 + 11)+'Q'+(cx - 8)+' '+(y0 + 17)+' '+(cx - 15)+' '+(y0 + 11)+'Q'+(x0 + 23)+' '+(y0 + 17)+' '+(x0 + 15)+' '+(y0 + 11)+'Q'+(x0 + 8)+' '+(y0 + 17)+' '+x0+' '+(y0 + 11)+'Z" fill="'+C.rojoOsc+'" stroke="'+TINTA+'" stroke-width="1.8" stroke-linejoin="round"/>';
    } else s += '<path d="M'+(x0 + 10)+' '+(y0 + 20)+'L'+(x0 + 30)+' '+(y0 + 4)+'" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".2"/>';
    s += '<path d="M'+cx+' '+y0+'V'+y1+'M'+x0+' '+(vn.cy - 4)+'H'+x1+'" stroke="'+TINTA+'" stroke-width="8"/><path d="M'+cx+' '+y0+'V'+y1+'M'+x0+' '+(vn.cy - 4)+'H'+x1+'" stroke="'+MOSC+'" stroke-width="4.5"/>' +
      nieveLinea(x0 - 8, y0 - 9, x1 + 8, y0 - 9, 6, rnd) +
      '<rect x="'+(x0 - 16)+'" y="'+(y1 + 6)+'" width="'+(vn.w + 32)+'" height="10" rx="3" fill="'+TAB+'"'+TRAZO+'/>' +
      nieveLinea(x0 - 18, y1 + 6, x1 + 18, y1 + 6, 9, rnd);
  });
  /* puerta en arco con su corona */
  s += '<path d="M-58 0V-120A58 58 0 0 1 58-120V0Z" fill="'+MOSC+'"'+TRAZO+'/>' +
    '<path d="M-48 0V-120A48 48 0 0 1 48-120V0Z" fill="#7a4426"/><g clip-path="url(#'+p+'-pu)">' +
    '<rect x="-48" y="-170" width="24" height="170" fill="#84492a"/><rect x="0" y="-170" width="24" height="170" fill="#84492a"/>' +
    '<path d="M-24-162V0M0-168V0M24-162V0" stroke="'+MOSC+'" stroke-width="2.6"/></g>' +
    '<path d="M-48 0V-120A48 48 0 0 1 48-120V0" fill="none"'+TRAZO+'/>';
  [-136, -36].forEach(function(hy){
    s += '<path d="M-48 '+hy+'H-8" stroke="'+TINTA+'" stroke-width="8" stroke-linecap="round"/><path d="M-48 '+hy+'H-8" stroke="#3b3a4f" stroke-width="4.4" stroke-linecap="round"/>' +
      circ(-38, hy, 1.6, '#c9c6d8') + circ(-20, hy, 1.6, '#c9c6d8');
  });
  s += circ(32, -78, 5.5, C.dorado, TRAZO) + circ(30.5, -79.5, 1.6, '#fff', ' opacity=".8"');
  if (op.corona !== false) s += coronita(0, -114, 22);
  /* tejadillo de la puerta con nieve y carámbanos */
  s += '<path d="M-60-150L-44-176M60-150L44-176" stroke="'+TINTA+'" stroke-width="8" stroke-linecap="round"/><path d="M-60-150L-44-176M60-150L44-176" stroke="'+TAB+'" stroke-width="4" stroke-linecap="round"/>' +
    '<path d="M-78-174L0-214L78-174L78-163L0-203L-78-163Z" fill="'+TAB+'"'+TRAZO+'/>' +
    carambanos(-74, -164, -6, -201, 4, [7, 18], rnd) + carambanos(6, -201, 74, -164, 4, [7, 18], rnd) +
    nieveLinea(-84, -172, 2, -215, 10, rnd) + nieveLinea(-2, -215, 84, -172, 10, rnd);
  /* tejado: tablas del alero, nieve gorda, carámbanos y la chimenea de piedra */
  [-1, 1].forEach(function(sg){
    s += '<path d="M'+(sg * 268)+' -212L0-421L0-395L'+(sg * 268)+' -188Z" fill="'+TAB+'"'+TRAZO+'/>' +
      '<path d="M'+(sg * 256)+' -205L'+(sg * 12)+' -396" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".14"/>';
  });
  s += carambanos(-258, -190, -40, -362, 12, [9, 34], rnd) + carambanos(40, -362, 258, -190, 12, [9, 34], rnd);
  s += nieveLinea(-282, -210, 4, -423, 28, rnd) + nieveLinea(-4, -423, 282, -210, 28, rnd) +
    '<ellipse cx="-278" cy="-205" rx="17" ry="11" fill="'+C.nieve+'"'+TRAZO+'/><ellipse cx="278" cy="-205" rx="17" ry="11" fill="'+C.nieve+'"'+TRAZO+'/>' +
    '<ellipse cx="0" cy="-434" rx="27" ry="14" fill="'+C.nieve+'"/><path d="M-27-434A27 14 0 0 1 27-434" fill="none"'+TRAZO+'/>' +
    '<path d="M-250-214L-12-404M12-404L250-214" stroke="'+NIEVE_SOMBRA+'" stroke-width="5" stroke-linecap="round" opacity=".55"/>';
  s += '<path d="M122-470H176V-312L122-352Z" fill="'+PIEDRA[1]+'"/><g clip-path="url(#'+p+'-ch)">';
  for (y = -470, i = 0; y < -290; y += 16, i++){
    for (x = 116 + (i % 2) * 12; x < 180; x += 22) s += '<rect x="'+f1(x)+'" y="'+(y + 1)+'" width="20" height="14" rx="5" fill="'+PIEDRA[(i + Math.round(x)) % 3]+'" stroke="'+TINTA+'" stroke-width="1.6"/>';
  }
  s += '<rect x="122" y="-470" width="12" height="180" fill="#fff" opacity=".12"/><rect x="162" y="-470" width="14" height="180" fill="'+TINTA+'" opacity=".22"/></g>' +
    '<path d="M122-352V-470H176V-312" fill="none"'+TRAZO+'/>' +
    '<rect x="113" y="-484" width="72" height="15" rx="4" fill="#5d6079"'+TRAZO+'/>' +
    nieveLinea(111, -484, 187, -484, 10, rnd);
  /* nieve al pie de la chimenea: sigue la pendiente del tejado (y = -423 + (x + 4) × .745) y se funde con la
     nieve del tejado: va rellena y solo lleva contorno arriba, como un montoncito que cubre el corte de la piedra */
  var alero = function(x, k){ return f1(-423 + (x + 4) * .745 - k); };
  s += '<path d="M96 '+alero(96, 26)+'Q112 '+alero(112, 40)+' 128 '+alero(128, 39)+'Q144 '+alero(144, 45)+' 158 '+alero(158, 38)+'Q174 '+alero(174, 43)+' 188 '+alero(188, 35)+'Q200 '+alero(200, 33)+' 212 '+alero(212, 20)+'L212 '+alero(212, 6)+'L96 '+alero(96, 6)+'Z" fill="'+C.nieve+'"/>' +
    '<path d="M96 '+alero(96, 26)+'Q112 '+alero(112, 40)+' 128 '+alero(128, 39)+'Q144 '+alero(144, 45)+' 158 '+alero(158, 38)+'Q174 '+alero(174, 43)+' 188 '+alero(188, 35)+'Q200 '+alero(200, 33)+' 212 '+alero(212, 20)+'" fill="none"'+TRAZO+'/>';
  /* focos en el alero */
  if (cols){
    [-1, 1].forEach(function(sg){
      var cl = G.clavos.filter(function(c){ return c[0] * sg > 0; }), d = 'M' + f1(cl[0][0]) + ' ' + f1(cl[0][1]);
      for (var j = 0; j < cl.length - 1; j++) d += 'Q'+f1((cl[j][0] + cl[j + 1][0]) / 2)+' '+f1((cl[j][1] + cl[j + 1][1]) / 2 + 20)+' '+f1(cl[j + 1][0])+' '+f1(cl[j + 1][1]);
      s += '<path d="'+d+'" fill="none" stroke="#123524" stroke-width="3" stroke-linecap="round"/>';
    });
    G.luces.forEach(function(l){
      s += '<g transform="translate('+f1(l[3])+' '+f1(l[4])+') rotate('+((rnd() - .5) * 24).toFixed(1)+') scale(.5)">' + A.foco(cols[l[2] % cols.length]) + '</g>';
    });
    G.clavos.forEach(function(c){ s += circ(c[0], c[1], 2.4, '#2a2838'); });
  }
  /* farol de pared junto a la puerta */
  if (op.farol !== false) s += '<g transform="translate(60 -150)">' + A.farol({ brazo: 24, luz: luz, id: p + '-fa' }) + '</g>';
  /* escalón y nieve al pie de la fachada */
  s += '<rect x="-68" y="-8" width="136" height="14" rx="7" fill="'+PIEDRA[0]+'"'+TRAZO+'/>' + nieveLinea(-70, -7, -30, -7, 5, rnd) + nieveLinea(34, -7, 68, -7, 5, rnd) +
    nieveLinea(-256, 7, -62, 7, 15, rnd) + nieveLinea(62, 7, 256, 7, 15, rnd);
  if (op.humo){
    var hx = G.humo[0], hy = G.humo[1];
    for (i = 0; i < 4; i++) s += '<circle class="hw-humo" cx="'+hx+'" cy="'+hy+'" r="'+(10 + i * 2)+'" fill="#e6e8f5" style="--hx:'+(14 + i * 8)+'px;animation-delay:-'+(i * 1.5)+'s"/>';
  }
  return s + '</g>';
};
A.cabana.GEO = CAB;
/* Animales del fondo Blanca Navidad (feedback 05-nov). Suelo en y = 0, mirando a la derecha. Cada pose es un
   dibujo entero: la pieza enseña uno u otro (como las dos poses del trineo), nada animado por dentro.
   zorro(pose): anda1, anda2, quieto, sentado, sentado2 · ciervo(pose): anda1, anda2, quieto, mira, come, come2
   buho(pose): quieto, parpadea, izq, der, vuelo1, vuelo2 */
function trazoAnimal(g){ return ' stroke="'+TINTA+'" stroke-width="'+(g || 3.4)+'" stroke-linejoin="round" stroke-linecap="round"'; }
A.zorro = function(pose){
  var PIEL = '#e5823a', OSCURA = '#c4622a', CREMA = '#fff1dc', CAL = '#3a2a2c', TR = trazoAnimal();
  var sentado = /^sentado/.test(pose), s = '<ellipse cx="'+(sentado ? 0 : -6)+'" cy="2" rx="'+(sentado ? 74 : 92)+'" ry="7" fill="'+TINTA+'" opacity=".16"/>';
  function pata(x, a, lejos){
    var d = 'M'+(x - 8)+'-44V-8Q'+(x - 8)+'-1 '+x+'-1Q'+(x + 9)+'-1 '+(x + 9)+'-7V-44Z';
    return '<g transform="rotate('+a+' '+x+' -40)"><path d="'+d+'" fill="'+(lejos ? OSCURA : PIEL)+'"'+TR+'/>' +
      '<path d="M'+(x - 6.4)+'-18H'+(x + 7.4)+'V-7Q'+(x + 7.4)+'-2.6 '+x+'-2.6Q'+(x - 6.4)+'-2.6 '+(x - 6.4)+'-8Z" fill="'+CAL+'"/></g>';
  }
  function cabeza(dx, dy, ojo){
    var o = '<g transform="translate('+dx+' '+dy+')"><path d="M36-72C36-84 38-96 42-105C50-99 58-93 62-88C68-93 78-99 87-103C91-93 91-82 88-72C98-68 108-64 117-60C110-52 96-44 78-42C58-42 38-54 36-72Z" fill="'+PIEL+'"'+TR+'/>' +
      '<path d="M46-61C62-58 92-60 115-60C108-53 95-46 78-44C63-44 52-51 46-61Z" fill="'+CREMA+'"/>' +
      '<path d="M45.5-96C50-92 53-89 55-86L45-81Z" fill="'+CAL+'"/><path d="M84-94C80-91 74-88 71-85L84-79Z" fill="'+CAL+'"/>' +
      circ(114.5, -60.5, 4.8, CAL) + circ(113, -62, 1.3, '#fff', ' opacity=".8"') + '<path d="M112-55Q104-50 94-51" fill="none" stroke="'+CAL+'" stroke-width="2" stroke-linecap="round"/>';
    if (ojo === 'cerrado') o += '<path d="M71-73Q77-68 83-73" fill="none" stroke="'+CAL+'" stroke-width="3" stroke-linecap="round"/>';
    else o += '<ellipse cx="77" cy="-73" rx="3.8" ry="4.6" fill="'+CAL+'"/>' + circ(78.2, -74.8, 1.3, '#fff');
    return o + '</g>';
  }
  if (sentado){
    s += '<path d="'+(pose === 'sentado2' ? 'M-42-16C-74-30-100-14-86 2H14' : 'M-42-16C-72-26-96-8-80 2H14')+'C8-10-18-8-42-16Z" fill="'+PIEL+'"'+TR+'/><path d="M-22 1.6H14C10-5 2-8-8-9C-12-4-18-1-22 1.6Z" fill="'+CREMA+'"/>';
    s += '<path d="M-48-22C-52-48-30-62-10-70C4-84 22-94 36-86C48-78 46-60 42-44C40-30 38-14 36-3L-28-1C-44-4-47-12-48-22Z" fill="'+PIEL+'"'+TR+'/>' +
      '<path d="M4-74C18-82 32-72 34-58C36-40 30-20 26-8C14-14 2-40 4-74Z" fill="'+CREMA+'"/>' +
      '<path d="M-44-20C-44-40-30-52-14-50" fill="none" stroke="'+OSCURA+'" stroke-width="3" stroke-linecap="round"/>' +
      pata(14, 0) + pata(30, 0) + cabeza(-22, -20, pose === 'sentado2' ? 'cerrado' : '');
    return s;
  }
  var a = pose === 'anda1' ? 18 : pose === 'anda2' ? -18 : 0, cola = pose === 'quieto' ? -6 : 0;
  s += '<g transform="rotate('+cola+' -50 -42)"><path d="M-52-46C-78-66-106-68-124-50C-134-38-128-28-114-27C-92-25-70-27-50-34Z" fill="'+PIEL+'"'+TR+'/>' +
    '<path d="M-122.6-48C-131-37-126-29-114-28.6C-108-28-104-31-101-37C-105-44-113-50-122.6-48Z" fill="'+CREMA+'"/></g>';
  s += pata(-24, -a, true) + pata(44, a, true) + pata(-40, a) + pata(28, -a);
  s += '<path d="M-58-42C-58-60-30-68 0-66C26-65 44-62 52-52C56-40 48-28 30-26L-36-26C-50-28-58-32-58-42Z" fill="'+PIEL+'"'+TR+'/>' +
    '<path d="M-38-28C-18-33 18-33 32-28L30-27.6L-36-27.6Z" fill="'+CREMA+'"/>' +
    '<path d="M36-62C50-64 62-58 60-46C58-33 46-27 38-30C43-40 41-52 36-62Z" fill="'+CREMA+'"/>';
  return s + cabeza(pose === 'quieto' ? -2 : 0, pose === 'quieto' ? -6 : 0);
};
A.ciervo = function(pose){
  var PIEL = '#b67a4c', OSCURA = '#96603a', CREMA = '#f8e7cf', CAL = '#3a2a2c', ASTA = '#e0c79a', TR = trazoAnimal();
  var s = '<ellipse cx="0" cy="2" rx="96" ry="8" fill="'+TINTA+'" opacity=".16"/>';
  var a = pose === 'anda1' ? 15 : pose === 'anda2' ? -15 : 0;
  function pata(x, g, lejos){
    return '<g transform="rotate('+g+' '+x+' -104)"><path d="M'+(x - 8)+'-112C'+(x - 8)+'-84 '+(x - 5)+'-60 '+(x - 5)+'-10H'+(x + 6)+'C'+(x + 6)+'-60 '+(x + 10)+'-84 '+(x + 10)+'-112Z" fill="'+(lejos ? OSCURA : PIEL)+'"'+TR+'/>' +
      '<path d="M'+(x - 6)+'-13H'+(x + 7)+'L'+(x + 8)+'-1H'+(x - 7)+'Z" fill="'+CAL+'"'+TR+'/></g>';
  }
  s += pata(-44, -a, true) + pata(46, a, true) + pata(-58, a) + pata(32, -a);
  s += '<path d="M-66-142C-78-150-86-138-76-126C-70-124-66-132-66-142Z" fill="'+CREMA+'"'+TR+'/>';
  s += '<path d="M-72-130C-74-148-52-154-20-152C16-152 46-152 60-142C72-132 68-106 52-100C20-94-24-94-50-100C-66-106-72-118-72-130Z" fill="'+PIEL+'"'+TR+'/>' +
    '<path d="M-40-103C-14-110 26-110 46-103C24-97-20-97-40-103Z" fill="'+CREMA+'"/>' +
    '<path d="M-71-130C-72-142-62-150-52-150C-60-138-60-116-50-101C-64-106-70-118-71-130Z" fill="'+CREMA+'"/>';
  [[-28, -136, 3.6], [-8, -142, 3.2], [12, -134, 3.6], [-16, -124, 2.8], [30, -142, 3]].forEach(function(p){ s += circ(p[0], p[1], p[2], CREMA, ' opacity=".85"'); });
  var g = pose === 'come' ? 84 : pose === 'come2' ? 78 : pose === 'mira' ? -5 : 0;
  s += '<g transform="rotate('+g+' 48 -132)"><path d="M36-142C50-164 60-190 68-208L100-198C94-172 84-134 62-112Z" fill="'+PIEL+'"'+TR+'/>' +
    '<path d="M72-180C78-164 74-138 62-118C68-140 72-158 72-180Z" fill="'+CREMA+'"/>';
  /* astas: cada rama con su contorno */
  var astas = 'M88-226C86-246 94-262 110-274M92-250C100-252 106-252 112-258M72-226C66-244 54-254 40-260M60-246C54-246 48-246 42-250';
  s += '<path d="'+astas+'" fill="none" stroke="'+TINTA+'" stroke-width="8.4" stroke-linecap="round"/><path d="'+astas+'" fill="none" stroke="'+ASTA+'" stroke-width="3.6" stroke-linecap="round"/>' +
    '<path d="M70-218C60-234 46-240 38-234C42-222 54-210 68-210Z" fill="'+PIEL+'"'+TR+'/><path d="M64-218C56-227 49-231 44-230C47-224 54-217 62-214Z" fill="'+CREMA+'"/>' +
    '<path d="M62-214C68-228 90-232 102-226C114-222 128-214 138-208C142-198 132-192 122-190C106-186 84-184 72-192C64-198 60-206 62-214Z" fill="'+PIEL+'"'+TR+'/>' +
    '<path d="M112-200C120-200 132-204 139-206C141-198 132-193 122-191C118-192 114-195 112-200Z" fill="'+CREMA+'"/>' +
    circ(136, -207, 5, CAL) + '<ellipse cx="96" cy="-210" rx="4.2" ry="5" fill="'+CAL+'"/>' + circ(97.4, -212, 1.5, '#fff') + '</g>' +
    '<ellipse cx="46" cy="-126" rx="19" ry="17" fill="'+PIEL+'"/>';
  return s;
};
A.buho = function(pose){
  var PLUMA = '#8a6242', OSCURA = '#6b4a30', CREMA = '#f3e2c4', ORO = '#ffcf5c', PICO = '#e8a23c', CAL = '#2a2030', TR = trazoAnimal(3);
  var vuelo = /^vuelo/.test(pose), s = '';
  function ala(sg){
    var g = pose === 'vuelo2' ? 34 : -6;
    return '<g transform="scale('+sg+' 1) rotate('+g+' 30 -72)"><path d="M28-82C60-110 104-110 128-88C108-84 104-72 90-70C84-60 72-60 62-56C52-50 40-52 30-58Z" fill="'+PLUMA+'"'+TR+'/>' +
      '<path d="M46-74C66-90 92-94 112-88M58-62C72-68 84-74 92-82" fill="none" stroke="'+OSCURA+'" stroke-width="3" stroke-linecap="round"/></g>';
  }
  if (vuelo) s += ala(1) + ala(-1);
  else s += '<path d="M-24-2V6M-14-2V6M14-2V6M24-2V6" stroke="'+PICO+'" stroke-width="6" stroke-linecap="round"/>';
  s += '<path d="M-36-22C-46-52-42-94-26-106C-14-114 14-114 26-106C42-94 46-52 36-22C26-4-26-4-36-22Z" fill="'+PLUMA+'"'+TR+'/>' +
    '<path d="M-30-102L-40-127L-13-112ZM30-102L40-127L13-112Z" fill="'+PLUMA+'"'+TR+'/>' +
    '<path d="M-23-22C-31-46-27-68-14-74C-6-78 6-78 14-74C27-68 31-46 23-22C12-9-12-9-23-22Z" fill="'+CREMA+'"/>';
  [[-12, -60], [0, -56], [12, -60], [-16, -44], [-5, -40], [6, -40], [16, -44], [-10, -26], [1, -24], [11, -26]].forEach(function(p){
    s += '<path d="M'+(p[0] - 4)+' '+p[1]+'Q'+p[0]+' '+(p[1] + 5)+' '+(p[0] + 4)+' '+p[1]+'" fill="none" stroke="'+OSCURA+'" stroke-width="2.4" stroke-linecap="round"/>';
  });
  if (!vuelo) s += '<path d="M-38-84C-52-62-50-36-34-20C-28-40-28-64-38-84ZM38-84C52-62 50-36 34-20C28-40 28-64 38-84Z" fill="'+OSCURA+'"'+TR+'/>';
  var mira = pose === 'izq' ? -3.6 : pose === 'der' ? 3.6 : 0;
  s += circ(-14, -87, 17.5, CREMA, ' stroke="'+OSCURA+'" stroke-width="2.4"') + circ(14, -87, 17.5, CREMA, ' stroke="'+OSCURA+'" stroke-width="2.4"');
  [-14, 14].forEach(function(x){
    if (pose === 'parpadea') s += '<path d="M'+(x - 9)+'-87Q'+x+'-80 '+(x + 9)+'-87" fill="none" stroke="'+CAL+'" stroke-width="3.4" stroke-linecap="round"/>';
    else s += circ(x, -87, 10.5, ORO, ' stroke="'+CAL+'" stroke-width="2"') + circ(x + mira, -87, 6.2, CAL) + circ(x + mira + 2, -89.4, 1.8, '#fff');
  });
  return s + '<path d="M-6-80Q0-84 6-80L0-68Z" fill="'+PICO+'"'+TR+'/>';
};

/* ── fase 7: casa de jengibre (HW.arte.jengibre) ─────────────────
   La MISMA casa para el «Fondo: Casa de jengibre» (interior) y la «Cocina de
   Navidad» (exterior, en el mostrador): ventana() y gomita() son las mismas
   funciones en los dos fondos, así se reconoce que es la misma casita.
   · COL: colores (galleta, glaseado, gomitas, caramelo translúcido…)
   · hueco(w, h) → { d, r, k }: camino del hueco de la ventana (abajo al centro
     en 0,0; arco elíptico arriba de alto k). Sirve para recortes (clip-path).
   · ventana({ w, h, luz, vidrio:'caramelo', hueco, id }): ventana en arco, abajo
     al centro en 0,0 (el alféizar queda debajo de y = 0). Marco y cruz de
     glaseado, vitral de caramelo de 4 colores translúcidos. luz → resplandor
     cálido dentro (clase .jg-luz para animar su opacidad). hueco:true → sin
     fondo: el caramelo deja ver lo que haya detrás (interior del fondo a).
   · gomita(c, { x, y, r }): gomita azucarada apoyada en (x, y). c = nombre de
     COL.gomitas (rojo, verde, amarillo, morado, rosa) o un hex.
   · glaseado(d, op): si d es un camino → trazo grueso de glaseado (contorno
     tinta + crema + brillo), op.grosor. Si d es { x1, x2, y, grosor, goteos,
     largo:[min,max], prob, semilla } → banda horizontal con ondas y goteos
     (arriba en y, el borde de abajo ondulado en y + grosor).
   · casa({ luz, humo, nieve, id, semilla }): exterior completo, abajo al centro
     en 0,0, ~400 × 380 (más el humo). Todas las animaciones van en clases
     (hw-humo, jg-luz): si no se quieren, basta no cargar su CSS.
     Con partes:true devuelve [[capa, svg], …] en orden de dibujo, para armarla por
     pasos (la cocina con la Sra. Claus). Capas: defs, sombra, humo, paredes, chimenea,
     copo, hueco, ventana, puerta, dulce, techo, tejas, alero, cumbre, estrella.
   ───────────────────────────────────────────────────────────── */
var J = A.jengibre = {};
J.COL = {
  galleta:'#c47a3d', galletaOsc:'#9a5a2a', galletaClaro:'#d9955a', tostado:'#7e4521',
  glaseado:'#fffaf0', glaseadoSombra:'#ecdcc4', chocolate:'#5b3222', chocolateOsc:'#3f2117',
  gomitas:{ rojo:'#e8424f', verde:'#35a85c', amarillo:'#ffc93c', morado:'#9a62d6', rosa:'#ff8fb8' },
  /* caramelo translúcido: [color, opacidad] (naranja, rojo, amarillo, naranja tostado) */
  caramelo:[ ['#ff9a3c', .5], ['#e8424f', .42], ['#ffcf5c', .5], ['#ff7a3d', .46] ]
};
J.GOMITAS = ['rojo', 'verde', 'amarillo', 'morado', 'rosa'];

J.gomita = function(c, op){
  op = op || {};
  var col = J.COL.gomitas[c] || HW.hex(c, J.COL.gomitas.rojo), r = op.r || 14, x = op.x || 0, y = op.y || 0, h = r * 1.15;
  var osc = HW.mezcla(col, TINTA, .3), sw = r < 8 ? 1.6 : r < 15 ? 2.4 : 3;
  var rnd = HW.azar(HW.hash(col + '|' + f1(x) + '|' + f1(y) + '|' + f1(r)));
  var d = 'M'+f1(-r)+' 0C'+f1(-r)+' '+f1(-h * .66)+' '+f1(-r * .6)+' '+f1(-h)+' 0 '+f1(-h)+'C'+f1(r * .6)+' '+f1(-h)+' '+f1(r)+' '+f1(-h * .66)+' '+f1(r)+' 0Q0 '+f1(r * .08)+' '+f1(-r)+' 0Z';
  var s = '<g class="jg-gomita" transform="translate('+f1(x)+' '+f1(y)+')">' +
    '<path d="'+d+'" fill="'+col+'" stroke="'+TINTA+'" stroke-width="'+sw+'" stroke-linejoin="round"/>' +
    '<path d="M'+f1(r * .52)+' '+f1(-h * .12)+'Q'+f1(r * .66)+' '+f1(-h * .6)+' '+f1(r * .12)+' '+f1(-h * .84)+'" fill="none" stroke="'+osc+'" stroke-width="'+f1(r * .2)+'" stroke-linecap="round" opacity=".4"/>' +
    '<ellipse cx="'+f1(-r * .4)+'" cy="'+f1(-h * .6)+'" rx="'+f1(r * .17)+'" ry="'+f1(r * .3)+'" transform="rotate(28 '+f1(-r * .4)+' '+f1(-h * .6)+')" fill="#fff" opacity=".62"/>';
  /* cristalitos de azúcar */
  var n = r < 8 ? 3 : r < 15 ? 6 : 10;
  for (var i = 0, k = 0; i < 40 && k < n; i++){
    var px = (rnd() * 2 - 1) * r * .8, py = -h * (.12 + rnd() * .76);
    if ((px * px) / (r * r) + Math.pow((py + h * .35) / (h * .7), 2) > .8) continue;
    s += '<rect x="'+f1(px)+'" y="'+f1(py)+'" width="'+f1(Math.max(1.1, r * .09))+'" height="'+f1(Math.max(1.1, r * .09))+'" fill="#fff" opacity="'+(.55 + rnd() * .35).toFixed(2)+'" transform="rotate('+Math.round(rnd() * 90)+' '+f1(px)+' '+f1(py)+')"/>';
    k++;
  }
  return s + '</g>';
};

/* Goteo de glaseado colgando entre xr (derecha) y xl (izquierda) desde yb. Devuelve
   el tramo de camino (va de derecha a izquierda) y el centro de la gota. */
function tramoGoteo(xr, xl, yb, L){
  var dw = xr - xl, rr = dw * .42, yt = yb + L - rr * .9;
  return {
    d: 'C'+f1(xr)+' '+f1(yb + L * .3)+' '+f1(xr - dw * .12)+' '+f1(yb + L * .55)+' '+f1(xr - dw * .12)+' '+f1(yt) +
       'A'+f1(rr)+' '+f1(rr)+' 0 1 1 '+f1(xl + dw * .12)+' '+f1(yt) +
       'C'+f1(xl + dw * .12)+' '+f1(yb + L * .55)+' '+f1(xl)+' '+f1(yb + L * .3)+' '+f1(xl)+' '+f1(yb),
    cx: (xr + xl) / 2, cy: yt + rr * .2, r: rr
  };
}
J.glaseado = function(d, op){
  op = op || {};
  var G = J.COL.glaseado;
  if (typeof d === 'string'){
    var g = op.grosor || 10;
    return '<g class="jg-glaseado">' +
      '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="'+f1(g + 6)+'" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="'+d+'" fill="none" stroke="'+G+'" stroke-width="'+f1(g)+'" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="'+d+'" fill="none" stroke="#fff" stroke-width="'+f1(Math.max(1.5, g * .26))+'" stroke-linecap="round" stroke-linejoin="round" opacity=".75" transform="translate('+f1(-g * .1)+' '+f1(-g * .2)+')"/>' +
      '</g>';
  }
  var o = d || {}, x1 = +o.x1 || 0, x2 = o.x2 == null ? 100 : +o.x2, y = +o.y || 0, gr = o.grosor || 16;
  var rnd = HW.azar(o.semilla || 9), sw = o.contorno || 3, prob = o.goteos === false ? 0 : (o.prob == null ? .4 : o.prob);
  var largo = o.largo || [gr * .7, gr * 2.6], yb = y + gr, borde = '', x = x2, gotas = [];
  while (x > x1 + .5){
    var paso = Math.min(x - x1, gr * 1.3 + rnd() * gr * 1.5);
    if (paso > gr * 1.1 && rnd() < prob){
      var dw = Math.min(paso * .78, gr * .75 + rnd() * gr * .45), m = (paso - dw) / 2, L = largo[0] + rnd() * (largo[1] - largo[0]);
      var xr = x - m, xl = xr - dw, t = tramoGoteo(xr, xl, yb, L);
      borde += 'Q'+f1(x - m / 2)+' '+f1(yb + gr * .12)+' '+f1(xr)+' '+f1(yb) + t.d + 'Q'+f1(xl - m / 2)+' '+f1(yb + gr * .12)+' '+f1(x - paso)+' '+f1(yb);
      gotas.push(t);
    } else {
      borde += 'Q'+f1(x - paso / 2)+' '+f1(yb + gr * (.3 + rnd() * .25))+' '+f1(x - paso)+' '+f1(yb);
    }
    x -= paso;
  }
  var s = '<g class="jg-glaseado"><path d="M'+f1(x1)+' '+f1(y)+'H'+f1(x2)+'V'+f1(yb)+borde+'Z" fill="'+G+'" stroke="'+TINTA+'" stroke-width="'+sw+'" stroke-linejoin="round"/>' +
    '<path d="M'+f1(x1 + 8)+' '+f1(y + gr * .32)+'H'+f1(x2 - 8)+'" stroke="#fff" stroke-width="'+f1(Math.max(1.5, gr * .16))+'" stroke-linecap="round" opacity=".7"/>' +
    '<path d="M'+f1(x1 + 4)+' '+f1(yb - gr * .12)+'H'+f1(x2 - 4)+'" stroke="'+J.COL.glaseadoSombra+'" stroke-width="'+f1(Math.max(1.5, gr * .14))+'" stroke-linecap="round" opacity=".8"/>';
  gotas.forEach(function(t){ s += circ(t.cx - t.r * .3, t.cy - t.r * .3, Math.max(1.2, t.r * .28), '#fff', ' opacity=".8"'); });
  return s + '</g>';
};
/* Gotas sueltas colgando (en vertical) de la recta (xa,ya)-(xb,yb): n gotas.
   Se dibujan ANTES del trazo de glaseado que las tapa arriba. */
function gotasEnRecta(xa, ya, xb, yb, n, largo, ancho, rnd){
  var s = '';
  for (var i = 0; i < n; i++){
    var t = (i + .5 + (rnd() - .5) * .5) / n, x = xa + (xb - xa) * t, y = ya + (yb - ya) * t;
    var w = ancho * (.8 + rnd() * .45), L = largo[0] + rnd() * (largo[1] - largo[0]), g = tramoGoteo(x + w / 2, x - w / 2, y, L);
    s += '<path d="M'+f1(x + w / 2)+' '+f1(y - 6)+'V'+f1(y)+g.d+'V'+f1(y - 6)+'Z" fill="'+J.COL.glaseado+'" stroke="'+TINTA+'" stroke-width="2.6" stroke-linejoin="round"/>' +
      circ(g.cx - g.r * .3, g.cy - g.r * .3, Math.max(1, g.r * .28), '#fff', ' opacity=".8"');
  }
  return s;
}
J.gotas = gotasEnRecta;

J.hueco = function(w, h){
  var r = w / 2, k = Math.min(h * .42, r * .92);
  return { d:'M'+f1(-r)+' 0V'+f1(-h + k)+'A'+f1(r)+' '+f1(k)+' 0 0 1 '+f1(r)+' '+f1(-h + k)+'V0Z', r:r, k:k };
};
J.ventana = function(op){
  op = op || {};
  var w = op.w || 70, h = op.h || 84, p = prefijo(op), H = J.hueco(w, h), r = H.r, yT = -h + H.k;
  var fw = Math.max(5, Math.min(26, w * .075)), sw = w > 220 ? 4 : w > 90 ? 3 : 2.4, transp = op.hueco === true;
  var cv = J.COL.caramelo, G = J.COL.glaseado, rnd = HW.azar(HW.hash(p + w + 'x' + h));
  var s = '<g class="jg-ventana"><defs><clipPath id="'+p+'-vh"><path d="'+H.d+'"/></clipPath>' +
    '<radialGradient id="'+p+'-vl" cx=".5" cy=".62" r=".72"><stop offset="0" stop-color="#fff3c8"/><stop offset=".5" stop-color="#ffc861"/><stop offset="1" stop-color="#e2803a"/></radialGradient>' +
    '<linearGradient id="'+p+'-vo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d2b4f"/><stop offset="1" stop-color="#22192f"/></linearGradient>' +
    '<radialGradient id="'+p+'-vg"><stop offset="0" stop-color="#ffcf6b" stop-opacity=".75"/><stop offset=".45" stop-color="#ffb547" stop-opacity=".28"/><stop offset="1" stop-color="#ffb547" stop-opacity="0"/></radialGradient></defs>';
  /* resplandor hacia fuera (solo con luz y sin hueco: ventana vista desde fuera) */
  if (op.luz && !transp) s += '<g opacity=".7"><ellipse class="jg-luz" cx="0" cy="'+f1(-h * .48)+'" rx="'+f1(w * 1.15)+'" ry="'+f1(h * .95)+'" fill="url(#'+p+'-vg)"/></g>';
  if (!transp) s += '<path d="'+H.d+'" fill="url(#'+p+(op.luz ? '-vl' : '-vo')+')"/>';
  /* vitral de caramelo: 4 paños (arco izq/der, abajo izq/der) */
  var opa = transp ? .5 : op.luz ? .78 : 1;
  var panos = [[-r, -h, r, yT + h], [0, -h, r, yT + h], [-r, yT, r, -yT], [0, yT, r, -yT]];   /* [x, y, ancho, alto] */
  s += '<g clip-path="url(#'+p+'-vh)">';
  panos.forEach(function(q, i){
    var c = cv[i % cv.length];
    s += '<rect x="'+f1(q[0])+'" y="'+f1(q[1])+'" width="'+f1(q[2])+'" height="'+f1(q[3])+'" fill="'+c[0]+'" opacity="'+(c[1] * opa).toFixed(2)+'"/>';
    /* vetas claras del caramelo y burbujitas */
    var x0 = q[0], y0 = q[1], pw = q[2], ph = q[3];
    s += '<path d="M'+f1(x0 + pw * .18)+' '+f1(y0 + ph * .8)+'L'+f1(x0 + pw * .62)+' '+f1(y0 + ph * .16)+'" stroke="#fff" stroke-width="'+f1(Math.max(2, w * .03))+'" stroke-linecap="round" opacity=".32"/>' +
      '<path d="M'+f1(x0 + pw * .42)+' '+f1(y0 + ph * .86)+'L'+f1(x0 + pw * .7)+' '+f1(y0 + ph * .46)+'" stroke="#fff" stroke-width="'+f1(Math.max(1.2, w * .012))+'" stroke-linecap="round" opacity=".3"/>';
    for (var b = 0; b < (w > 200 ? 5 : 2); b++){
      s += circ(x0 + pw * (.15 + rnd() * .7), y0 + ph * (.15 + rnd() * .7), Math.max(1, w * (.006 + rnd() * .01)), '#fff', ' opacity=".35"');
    }
  });
  /* borde interior más oscuro: da grosor al caramelo */
  s += '<path d="'+H.d+'" fill="none" stroke="#9a3f1c" stroke-width="'+f1(fw * 1.3)+'" opacity=".28"/></g>';
  /* cruz de glaseado */
  var cw = Math.max(3.5, fw * .62), cruz = 'M0 '+f1(-h)+'V0M'+f1(-r)+' '+f1(yT)+'H'+f1(r);
  s += '<path d="'+cruz+'" stroke="'+TINTA+'" stroke-width="'+f1(cw + sw * 2)+'"/><path d="'+cruz+'" stroke="'+G+'" stroke-width="'+f1(cw)+'"/>' +
    '<path d="M'+f1(-cw * .18)+' '+f1(-h + fw)+'V'+f1(yT - cw)+'M'+f1(-cw * .18)+' '+f1(yT + cw)+'V'+f1(-fw)+'" stroke="#fff" stroke-width="'+f1(Math.max(1, cw * .22))+'" stroke-linecap="round" opacity=".7"/>' +
    circ(0, yT, cw * .85, G, ' stroke="'+TINTA+'" stroke-width="'+sw+'"');
  /* marco de glaseado con perlitas de colores */
  s += '<path d="'+H.d+'" fill="none" stroke="'+TINTA+'" stroke-width="'+f1(fw + sw * 2)+'" stroke-linejoin="round"/>' +
    '<path d="'+H.d+'" fill="none" stroke="'+G+'" stroke-width="'+f1(fw)+'" stroke-linejoin="round"/>';
  var perlas = [C.rojo, C.verde, J.COL.gomitas.amarillo], np = Math.max(4, Math.round(w / 26));
  for (var i = 1; i < np; i++){
    var a = Math.PI + Math.PI * i / np, px = r * Math.cos(a), py = yT + H.k * Math.sin(a);
    s += circ(px, py, Math.max(1.3, fw * .17), perlas[i % 3], ' stroke="'+TINTA+'" stroke-width="'+(w > 220 ? 1.6 : 1)+'"');
  }
  for (var j = 1; j <= Math.max(1, Math.round((h - H.k) / (w * .2))); j++){
    var yy = yT + (h - H.k) * j / (Math.round((h - H.k) / (w * .2)) + 1);
    [-r, r].forEach(function(xx, ii){ s += circ(xx, yy, Math.max(1.3, fw * .17), perlas[(j + ii) % 3], ' stroke="'+TINTA+'" stroke-width="'+(w > 220 ? 1.6 : 1)+'"'); });
  }
  /* alféizar de galleta con glaseado que gotea */
  var aw = r + fw * 1.3, ah = Math.max(6, fw * 1.05);
  s += '<rect x="'+f1(-aw)+'" y="'+f1(-fw * .2)+'" width="'+f1(aw * 2)+'" height="'+f1(ah + fw * .2)+'" rx="'+f1(ah * .4)+'" fill="'+J.COL.galleta+'" stroke="'+TINTA+'" stroke-width="'+sw+'"/>' +
    '<path d="M'+f1(-aw + ah * .4)+' '+f1(ah * .78)+'H'+f1(aw - ah * .4)+'" stroke="'+J.COL.galletaOsc+'" stroke-width="'+f1(Math.max(1.5, ah * .18))+'" stroke-linecap="round" opacity=".7"/>';
  s += J.glaseado({ x1: -aw - fw * .15, x2: aw + fw * .15, y: -fw * .45, grosor: Math.max(4, fw * .5), prob: .5, largo: [fw * .35, fw * 1.2], contorno: w > 220 ? 3.5 : w > 90 ? 2.6 : 2, semilla: HW.hash(p) % 997 + 1 });
  /* gomita en lo alto del arco */
  s += J.gomita('rojo', { x: 0, y: -h - fw * .28, r: Math.max(4.5, fw * .82) });
  return s + '</g>';
};

J.casa = function(op){
  op = op || {};
  var p = prefijo(op), K = J.COL, G = K.glaseado, rnd = HW.azar(op.semilla || 21), out = [];
  function pon(capa, t){ out.push([capa, t]); }
  var Ax = 0, Ay = -352, Lx = -188, Ly = -188, t = 50;
  var fachada = 'M-150 0H150V-190L0-306L-150-190Z';
  var losa = function(sg){ return 'M0 '+Ay+'L'+(sg * -Lx)+' '+Ly+'L'+(sg * -Lx)+' '+(Ly + t)+'L0 '+(Ay + t)+'Z'; };
  pon('defs', '<defs><clipPath id="'+p+'-fa"><path d="'+fachada+'"/></clipPath>' +
    '<clipPath id="'+p+'-li"><path d="'+losa(-1)+'"/></clipPath><clipPath id="'+p+'-ld"><path d="'+losa(1)+'"/></clipPath></defs>');
  pon('sombra', '<ellipse cx="0" cy="3" rx="205" ry="13" fill="'+TINTA+'" opacity=".22"/>');
  /* chimenea (detrás del tejado) y humo */
  if (op.humo){
    [[0, 22], [-2.1, 30], [-4.2, 16]].forEach(function(h, i){
      pon('humo', '<circle class="hw-humo" cx="'+(100 + i * 4)+'" cy="-366" r="'+[14, 18, 12][i]+'" fill="#f4eee6" style="--hx:'+h[1]+'px;animation-delay:'+h[0]+'s"/>');
    });
  }
  pon('paredes', '<rect x="80" y="-336" width="44" height="104" rx="4" fill="'+K.galletaOsc+'"'+TRAZO+'/>');
  pon('chimenea', '<path d="M80-318H124M80-300H124M80-282H124M102-336V-318M92-318V-300M112-318V-300M102-300V-282" stroke="'+K.glaseadoSombra+'" stroke-width="2.4" opacity=".85"/>' +
    gotasEnRecta(78, -334, 126, -334, 3, [6, 14], 7, rnd) +
    '<rect x="72" y="-348" width="60" height="16" rx="7" fill="'+G+'"'+TRAZO+'/>' +
    '<path d="M78-344H120" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>');
  /* fachada de galleta: borde tostado y puntitos */
  var s = '<path d="'+fachada+'" fill="'+K.galleta+'"/><g clip-path="url(#'+p+'-fa)">' +
    '<path d="'+fachada+'" fill="none" stroke="'+K.galletaOsc+'" stroke-width="16" opacity=".45"/>' +
    '<rect x="-150" y="-330" width="300" height="38" fill="'+K.galletaOsc+'" opacity=".25"/>';
  for (var i = 0; i < 30; i++){
    var px = -140 + rnd() * 280, py = -300 + rnd() * 292;
    s += '<ellipse cx="'+f1(px)+'" cy="'+f1(py)+'" rx="'+f1(1.4 + rnd() * 2)+'" ry="'+f1(1 + rnd() * 1.4)+'" fill="'+K.tostado+'" opacity=".38"/>';
  }
  pon('paredes', s + '</g><path d="'+fachada+'" fill="none"'+TRAZO+'/>');
  pon('copo', '<g transform="translate(0 -246) scale(2.1)">' + A.copo(1) + '</g>');
  /* ventanas: LAS MISMAS del interior */
  if (op.partes) [-92, 92].forEach(function(x){ pon('hueco', '<path transform="translate('+x+' -80)" d="'+J.hueco(60, 72).d+'" fill="'+K.tostado+'"'+TRAZO+'/>'); });
  pon('ventana', '<g transform="translate(-92 -80)">' + J.ventana({ w:60, h:72, luz:op.luz, id:p+'-v1' }) + '</g>');
  pon('ventana', '<g transform="translate(92 -80)">' + J.ventana({ w:60, h:72, luz:op.luz, id:p+'-v2' }) + '</g>');
  /* puerta en arco de chocolate con gomitas */
  var puerta = 'M-34 0V-84A34 34 0 0 1 34-84V0';
  pon('paredes', '<path d="'+puerta+'Z" fill="'+K.chocolate+'"'+TRAZO+'/>' +
    '<path d="M-12-6V-100M12-6V-100" stroke="'+K.chocolateOsc+'" stroke-width="3" stroke-linecap="round" opacity=".8"/>' +
    '<path d="M-24-12V-80" stroke="#fff" stroke-width="2.6" stroke-linecap="round" opacity=".18"/>');
  pon('puerta', J.glaseado(puerta, { grosor:7 }) +
    circ(20, -46, 4.4, C.dorado, ' stroke="'+TINTA+'" stroke-width="2"'));
  pon('dulce', '<g transform="translate(0 -88) scale(.5)">' + A.acebo() + '</g>');
  pon('puerta', '<rect x="-46" y="-7" width="92" height="10" rx="5" fill="'+G+'"'+TRAZO+'/>');
  [200, 235, 270, 305, 340].forEach(function(g, i){
    var a = g * Math.PI / 180;
    pon('dulce', J.gomita(J.GOMITAS[i % 5], { x: 41 * Math.cos(a), y: -84 + 41 * Math.sin(a) + 5, r: 6.5 }));
  });
  /* tejado: losas de galleta con tejas de glaseado */
  [-1, 1].forEach(function(sg){
    var d = losa(sg), ex = sg * -Lx, ux = ex / Math.hypot(ex, Ly - Ay), uy = (Ly - Ay) / Math.hypot(ex, Ly - Ay);
    var nx = -uy * sg, ny = ux * sg; if (ny < 0){ nx = -nx; ny = -ny; }
    var clip = '<g clip-path="url(#'+p+(sg < 0 ? '-li' : '-ld')+')">', tejas = '';
    var losaBase = '<path d="'+d+'" fill="'+K.galleta+'"/>' + clip + '<path d="'+d+'" fill="none" stroke="'+K.galletaOsc+'" stroke-width="10" opacity=".4"/>';
    var largo = Math.hypot(ex, Ly - Ay), c = 22;
    [[t * .16, 0], [t * .44, c / 2], [t * .72, 0], [t, c / 2]].forEach(function(fila){
      for (var k = -1; k * c < largo + c; k++){
        var x0 = ux * (k * c + fila[1]), y0 = Ay + fila[0] + uy * (k * c + fila[1]), x1 = x0 + ux * c, y1 = y0 + uy * c;
        tejas += '<path d="M'+f1(x0)+' '+f1(y0)+'Q'+f1((x0 + x1) / 2 + nx * c * .5)+' '+f1((y0 + y1) / 2 + ny * c * .5)+' '+f1(x1)+' '+f1(y1)+'" fill="none" stroke="'+G+'" stroke-width="3.2" stroke-linecap="round"/>';
      }
    });
    var borde = '<path d="'+d+'" fill="none"'+TRAZO+'/>';
    if (op.partes){ pon('techo', losaBase + '</g>' + borde); pon('tejas', clip + tejas + '</g>' + borde); }
    else pon('techo', losaBase + tejas + '</g>' + borde);
    pon('alero', gotasEnRecta(0, Ay + t, ex, Ly + t, 6, [6, 20], 9, rnd) + J.glaseado('M0 '+(Ay + t)+'L'+f1(ex)+' '+(Ly + t), { grosor:6 }));
  });
  /* nieve o glaseado encima del tejado */
  var cumbre = 'M-196 '+(Ly + 6)+'L0 '+(Ay - 4)+'L196 '+(Ly + 6);
  if (op.nieve){
    pon('cumbre', gotasEnRecta(-190, Ly + 8, -4, Ay + 4, 5, [8, 22], 11, rnd) + gotasEnRecta(4, Ay + 4, 190, Ly + 8, 5, [8, 22], 11, rnd) + J.glaseado(cumbre, { grosor:18 }) +
      '<ellipse cx="-118" cy="-1" rx="46" ry="9" fill="'+G+'"'+TRAZO+'/><ellipse cx="128" cy="-1" rx="38" ry="8" fill="'+G+'"'+TRAZO+'/>');
  } else pon('cumbre', J.glaseado(cumbre, { grosor:8 }));
  [.32, .66].forEach(function(tt, i){
    [-1, 1].forEach(function(sg){
      pon('dulce', J.gomita(J.GOMITAS[(i * 2 + (sg > 0 ? 1 : 0) + 2) % 5], { x: sg * 188 * tt, y: Ay - 4 + (Ly - Ay + 10) * tt - (op.nieve ? 6 : 2), r: 9 }));
    });
  });
  pon('estrella', '<g transform="translate(0 '+(Ay - 16)+')">' + A.estrella({ r:14 }) + '</g>');
  /* bastones de caramelo en las esquinas y gomitas abajo */
  pon('dulce', '<g transform="translate(-160 -142) scale(1.75)">' + A.baston() + '</g>');
  pon('dulce', '<g transform="translate(160 -142) scale(-1.75 1.75)">' + A.baston() + '</g>');
  [58, 84, 110, 136].forEach(function(x, i){
    pon('dulce', J.gomita(J.GOMITAS[(i + 1) % 5], { x: -x, y: 1, r: 8.5 }));
    pon('dulce', J.gomita(J.GOMITAS[(i + 3) % 5], { x: x, y: 1, r: 8.5 }));
  });
  if (op.partes) return out;
  return '<g class="jg-casa">' + out.map(function(o){ return o[1]; }).join('') + '</g>';
};

/* ── La Sra. Claus (HW.arte.sraClaus) ────────────────────────────
   Misma caja, contorno, ojos y proporciones que la Mascota: 240×280, pies en y = 272,
   ojos en y = 98 (x = 104 y 136), boca en (120, 118). Vestido rojo, delantal, chongo y lentes.
   Viene por piezas para animarla (cada pieza va en su propio div, ver «Fondo: Cocina de Navidad»):
   · PIV: pivotes. L1, L2: largo del brazo y del antebrazo (mano incluida).
   · vestido(), cabezaAtras(), rasgos(), ojos(), cabezaFrente(): en la caja 240×280.
     rasgos() y ojos() traen todas las caras superpuestas (.bo-n .bo-f .bo-o .bo-c y .oj-n .oj-f .oj-c .oj-s).
   · pie(lado), brazo(), antebrazo(lado), guante(lado): con el pivote en 0,0 (el miembro cuelga hacia y +). */
A.sraClaus = function(){
  var PIEL = '#ffd9c4', NIEVE = C.nieve, SOMBRA = '#dfe7f3', ROJO = C.rojo, OSC = C.rojoOsc, BOCA = '#7a2638', LENGUA = '#ff8fa3', ORO = C.doradoOsc, TELA = '#fff8ea', S = TRAZO;
  var S25 = ' stroke="'+TINTA+'" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"', S2 = ' stroke="'+TINTA+'" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"';
  function rama(d, color, w){
    return '<path d="'+d+'" fill="none" stroke="'+TINTA+'" stroke-width="'+(w + 3.5)+'" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="'+d+'" fill="none" stroke="'+color+'" stroke-width="'+w+'" stroke-linecap="round" stroke-linejoin="round"/>';
  }
  function luz(d, w, op){ return '<path d="'+d+'" fill="none" stroke="#fff" stroke-width="'+(w || 3.5)+'" stroke-linecap="round" opacity="'+(op || .38)+'"/>'; }
  function trazo(d, w, col){ return '<path d="'+d+'" fill="none" stroke="'+(col || TINTA)+'" stroke-width="'+(w || 3.6)+'" stroke-linecap="round" stroke-linejoin="round"/>'; }
  function ambos(s){ return s + '<g transform="matrix(-1 0 0 1 240 0)">' + s + '</g>'; }
  /* Volantes del delantal: arcos entre dos puntos sobre la curva y = f(x) */
  function volante(x0, x1, n, yf, alto){
    var d = '', paso = (x1 - x0) / n;
    for (var i = 0; i < n; i++){ var a = x0 + paso * i, b = a + paso; d += (i ? '' : 'M'+f1(a)+' '+f1(yf(a))) + 'Q'+f1((a + b) / 2)+' '+f1((yf(a) + yf(b)) / 2 + alto)+' '+f1(b)+' '+f1(yf(b)); }
    return d;
  }
  return {
    PIV: { hombroI:[85, 153], hombroD:[155, 153], cuello:[120, 132], cadera:[120, 240], pieI:[103, 242], pieD:[137, 242], ojos:[120, 98] },
    L1: 33, L2: 40,
    vestido: function(){
      var curva = function(x){ return 251 + 9 * (1 - Math.pow((x - 120) / 52, 2)); };
      var s = '<path d="M93 133Q120 125 147 133Q164 142 169 176Q175 226 185 248Q188 257 176 260Q120 271 64 260Q52 257 55 248Q65 226 71 176Q76 142 93 133Z" fill="'+ROJO+'"'+S+'/>' +
        '<path d="M152 146Q165 192 176 250" fill="none" stroke="'+OSC+'" stroke-width="7" stroke-linecap="round" opacity=".32"/>' +
        luz('M77 176Q79 156 90 144', 4.2, .3);
      /* ribete blanco de abajo */
      s += '<path d="M55 247Q120 266 185 247L186 254Q187 259 176 261Q120 272 64 261Q53 259 54 254Z" fill="'+NIEVE+'"'+S+'/>' +
        '<path d="M70 257q4 2.5 8 1M96 262q4 2 8 .6M136 262.6q4 1 8-.6M162 258.6q4 1 8-1.4" fill="none" stroke="'+SOMBRA+'" stroke-width="2.4" stroke-linecap="round"/>';
      /* falda del delantal con volante y bolsillo */
      s += '<path d="M85 187Q120 197 155 187Q163 222 172 251Q120 269 68 251Q77 222 85 187Z" fill="'+TELA+'"'+S25+'/>' +
        '<path d="M150 198Q157 226 164 248" fill="none" stroke="#ecdcc4" stroke-width="5" stroke-linecap="round" opacity=".8"/>' +
        '<path d="'+volante(68, 172, 8, curva, 7)+'" fill="'+NIEVE+'"'+S25+'/>' +
        '<path d="M97 214H143V232Q143 240 135 240H105Q97 240 97 232Z" fill="#fffdf6"'+S25+'/><path d="M97 220H143" fill="none" stroke="'+ROJO+'" stroke-width="3"/>' +
        '<g transform="translate(120 230) scale(.38)">' + A.acebo() + '</g>';
      /* peto, tirantes con volante y cinta de la cintura */
      s += ambos(rama('M103 150L96 134', NIEVE, 6)) +
        '<path d="M99 150Q120 156 141 150L153 190Q120 200 87 190Z" fill="'+TELA+'"'+S25+'/>' +
        '<path d="M99 150Q120 156 141 150" fill="none" stroke="'+ROJO+'" stroke-width="3.4" stroke-linecap="round"/>' +
        '<path d="M120 164C114 158 106 162 109 169C111 174 117 177 120 180C123 177 129 174 131 169C134 162 126 158 120 164Z" fill="'+ROJO+'"'+S2+'/>' + luz('M112 166q1-3 4-3.4', 2, .7) +
        '<path d="M84 186Q120 197 156 186L158 195Q120 207 82 195Z" fill="'+OSC+'"'+S25+'/>';
      /* cuello de encaje */
      s += '<path d="M92 133Q104 146 120 146Q136 146 148 133Q138 124 120 124Q102 124 92 133Z" fill="'+NIEVE+'"'+S25+'/>' +
        '<path d="M100 137q4 3 8 2.6M132 139.6q4 .4 8-2.6" fill="none" stroke="'+SOMBRA+'" stroke-width="2.2" stroke-linecap="round"/>';
      return s;
    },
    cabezaAtras: function(){
      var chongo = '<circle cx="120" cy="40" r="23" fill="'+NIEVE+'"'+S+'/>' +
        '<path d="M106 34Q116 22 132 30Q126 36 116 38M108 48Q120 54 134 44" fill="none" stroke="'+SOMBRA+'" stroke-width="3" stroke-linecap="round"/>' + luz('M104 30q5-9 15-10', 3.2, .8);
      var cinta = '<path d="M97 60Q120 50 143 60L141 69Q120 59 99 69Z" fill="'+ROJO+'"'+S25+'/>';
      return chongo + cinta +
        ambos('<circle cx="81" cy="108" r="12" fill="'+NIEVE+'"'+S+'/><circle cx="79" cy="90" r="11.5" fill="'+NIEVE+'"'+S+'/>') +
        '<circle cx="120" cy="92" r="42" fill="'+PIEL+'"'+S+'/>' + ambos('<circle cx="76.6" cy="121" r="3.8" fill="'+ORO+'"'+S2+'/>');
    },
    rasgos: function(){
      var ab = function(d, lengua){ return '<path d="'+d+'" fill="'+BOCA+'" stroke="'+TINTA+'" stroke-width="2.8" stroke-linejoin="round"/>' + (lengua || ''); };
      return '<ellipse cx="89" cy="113" rx="9" ry="5.4" fill="#ff8fab" opacity=".62"/><ellipse cx="151" cy="113" rx="9" ry="5.4" fill="#ff8fab" opacity=".62"/>' +
        '<ellipse cx="120" cy="108.5" rx="4.8" ry="3.8" fill="#f7b1a2"/>' +
        '<g class="bo bo-n">' + trazo('M110 117q10 8.5 20 0', 3.4) + '</g>' +
        '<g class="bo bo-f">' + ab('M107.5 114Q120 117.5 132.5 114Q131.5 132 120 132Q108.5 132 107.5 114Z', '<path d="M113 127.5Q120 122 127 127.5Q124 131 120 131Q116 131 113 127.5Z" fill="'+LENGUA+'"/>') + '</g>' +
        '<g class="bo bo-o">' + ab('M120 115C124.6 115 126.4 119 126.4 122C126.4 126 124 128 120 128C116 128 113.6 126 113.6 122C113.6 119 115.4 115 120 115Z') + '</g>' +
        '<g class="bo bo-c">' + trazo('M112 119q4-3.6 8 0t8 0', 3.2) + '</g>';
    },
    ojos: function(){
      var n = function(x){ return '<ellipse cx="'+x+'" cy="98" rx="6.6" ry="8.4" fill="'+TINTA+'"/>' + circ(x + 2.5, 94.6, 2.7, '#fff') + circ(x - 2.3, 101.8, 1.2, '#fff', ' opacity=".85"'); };
      var f = function(x){ return 'M'+(x - 7.6)+' 101q7.6-10.4 15.2 0'; }, c = function(x){ return 'M'+(x - 7.6)+' 97q7.6 7 15.2 0'; };
      var o = function(x){ return circ(x, 97.6, 8.6, '#fff', S25) + circ(x, 98.4, 3.6, TINTA) + circ(x + 1.2, 97, 1, '#fff'); };
      return '<g class="oj oj-n">' + n(104) + n(136) + '</g><g class="oj oj-f">' + trazo(f(104) + f(136), 3.8) + '</g>' +
        '<g class="oj oj-c">' + trazo(c(104) + c(136), 3.4) + '</g><g class="oj oj-s">' + o(104) + o(136) + '</g>';
    },
    cabezaFrente: function(){
      /* lentes redondos dorados + mechón partido al medio */
      var lente = '<circle cx="104" cy="98" r="14" fill="#dff3ff" fill-opacity=".2" stroke="'+TINTA+'" stroke-width="4.4"/><circle cx="104" cy="98" r="14" fill="none" stroke="'+ORO+'" stroke-width="2.4"/>' +
        '<path d="M95 92q2.4-4 6.6-5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".75"/>' + trazo('M90 95L81 91', 4, TINTA) + trazo('M90 95L81 91', 2, ORO);
      return ambos(lente) + trazo('M117.6 96Q120 93 122.4 96', 4.2, TINTA) + trazo('M117.6 96Q120 93 122.4 96', 2.2, ORO);
    },
    pelo: function(){
      return '<path d="M120 60Q100 64 89 80Q83 89 78.6 100Q70 62 98 51Q120 43 142 51Q170 62 161.4 100Q157 89 151 80Q140 64 120 60Z" fill="'+NIEVE+'"'+S+'/>' +
        '<path d="M120 60V50" fill="none" stroke="'+SOMBRA+'" stroke-width="2.6" stroke-linecap="round"/>' +
        '<path d="M86 84Q92 68 110 60M154 84Q148 68 130 60" fill="none" stroke="'+SOMBRA+'" stroke-width="3" stroke-linecap="round"/>' + luz('M84 72Q90 58 104 53', 3.2, .85);
    },
    pie: function(lado){
      var k = lado === 'i' ? 1 : -1;
      return rama('M0 0V19', '#f4e6d8', 11) +
        '<g transform="scale('+k+' 1)"><path d="M-9 17H9V25Q9 30 4 30H-14Q-19 30-19 25Q-19 20-12 19Z" fill="#6b3a2a"'+S+'/>' + luz('M-14 25q2-3 6-3.4', 2.4, .35) + '</g>';
    },
    brazo: function(){ return rama('M0 0V33', ROJO, 21) + luz('M-5.4 4V24', 3, .28); },
    antebrazo: function(lado){
      var k = lado === 'i' ? 1 : -1;
      return rama('M0 0V21', ROJO, 19) + circ(0, 0, 10, ROJO) + rama('M-4 25H4', NIEVE, 12) +
        '<g transform="scale('+k+' 1)">' + circ(7.6, 32, 4.6, PIEL, S25) + circ(0, 37, 10.4, PIEL, S) + luz('M-5.4 33.6q1.5-3.4 5-3.8', 2.2, .6) + '</g>';
    },
    guante: function(lado){
      var k = lado === 'i' ? 1 : -1, col = '#e9a23b';
      return '<g transform="scale('+k+' 1)"><path d="M-12 22H12V38Q12 50 0 50Q-12 50-12 38Z" fill="'+col+'"'+S+'/>' +
        circ(11, 34, 6, col, S25) + '<path d="M-9 28L7 44M-3 24L11 36M-11 38L0 48M9 26L-8 44" fill="none" stroke="#fff" stroke-width="1.8" opacity=".35"/>' +
        '<rect x="-14" y="18" width="28" height="9" rx="4" fill="'+NIEVE+'"'+S25+'/></g>';
    }
  };
};

/* ── Árbol de Navidad (HW.arte.arbol) ────────────────────────────
   El MISMO dibujo en el overlay «Árbol de Navidad» y en el «Fondo: Casa de jengibre».
   Suelo en y = 0, punta en y ≈ -654, ancho ±210 con los regalos. El tronco se ve entre la falda y el primer piso.
   op = { paleta:[colores], parpadeo:'suave'|'secuencia'|'ninguno', nieve, adornos:'variados'|'color'|'ninguno',
          colorAdornos, tinte, regalos:0-5, espejo:1|-1, id, semilla, quieto }
   Devuelve { svg, defs, bolas:[{x, y, esc, deco}], regalos:[{r, x, y, deco}], luces:[{x, y, c}], estrella:{x, y}, colgante }
   · svg va envuelto por quien lo usa; defs va dentro de un <defs> del mismo <svg>.
   · quieto:true = sin nada animado dentro del SVG (los fondos ponen el brillo aparte, en sus propios divs,
     usando luces y estrella). Las clases .mece, .halo y .estrella-late las define el overlay.
   · tinte = color de la decoración de un fondo: pinta bolas, falda y regalos rojos. Sin tinte, los de fábrica. */
A.arbol = function(op){
  op = op || {};
  var id = op.id || 'arb', quieto = !!op.quieto, parpadeo = quieto ? 'ninguno' : (op.parpadeo || 'suave');
  var cols = op.paleta || HW.PALETAS.clasica, rnd = HW.azar(op.semilla || 11), T = TINTA, TR = TRAZO;
  var VERDE = '#2f8f5b', VERDE_OSC = HW.mezcla(VERDE, T, .35), VERDE_CLARO = '#5fc28a';
  /* Pisos del árbol, de abajo arriba: [y de abajo, y de la punta, ancho, ondas] (unidades del dibujo, suelo en y = 0) */
  var PISOS = [[-92, -296, 374, 5], [-212, -408, 300, 4], [-322, -506, 224, 4], [-426, -592, 148, 3]];
  /* Piso: borde de abajo en ondas y lados un poco cóncavos hasta la punta redondeada */
  function piso(yb, yt, w, n){
    var x = -w / 2, paso = w / n, h = yb - yt, d = 'M'+f1(x)+' '+f1(yb);
    for (var i = 0; i < n; i++) d += 'Q'+f1(x + paso * (i + .5))+' '+f1(yb + 18)+' '+f1(x + paso * (i + 1))+' '+f1(yb);
    return d + 'Q'+f1(w * .17)+' '+f1(yt + h * .5)+' 7 '+f1(yt + 7)+'Q0 '+f1(yt - 4)+' -7 '+f1(yt + 7)+'Q'+f1(-w * .17)+' '+f1(yt + h * .5)+' '+f1(x)+' '+f1(yb)+'Z';
  }
  /* Halo de cada color de luz */
  var defs = '';
  cols.forEach(function(c, i){
    defs += '<radialGradient id="'+id+'-g'+i+'"><stop offset="0" stop-color="'+c+'" stop-opacity=".95"/><stop offset=".35" stop-color="'+c+'" stop-opacity=".45"/><stop offset="1" stop-color="'+c+'" stop-opacity="0"/></radialGradient>';
  });
  defs += '<radialGradient id="'+id+'-est"><stop offset="0" stop-color="#fff1b8" stop-opacity=".95"/><stop offset=".4" stop-color="#ffcf5c" stop-opacity=".45"/><stop offset="1" stop-color="#ffcf5c" stop-opacity="0"/></radialGradient>';
  PISOS.forEach(function(p, i){ defs += '<clipPath id="'+id+'-c'+i+'"><path d="'+piso(p[0], p[1], p[2], p[3])+'"/></clipPath>'; });

  /* Colores de las bolas */
  var TINTE = op.tinte || '', ROJO = TINTE || C.rojo;
  var BOLAS = op.adornos === 'color' ? [op.colorAdornos] : TINTE ? [TINTE, C.dorado, HW.mezcla(TINTE, '#ffffff', .4), TINTE, '#e9ecf7', HW.mezcla(TINTE, T, .22)] : [C.rojo, C.dorado, '#4fb3ff', '#ff7fc8', '#e9ecf7', C.verdeClaro];
  var nb = 0, kk = 0, bolas = [], regalos = [], luces = [];
  /* Un foco del árbol colgando del cable en (x, y) */
  function luz(x, y, ang){
    var ci = kk % cols.length, anim = '', animFoco = null, k = kk++;
    if (parpadeo === 'suave'){
      var st = 'animation-duration:'+(2.2 + rnd() * 2.8).toFixed(2)+'s;animation-delay:'+(-rnd() * 5).toFixed(2)+'s';
      anim = ' class="hw-luz" style="'+st+'"'; animFoco = { clase:'hw-encendido', estilo:st };
    } else if (parpadeo === 'secuencia'){
      var st2 = 'animation-delay:'+(-(2 - k % 3) * 0.6).toFixed(1)+'s';
      anim = ' class="hw-sec" style="'+st2+'"'; animFoco = { clase:'hw-sec-foco', estilo:st2 };
    }
    var a = ang * Math.PI / 180;
    luces.push({ x: x - Math.sin(a) * 31 * .62, y: y + Math.cos(a) * 31 * .62, c: cols[ci] });
    return '<g transform="translate('+f1(x)+' '+f1(y)+') rotate('+f1(ang)+') scale(.62)">' +
      (quieto ? '' : '<g style="opacity:.9"><circle cx="0" cy="31" r="44" fill="url(#'+id+'-g'+ci+')"'+anim+'/></g>') + A.foco(cols[ci], animFoco) + '</g>';
  }
  /* Bola colgando de (x, y) que se mece muy poco */
  function colgante(c, esc, azar){
    return (quieto ? '<g>' : '<g class="mece" style="animation-duration:'+(3.2 + azar() * 1.6).toFixed(2)+'s;animation-delay:'+(-azar() * 4).toFixed(2)+'s">') +
      '<line x1="0" y1="-6" x2="0" y2="2" stroke="#e9dcc0" stroke-width="1.6"/><g transform="scale('+esc+')">' + A.bola(c) + '</g></g>';
  }
  /* Cada llamada abre una posición. Con «Sin bolas» queda vacía, pero una donación puede colgar ahí */
  function bola(x, y, esc){
    var i = bolas.length, deco = op.adornos === 'ninguno' ? '' : colgante(BOLAS[nb++ % BOLAS.length], esc, rnd);
    bolas.push({ x: x, y: y, esc: +esc, deco: deco });
    return '<g class="plaza-bola" data-i="'+i+'" transform="translate('+f1(x)+' '+f1(y)+')">' + deco + '</g>';
  }
  /* Ancho (mitad) del piso p a la altura y: se busca en la curva del lado (cuadrática) */
  function lado(p, y){
    var yb = p[0], yt = p[1], w = p[2], h = yb - yt, a = 0, b = 1;
    var Y = function(t){ return (1 - t) * (1 - t) * (yt + 7) + 2 * t * (1 - t) * (yt + h * .5) + t * t * yb; };
    var X = function(t){ return (1 - t) * (1 - t) * 7 + 2 * t * (1 - t) * (w * .17) + t * t * (w / 2); };
    for (var i = 0; i < 22; i++){ var m = (a + b) / 2; if (Y(m) < y) a = m; else b = m; }
    return X((a + b) / 2);
  }
  function bez(a, c, b, t){ return (1 - t) * (1 - t) * a + 2 * t * (1 - t) * c + t * t * b; }

  var s = '';
  /* falda y, encima, el tronco plantado en ella (se ve entre la falda y el primer piso) */
  s += '<ellipse cx="0" cy="-6" rx="196" ry="28" fill="'+C.nieve+'"'+TR+'/>' +
    '<ellipse cx="0" cy="-9" rx="178" ry="21" fill="'+ROJO+'"/>' +
    '<path d="M-150-14Q-60-28 40-24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".3"/>' +
    '<ellipse cx="3" cy="-11" rx="46" ry="9" fill="'+T+'" opacity=".26"/>' +
    '<path d="M-27-122H27L28-20Q34-9 41-8Q20-1 0-1Q-20-1-41-8Q-34-9-28-20Z" fill="'+C.canelaOsc+'"'+TR+'/>' +
    '<path d="M-13-110V-24" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".18"/>' +
    '<path d="M8-108V-66M15-54V-22M-3-46V-16" stroke="'+T+'" stroke-width="2.6" stroke-linecap="round" opacity=".26"/>';
  PISOS.forEach(function(p, i){
    var yb = p[0], yt = p[1], w = p[2], n = p[3], h = yb - yt, hw = w / 2, d = piso(yb, yt, w, n), j;
    /* cuerpo con sombra a la derecha y brillo a la izquierda */
    s += '<path d="'+d+'" fill="'+VERDE+'"/><g clip-path="url(#'+id+'-c'+i+')">' +
      '<path d="M6 '+f1(yt)+'L'+f1(hw + 30)+' '+f1(yb + 30)+'H6Z" fill="'+VERDE_OSC+'" opacity=".5"/>' +
      '<path d="M'+f1(-hw * .45)+' '+f1(yt + h * .7)+'q16 7 30 2M'+f1(hw * .18)+' '+f1(yt + h * .84)+'q16 7 30 2M'+f1(-hw * .1)+' '+f1(yt + h * .5)+'q12 5 22 1" stroke="'+VERDE_OSC+'" stroke-width="3.2" fill="none" stroke-linecap="round" opacity=".7"/></g>' +
      '<path d="M-9 '+f1(yt + 20)+'Q'+f1(-hw * .32)+' '+f1(yt + h * .55)+' '+f1(-hw * .66)+' '+f1(yb - 8)+'" stroke="'+VERDE_CLARO+'" stroke-width="4" fill="none" stroke-linecap="round" opacity=".55"/>' +
      '<path d="'+d+'" fill="none"'+TR+'/>';
    /* nieve: un montoncito en cada punta de rama y un gorro en la punta de arriba */
    if (op.nieve){
      var paso = w / n;
      for (j = 0; j < n; j++){
        var cx = -hw + paso * (j + .5), rx = paso * .3;
        s += '<path d="M'+f1(cx - rx)+' '+f1(yb + 9)+'Q'+f1(cx - rx)+' '+f1(yb - 5)+' '+f1(cx)+' '+f1(yb - 4)+'Q'+f1(cx + rx)+' '+f1(yb - 5)+' '+f1(cx + rx)+' '+f1(yb + 9)+
          'Q'+f1(cx + rx * .4)+' '+f1(yb + 14)+' '+f1(cx)+' '+f1(yb + 11)+'Q'+f1(cx - rx * .4)+' '+f1(yb + 16)+' '+f1(cx - rx)+' '+f1(yb + 9)+'Z" fill="'+C.nieve+'" stroke="'+T+'" stroke-width="2.5" stroke-linejoin="round"/>';
      }
      if (i === PISOS.length - 1){
        var yc = yt + h * .32, mw = lado(p, yc) + 3;
        s += '<path d="M'+f1(-mw)+' '+f1(yc)+'Q'+f1(-mw * .5)+' '+f1(yc + 10)+' 0 '+f1(yc + 2)+'Q'+f1(mw * .5)+' '+f1(yc + 11)+' '+f1(mw)+' '+f1(yc)+
          'L7 '+f1(yt + 7)+'Q0 '+f1(yt - 4)+' -7 '+f1(yt + 7)+'Z" fill="'+C.nieve+'" stroke="'+T+'" stroke-width="2.5" stroke-linejoin="round"/>';
      }
    }
    /* guirnalda de luces enrollada: el cable cruza el piso en diagonal (de arriba a la izquierda a abajo a la derecha) */
    var yl = yt + h * .58, yr = yt + h * .93, xl = -lado(p, yl) + 4, xr = lado(p, yr) - 6, cxm = (xl + xr) / 2, cym = (yl + yr) / 2 + 26;
    var cable = 'M'+f1(xl)+' '+f1(yl)+'Q'+f1(cxm)+' '+f1(cym)+' '+f1(xr)+' '+f1(yr);
    /* bolas detrás del cable (cuelgan de las ramas) */
    var pos = [[-.62, .9, .8], [.4, .6, .74], [.06, .99, .7]].slice(0, i === PISOS.length - 1 ? 2 : 3);
    pos.forEach(function(q){ var y = yt + h * q[1]; s += bola(q[0] * lado(p, y), y, (q[2] - i * .05).toFixed(2)); });
    s += '<path d="'+cable+'" fill="none" stroke="#123524" stroke-width="2.5" transform="translate(0 2)"/><path d="'+cable+'" fill="none" stroke="#1f5a3a" stroke-width="3.5" stroke-linecap="round"/>';
    var k = [6, 5, 4, 3][i];
    for (j = 0; j < k; j++){
      var t = (j + .5) / k, x = bez(xl, cxm, xr, t), y = bez(yl, cym, yr, t);
      var dx = 2 * (1 - t) * (cxm - xl) + 2 * t * (xr - cxm), dy = 2 * (1 - t) * (cym - yl) + 2 * t * (yr - cym);
      s += luz(x, y, Math.atan2(dy, dx) * 180 / Math.PI * .5 + (rnd() - .5) * 24);
    }
  });
  /* estrella de la punta: halo que titila + estrella que late + chispitas */
  var chis = function(x, y, e, d){ return '<g transform="translate('+x+' '+y+') scale('+e+')">' + (quieto ? '<g>' : '<g class="hw-chispa" style="animation-duration:'+(2.6 + d).toFixed(1)+'s;animation-delay:-'+d+'s">') + A.chispa() + '</g></g>'; };
  s += '<g transform="translate(0 -604)">' + (quieto ? '' : '<g class="halo"><circle r="92" fill="url(#'+id+'-est)"/></g>') +
    (quieto ? '<g>' : '<g class="estrella-late">') + A.estrella({ r: 36, cara: true }) + '</g>' +
    chis(-66, -34, .8, .3) + chis(64, -14, .65, 1.4) + chis(-46, 42, .55, 2.1) + chis(50, 50, .5, .9) + '</g>';
  /* regalos: [x, ancho, alto, y, color, lazo] (el orden de dibujo va de atrás adelante) */
  var REGALOS = [
    [-122, 72, 56, 2, ROJO, C.dorado], [104, 58, 72, 0, C.verde, ROJO], [-66, 84, 42, 16, '#4fb3ff', C.nieve],
    [174, 48, 40, 8, C.dorado, ROJO], [-182, 54, 46, 10, '#9b6bd6', C.dorado]
  ];
  var espejo = op.espejo === -1 ? -1 : 1;
  /* Las 5 posiciones existen siempre: las que pasan de «regalos» arrancan vacías y las llenan los subs */
  REGALOS.forEach(function(r, i){
    regalos.push({ r: r, x: r[0] * espejo, y: r[3], deco: i < op.regalos ? A.regalo({ w: r[1], h: r[2], color: r[4], lazo: r[5] }) : '' });
  });
  regalos.map(function(p, i){ return i; }).sort(function(a, b){ return REGALOS[a][3] - REGALOS[b][3]; }).forEach(function(i){
    var p = regalos[i];
    s += '<g class="plaza-regalo" data-i="'+i+'" transform="translate('+p.x+' '+p.y+')">' + p.deco + '</g>';
  });
  return { svg: s, defs: defs, bolas: bolas, regalos: regalos, luces: luces, estrella: { x: 0, y: -604 }, colgante: colgante };
};

/* ── fase 7: pantallas (Empezamos / Vuelvo / Fin) para los fondos ──
   HW.pantalla(lienzo, op) pone encima del lienzo (1920×1080) el bloque de texto
   portado de las Pantallas de Halloween: chip + título + subtítulo + cuenta atrás.
   op = { tipo:'soon'|'brb'|'ending', titulo, subtitulo, chip, fin, cuenta (bool),
          minutos, acento, zona:{ left, top, width, height, align } }
   · zona en píxeles del diseño 1920×1080; align 'left' | 'center' | 'right'.
     Con height, el bloque se centra en vertical y el texto se encoge hasta caber.
   · cuenta mm:ss; al llegar a 0 dice op.fin (o «¡Ya casi!»). minutos <= 0 la apaga.
     En «ending» no hay cuenta.
   · Todo el texto va por textContent (si alguien escribe <b>, sale <b>).
   Devuelve { el, ajustar(), destruir() }. Estilos: .hw-pantalla, .hw-p-chip,
   .hw-p-titulo, .hw-p-sub, .hw-p-cuenta (cada fondo puede retocarlos). */
HW.TEXTOS_PANTALLA = {
  soon:   { chip:'Empezamos pronto', titulo:'Calentando el chocolate', sub:'Ponte cómodo junto a la chimenea, que ya casi arrancamos.' },
  brb:    { chip:'Ya vuelvo', titulo:'Fui por más galletas', sub:'No te vayas: la chimenea sigue encendida y vuelvo enseguida.' },
  ending: { chip:'Gracias por venir', titulo:'¡Felices fiestas!', sub:'Gracias por pasar la noche aquí. ¡Nos vemos en el próximo directo!' },
  fin: '¡Ya casi!'
};
function cssPantalla(){
  if (document.getElementById('hw-css-pantalla')) return;
  var s = document.createElement('style'); s.id = 'hw-css-pantalla';
  var entra = 'hw-p-entra 1.1s cubic-bezier(.34,1.4,.64,1) both';
  s.textContent =
    '.hw-pantalla{position:absolute;display:flex;flex-direction:column;justify-content:center;--u:1px;--ft:1;--fs:1;pointer-events:none;}' +
    '.hw-pantalla.hw-p-left{align-items:flex-start;text-align:left;}' +
    '.hw-pantalla.hw-p-center{align-items:center;text-align:center;}' +
    '.hw-pantalla.hw-p-right{align-items:flex-end;text-align:right;}' +
    '.hw-p-chip{display:inline-block;font:700 calc(var(--u) * 25 * var(--fs))/1 var(--display);letter-spacing:.14em;text-transform:uppercase;' +
      'color:#1d1a2e;background:var(--p-acento);padding:calc(var(--u) * 11) calc(var(--u) * 24);border-radius:999px;border:calc(var(--u) * 3) solid #1d1a2e;' +
      'box-shadow:0 calc(var(--u) * 4) 0 #1d1a2e, 0 0 calc(var(--u) * 26) var(--p-acento-sombra);max-width:100%;overflow-wrap:anywhere;' +
      'animation:' + entra + ', hw-p-chip 3.2s ease-in-out 1.2s infinite;}' +
    '.hw-p-titulo{margin:calc(var(--u) * 24) 0 0;font:700 calc(var(--u) * 100 * var(--ft))/1.04 var(--display);color:#fff4dd;letter-spacing:-.005em;' +
      'max-width:100%;overflow-wrap:break-word;animation:' + entra + ' .15s;' +
      'text-shadow:0 calc(var(--u) * 5) 0 #1d1a2e, 0 0 calc(var(--u) * 22) var(--p-acento-sombra), 0 0 calc(var(--u) * 60) var(--p-acento-sombra);}' +
    '.hw-p-sub{margin:calc(var(--u) * 20) 0 0;font:700 calc(var(--u) * 31 * var(--fs))/1.35 var(--cuerpo);color:#f3e2cc;max-width:100%;' +
      'overflow-wrap:break-word;text-shadow:0 calc(var(--u) * 2) 0 rgba(29,26,46,.7);animation:' + entra + ' .35s;}' +
    '.hw-p-cuenta{margin-top:calc(var(--u) * 28);display:inline-flex;align-items:center;gap:calc(var(--u) * 16);' +
      'font:700 calc(var(--u) * 56 * var(--fs))/1 var(--display);color:#fff4dd;font-variant-numeric:tabular-nums;' +
      'padding:calc(var(--u) * 12) calc(var(--u) * 28);border-radius:calc(var(--u) * 26);background:rgba(29,26,46,.62);' +
      'border:calc(var(--u) * 3) solid var(--p-acento-borde);box-shadow:0 0 calc(var(--u) * 30) var(--p-acento-suave), inset 0 0 calc(var(--u) * 18) var(--p-acento-suave);' +
      'animation:' + entra + ' .55s;}' +
    '.hw-p-cuenta[hidden],.hw-p-sub[hidden]{display:none;}' +
    '.hw-p-cuenta svg{width:calc(var(--u) * 50 * var(--fs));height:calc(var(--u) * 50 * var(--fs));display:block;overflow:visible;}' +
    '.hw-p-cuenta svg > g{animation:hw-p-gira 6s ease-in-out infinite;transform-origin:0 0;}' +
    '.hw-p-cuenta.hw-p-fin span{display:inline-block;animation:hw-p-salta 1.2s cubic-bezier(.34,1.6,.64,1) infinite;}' +
    '@keyframes hw-p-entra{from{opacity:0;transform:translateY(calc(var(--u) * 28))}to{opacity:1;transform:none}}' +
    '@keyframes hw-p-chip{0%,100%{transform:translateY(0)}50%{transform:translateY(calc(var(--u) * -5))}}' +
    '@keyframes hw-p-gira{0%,100%{transform:rotate(-8deg)}50%{transform:rotate(8deg)}}' +
    '@keyframes hw-p-salta{0%,100%{transform:scale(1)}40%{transform:scale(1.08)}}';
  document.head.appendChild(s);
}
HW.pantalla = function(lienzo, op){
  op = op || {};
  cssPantalla();
  var TX = HW.TEXTOS_PANTALLA, tipo = (op.tipo === 'brb' || op.tipo === 'ending') ? op.tipo : 'soon', t = TX[tipo];
  var z = op.zona || {}, L = +z.left || 120, Tp = +z.top || 200, W = +z.width || 800, Hh = +z.height || 0;
  var al = (z.align === 'center' || z.align === 'right') ? z.align : 'left', acento = HW.hex(op.acento, '#ffcf5c');
  var raiz = document.createElement('div'); raiz.className = 'hw-pantalla hw-p-' + al + ' hw-p-tipo-' + tipo;
  raiz.style.left = (L / 19.2).toFixed(3) + '%'; raiz.style.top = (Tp / 10.8).toFixed(3) + '%';
  raiz.style.width = (W / 19.2).toFixed(3) + '%'; if (Hh) raiz.style.height = (Hh / 10.8).toFixed(3) + '%';
  raiz.style.setProperty('--p-acento', acento);
  raiz.style.setProperty('--p-acento-sombra', HW.rgba(acento, .55));
  raiz.style.setProperty('--p-acento-suave', HW.rgba(acento, .25));
  raiz.style.setProperty('--p-acento-borde', HW.rgba(acento, .7));
  var chip = document.createElement('span'); chip.className = 'hw-p-chip';
  var tit = document.createElement('h1'); tit.className = 'hw-p-titulo';
  var sub = document.createElement('p'); sub.className = 'hw-p-sub';
  var cue = document.createElement('div'); cue.className = 'hw-p-cuenta'; cue.hidden = true;
  var txSub = String(op.subtitulo || t.sub);
  chip.textContent = String(op.chip || t.chip);
  tit.textContent = String(op.titulo || t.titulo);
  sub.textContent = txSub; sub.hidden = !txSub.trim();
  raiz.appendChild(chip); raiz.appendChild(tit); raiz.appendChild(sub); raiz.appendChild(cue);
  lienzo.appendChild(raiz);
  /* Encoge el texto (primero el título) hasta que quepa en la zona */
  function ajustar(){
    var ancho = lienzo.clientWidth || window.innerWidth || 1920;
    raiz.style.setProperty('--u', (ancho / 1920).toFixed(4) + 'px');
    var ft = 1, fs = 1;
    for (var i = 0; i < 18; i++){
      raiz.style.setProperty('--ft', ft.toFixed(3)); raiz.style.setProperty('--fs', fs.toFixed(3));
      var alto = Hh ? raiz.clientHeight : Infinity, sobra = false;
      [chip, tit, sub, cue].forEach(function(e){ if (!e.hidden && e.scrollWidth > raiz.clientWidth + 1) sobra = true; });
      if (!sobra && raiz.scrollHeight <= alto + 1) break;
      ft = Math.max(.34, ft - .06); if (ft < .8) fs = Math.max(.6, fs - .045);
    }
  }
  var reloj = null, min = parseFloat(op.minutos);
  if (op.cuenta !== false && tipo !== 'ending' && min > 0){
    cue.hidden = false;
    cue.innerHTML = '<svg viewBox="-30 -30 60 60"><g>' + A.estrella({ r:16, cara:true }) + '</g></svg>';
    var num = document.createElement('span'); cue.appendChild(num);
    var finT = Date.now() + Math.min(120, min) * 60000;
    var tic = function(){
      var r = Math.max(0, Math.round((finT - Date.now()) / 1000));
      if (r > 0) num.textContent = Math.floor(r / 60) + ':' + ('0' + r % 60).slice(-2);
      else { num.textContent = String(op.fin || TX.fin); cue.classList.add('hw-p-fin'); if (reloj) clearInterval(reloj); reloj = null; ajustar(); }
    };
    tic(); if (min > 0 && cue.className.indexOf('hw-p-fin') < 0) reloj = setInterval(tic, 250);
  }
  ajustar();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(ajustar);
  var alCambiar = function(){ ajustar(); };
  window.addEventListener('resize', alCambiar);
  return {
    el: raiz, ajustar: ajustar,
    destruir: function(){ if (reloj) clearInterval(reloj); window.removeEventListener('resize', alCambiar); if (raiz.parentNode) raiz.parentNode.removeChild(raiz); }
  };
};

/* ── 7. Guirnalda de luces (la usan Guirnalda, fondos y marco) ── */
HW.PALETAS = {
  clasica:   ['#ff4d5e','#3fd47a','#ffcf5c','#4fb3ff','#ff7fc8'],
  calida:    ['#fff1c9','#ffcf5c','#ffe39a','#ffb547'],
  rojoverde: ['#ff4d5e','#3fd47a','#e8424f','#5fe08e'],
  fria:      ['#8fd3ff','#eef8ff','#6fa8ff','#c4e6ff']
};
/* Dibuja dentro de un <svg> con viewBox "0 0 ancho alto".
   op: { ancho, alto (300), pos:'arriba'|'abajo', paleta, colgantes:'calcetas'|'bastones'|'estrellas'|'bolas'|'ninguno',
         pino (bool), parpadeo:'suave'|'secuencia'|'ninguno', brillo, semilla, tramo, comba, y, puntos }
   Arriba: el cable cuelga en curvas y los focos miran hacia abajo.
   Abajo: el cable hace arcos hacia arriba, los focos miran hacia arriba y
   los adornos cuelgan de lo alto de cada arco. */
HW.guirnalda = function(svg, op){
  var W = op.ancho, alto = op.alto || 300, abajo = op.pos === 'abajo', sg = abajo ? -1 : 1;
  var tramo = op.tramo || 330, comba = op.comba || 58, rnd = HW.azar(op.semilla || 7);
  var y0 = op.y != null ? op.y : (abajo ? alto - 40 : 30);
  var cols = HW.PALETAS[op.paleta] || HW.PALETAS.clasica, brillo = op.brillo == null ? 1 : op.brillo;
  var parp = op.parpadeo || 'suave', colg = op.colgantes || 'ninguno';
  var n = Math.max(1, Math.round((W + 60) / tramo)), paso = (W + 60) / n, x0 = -30;
  var defs = '', cable, cable2, luces = '', objetos = '', puntos = '', chispas = '', verde = '', k = 0, uid = 'gl' + (++nId) + '-';
  cols.forEach(function(c, i){
    defs += '<radialGradient id="'+uid+i+'"><stop offset="0" stop-color="'+c+'" stop-opacity=".95"/><stop offset=".35" stop-color="'+c+'" stop-opacity=".45"/><stop offset="1" stop-color="'+c+'" stop-opacity="0"/></radialGradient>';
  });
  defs += '<radialGradient id="'+uid+'A"><stop offset="0" stop-color="#ffd98a" stop-opacity=".85"/><stop offset="1" stop-color="#ffd98a" stop-opacity="0"/></radialGradient>';
  function combaDe(i){ return sg * comba * (0.85 + 0.3 * ((i * 37) % 10) / 10); }
  function punto(i, t){ var xa = x0 + i*paso, c = combaDe(i); return { x: xa + paso*t, y: y0 + 4*c*t*(1-t), ang: Math.atan2(4*c*(1-2*t), paso) * 180/Math.PI }; }
  cable = 'M' + x0 + ' ' + y0; cable2 = 'M' + x0 + ' ' + (y0+3);
  var rojoVerde = [C.rojo, C.verde, '#f4f1ea'], patrones = ['rayas', 'copo', 'lunares'], nc = 0;
  for (var i = 0; i < n; i++){
    var c = combaDe(i), xa = x0 + i*paso;
    cable  += 'Q' + f1(xa + paso/2) + ' ' + f1(y0 + 2*c) + ' ' + f1(xa + paso) + ' ' + y0;
    cable2 += 'Q' + f1(xa + paso/2) + ' ' + f1(y0 + 2*c + 5) + ' ' + f1(xa + paso) + ' ' + (y0+3);
    /* 4 focos por tramo y, si hay adornos, uno colgando en el centro de cada tramo */
    (colg !== 'ninguno' ? [0.14, 0.38, 0.5, 0.62, 0.86] : [0.14, 0.38, 0.62, 0.86]).forEach(function(t){
      var p = punto(i, t);
      if (t === 0.5){
        var largo = abajo ? 8 + rnd() * 12 : 22 + rnd() * 30, dur = (3.4 + rnd() * 1.6).toFixed(2), del = (-rnd() * 4).toFixed(2), esc = 0.72 + rnd() * 0.12, dib = '', glow = '';
        if (colg === 'calcetas') dib = A.calceta({ color: rojoVerde[nc % 3], patron: patrones[nc % 3] });
        else if (colg === 'bastones') dib = A.baston();
        else if (colg === 'bolas'){ var cb = cols[nc % cols.length], rg = HW.rgb(cb); dib = A.bola((rg[0] + rg[1] + rg[2]) / 765 > .8 ? [C.dorado, C.rojo][nc % 2] : cb); }
        else { dib = '<g transform="translate(0 24)">' + A.estrella({ r:22, cara: nc % 2 === 0, brillo:false }) + '</g>'; glow = 1; }
        nc++;
        objetos += '<g transform="translate('+f1(p.x)+' '+f1(p.y)+')"><g class="hw-mece" style="animation-duration:'+dur+'s;animation-delay:'+del+'s">' +
          (glow ? '<circle cx="0" cy="'+f1(largo + 24*esc)+'" r="'+f1(60*esc*Math.max(.6, brillo))+'" fill="url(#'+uid+'A)" style="opacity:'+(0.55*Math.min(1.6, brillo)).toFixed(2)+'"/>' : '') +
          '<line x1="0" y1="0" x2="0" y2="'+f1(largo + 4)+'" stroke="#e9dcc0" stroke-width="1.6"/>' +
          '<g transform="translate(0 '+f1(largo)+') scale('+esc.toFixed(2)+')">' + dib + '</g></g></g>';
      } else {
        var ci = k % cols.length, kk = k; k++;
        var rot = (p.ang * 0.6 + (rnd() - .5) * 26 + (abajo ? 180 : 0)).toFixed(1), anim = '', animFoco = '';
        if (parp === 'suave'){
          var d2 = (2.2 + rnd() * 2.8).toFixed(2), de2 = (-rnd() * 5).toFixed(2), st = 'animation-duration:'+d2+'s;animation-delay:'+de2+'s';
          anim = ' class="hw-luz" style="'+st+'"'; animFoco = { clase:'hw-encendido', estilo:st };
        } else if (parp === 'secuencia'){
          var st2 = 'animation-delay:'+(-(2 - kk % 3) * 0.6).toFixed(1)+'s';
          anim = ' class="hw-sec" style="'+st2+'"'; animFoco = { clase:'hw-sec-foco', estilo:st2 };
        }
        luces += '<g transform="translate('+f1(p.x)+' '+f1(p.y)+') rotate('+rot+')">' +
          '<g style="opacity:'+Math.min(1, .85*brillo).toFixed(2)+'"><circle cx="0" cy="31" r="'+(46*Math.max(.6, brillo)).toFixed(0)+'" fill="url(#'+uid+ci+')"'+anim+'/></g>' +
          A.foco(cols[ci], animFoco || null) + '</g>';
      }
    });
    if (op.puntos !== false){
      for (var d = 0; d < 2; d++){
        var pp = punto(i, 0.3 + rnd() * 0.4), dx = (rnd() - .5) * 70, dy = sg * (16 + rnd() * 26);
        puntos += '<g transform="translate('+f1(pp.x+dx)+' '+f1(pp.y+dy)+')"><g class="hw-luz" style="animation-duration:'+(2+rnd()*2).toFixed(2)+'s;animation-delay:'+(-rnd()*3).toFixed(2)+'s">' +
          '<circle r="4" fill="#ffcf5c" opacity=".8"/><circle cx="8" cy="-3" r="3" fill="#ffcf5c" opacity=".7"/><circle cx="3" cy="6" r="2.6" fill="#ffe39a" opacity=".8"/></g></g>';
      }
      var pc = punto(i, rnd());
      chispas += '<g transform="translate('+f1(pc.x + (rnd()-.5)*80)+' '+f1(pc.y + sg*(30 + rnd()*50))+') scale('+(0.5+rnd()*0.5).toFixed(2)+')"><g class="hw-chispa" style="animation-duration:'+(2.4+rnd()*2).toFixed(2)+'s;animation-delay:'+(-rnd()*4).toFixed(2)+'s">' + A.chispa() + '</g></g>';
    }
  }
  if (op.pino) verde = ramasPino(cable, n, punto, rnd);
  svg.innerHTML = '<defs>' + defs + '</defs>' +
    '<g>' + puntos + '</g>' +
    '<path d="'+cable2+'" fill="none" stroke="#123524" stroke-width="2.5" opacity=".9"/>' +
    '<path d="'+cable+'" fill="none" stroke="#1f5a3a" stroke-width="3.5" stroke-linecap="round"/>' +
    verde + luces + objetos + '<g>' + chispas + '</g>';
};
/* Ramitas de pino sobre el cable: tres trazos con guiones (textura de agujas)
   + ramitas sueltas a lo largo + alguna baya roja */
function ramasPino(cable, n, punto, rnd){
  var s = '<path d="'+cable+'" fill="none" stroke="'+TINTA+'" stroke-width="25" stroke-linecap="round" opacity=".55"/>' +
    '<path d="'+cable+'" fill="none" stroke="#173f2b" stroke-width="21" stroke-linecap="round"/>' +
    '<path d="'+cable+'" fill="none" stroke="#2f8f5b" stroke-width="15" stroke-linecap="round" stroke-dasharray="2.5 4"/>' +
    '<path d="'+cable+'" fill="none" stroke="#4fb37a" stroke-width="8" stroke-linecap="round" stroke-dasharray="1.5 6" stroke-dashoffset="3"/>';
  var verdes = ['#1f5a3a', '#2f8f5b', '#3fa36a', '#4fb37a'], bayas = '';
  for (var i = 0; i < n; i++){
    for (var t = 0.015; t < 1; t += 0.055){
      var p = punto(i, Math.min(1, t + rnd() * 0.02)), g = '';
      for (var a = 0; a < 5; a++){
        var ang = (p.ang + (rnd() < .5 ? 0 : 180) + (rnd() - .5) * 110) * Math.PI / 180, L = 9 + rnd() * 7;
        g += '<path d="M0 0L'+f1(Math.cos(ang) * L)+' '+f1(Math.sin(ang) * L)+'" stroke="'+verdes[Math.floor(rnd() * verdes.length)]+'"/>';
      }
      s += '<g transform="translate('+f1(p.x)+' '+f1(p.y + (rnd() - .5) * 6)+')" stroke-width="3.2" stroke-linecap="round" fill="none">' + g + '</g>';
      if (rnd() < .16){
        var bx = p.x + (rnd() - .5) * 10, by = p.y + (rnd() - .5) * 8;
        bayas += circ(bx, by, 3.6, C.rojo, ' stroke="'+TINTA+'" stroke-width="1.4"') + circ(bx + 5, by + 3, 3.2, C.rojo, ' stroke="'+TINTA+'" stroke-width="1.4"') + circ(bx - 1, by + 5.5, 3, C.rojoOsc, ' stroke="'+TINTA+'" stroke-width="1.4"');
      }
    }
  }
  return '<g class="nv-pino-guirnalda">' + s + bayas + '</g>';
}
/* CSS de animación de la guirnalda y del arte (se inyecta una vez).
   Los keyframes hw-* viven en common.css. */
HW.cssArte = function(){
  if (document.getElementById('hw-css-arte')) return;
  var s = document.createElement('style'); s.id = 'hw-css-arte';
  s.textContent =
    '.hw-luz{animation:hw-titilar 3s ease-in-out infinite;}' +
    '.hw-encendido{animation:hw-encendido 3s ease-in-out infinite;}' +
    '.hw-sec{animation:hw-secuencia 1.8s linear infinite;}' +
    '.hw-sec-foco{animation:hw-secuencia-foco 1.8s linear infinite;}' +
    '.hw-mece{animation:hw-mecer 4s ease-in-out infinite;transform-origin:0 0;}' +
    '.hw-chispa{animation:hw-chispa 3s ease-in-out infinite;transform-box:fill-box;transform-origin:50% 50%;}' +
    '.hw-flota{animation:hw-flotar 3.2s ease-in-out infinite;}' +
    '.hw-llama{animation:hw-llama 1.4s ease-in-out infinite;transform-origin:0 0;}' +
    '.hw-vela{animation:hw-vela 2.8s ease-in-out infinite;}' +
    '.hw-humo{animation:hw-humo 6s ease-out infinite;transform-box:fill-box;transform-origin:50% 100%;}' +
    '.hw-aurora{animation:hw-aurora 14s ease-in-out infinite;transform-box:fill-box;transform-origin:50% 100%;}' +
    '.hw-destello{animation:hw-destello 3.2s ease-in-out infinite;transform-box:fill-box;transform-origin:50% 50%;}' +
    '.hw-vapor{animation:hw-vapor 2.8s ease-out infinite;transform-box:fill-box;transform-origin:50% 100%;}' +
    '@keyframes hw-vela{0%,100%{opacity:1}18%{opacity:.8}32%{opacity:.96}50%{opacity:.72}66%{opacity:1}82%{opacity:.86}}' +
    '@keyframes hw-encendido{0%,100%{opacity:1}45%{opacity:.72}60%{opacity:.94}}' +
    '@keyframes hw-secuencia{0%,28%{opacity:1}36%,92%{opacity:.08}100%{opacity:1}}' +
    '@keyframes hw-secuencia-foco{0%,28%{opacity:1}36%,92%{opacity:.18}100%{opacity:1}}';
  document.head.appendChild(s);
};
})();
